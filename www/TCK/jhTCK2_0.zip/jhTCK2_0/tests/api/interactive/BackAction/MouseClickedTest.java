/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... BackAction(control).mouseClicked(e) --> BackAction(control).mouseClicked(e)
 */

package javasoft.sqe.tests.api.javax.help.BackAction;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import java.util.Date;

import javax.help.JHelp;
import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.BackAction;

import javax.swing.JFrame;
import javax.swing.JButton;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.BackAction ... mouseClicked(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class MouseClickedTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public MouseClickedTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        MouseClickedTest test = new MouseClickedTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "mouseclickedtest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void mouseClicked(java.awt.event.MouseEvent e)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void mouseclickedtest() {
        addInfo("This test checks mouseClicked(java.awt.event.MouseEvent e) method.");
        addInfo("1) A 'Back Frame' frame with 'JHelp/April fools' days' should come up");
        addInfo("2) 'April Fools' node should be selected and the back button should be enabled");
        addInfo("3) A 'Back' frame with 'Back' button have to come up");
        addInfo("4) Click a 'Back' button");
        addInfo("5a) Now should be enabled forward button");
        addInfo("5b) 'Introduction' node should be selecrted");
        addInfo("5c) The 'Mixing secular and sacred holidays' page should be displayed");
        addInfo("6) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        MouseClickedTestClass testPanel = new MouseClickedTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("BackAction.mouseClicked(java.awt.event.MouseEvent e)");
        setTimeout(600);
    }



    /**
     * Help class with JFrame for mouseClicked button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class MouseClickedTestClass extends Applet implements ActionListener {
        private JButton backButton = null;
        private BackAction backAction = null;

        public MouseClickedTestClass() {
            try {
                //create a HelpSet object ... start
                HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
                //create a HelpSet object ... end

                //create a JHelp object ... start
                JHelp jhelp = new JHelp(hs);
                //create a JHelp object ... end

                //set an current ID to HelpSet object ... start
                ID currentID = ID.create("aprilfools", hs);
                jhelp.setCurrentID(currentID);
                //set an current ID to HelpSet object ... end

                //create a BackAction object ... start
                this.backAction = new BackAction(jhelp);
                //create a BackAction object ... end

                //display the JHelp object ... start
                JFrame frame = new JFrame("Back Frame");
                frame.getContentPane().add(jhelp);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JHelp object ... end


                //create a backButton and setup action listener for it ... start
                backButton = new JButton("Back");
                backButton.addActionListener(this);
                //create a backButton and setup action listener for it ... end

                //setup JFrame with backButton and show it ... start
                JFrame backFrame        = new JFrame("Back Frame");
                Container backContainer = backFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(backButton);
                backFrame.setResizable(false);
                backFrame.pack();
                backFrame.show();
                //setup JFrame with backButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }


        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == backButton) {
                //create a MouseEvent object ... start
                MouseEvent mevent = new MouseEvent((Component)event.getSource(), event.getID(), (new Date()).getTime(), MouseEvent.MOUSE_CLICKED, (backButton.getX()/2), (backButton.getY()/2), 1, false);
                //create a MouseEvent object ... end

                //perform action for BackAction ... start
                backAction.mouseClicked(mevent);
                //perform action for BackAction ... end
            }
        }
    }

}

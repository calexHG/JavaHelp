/*
 * @(#)TrackCSEventsTest.java	1.1 99/03/05
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.CSH;

import javax.help.HelpSet;
import javax.help.HelpBroker;
import javax.help.CSH;

import javasoft.sqe.javatest.lib.InteractiveTest;
import javasoft.sqe.javatest.Status;

import java.io.PrintWriter;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.*;
import java.awt.*;
import java.net.URL;
import java.applet.*;

/**
 * Tests for javax.help.CSH.trackCSEvents()
 *
 * @author Sudhakar.Adini
 */
public class TrackCSEventsTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    class ActionTest extends Applet implements ActionListener {
        java.lang.Object obj;
        JButton b,b1;
        JFrame ff;
        public ActionTest() {
          
            ff = new JFrame("Test in CSH.trackCSEvents");
            b = new JButton("StartTracking");            
            b1 = new JButton("HalloweenHelp");            
            CSH.setHelpIDString(b, "halloween");
            b.addActionListener(this);
            ff.getContentPane().setLayout(new FlowLayout());
            ff.getContentPane().add(b);
            ff.getContentPane().add(b1);
            ff.pack();
            ff.show();        
        }
        
        public void actionPerformed(ActionEvent e) {
            obj = CSH.trackCSEvents();
        }
        
        public boolean textChanged() {
            return true;
        }
    }
    protected ActionTest testPanel;
    // These interactive tests use the Done user interface
    
    public TrackCSEventsTest() {
        super("Done");
    }
    /* Standalone interface */
    
    public static void main(String[] argv) {
        TrackCSEventsTest test = new TrackCSEventsTest();
        PrintWriter log = new PrintWriter(System.err, true);
        PrintWriter ref = new PrintWriter(System.out, true);
        Status status = test.run(argv, log, ref);
        status.exit();
    }
    /* Test interface */
    
    public Status init(String[] argv) {
        testCases = new String[1];
        testCases[0] = "testCase1";
        return Status.passed("");
    }
    
    public void testCase1() {
        String intro = "This test is to check the trackCSEvents() "
        + "method of CSH class";
        String instruction1 = "1. A Frame with two Buttons will be "
        + "displayed." ;
        String instruction2 = "2. Click the Button labeled \"StartTracking\"";
        String instruction3 = "3. Click the Button labeled \"HalloweenHelp\"";
	String instruction4 = "4. Click Done when finished";
        
        String passMsg="trackCSEvents() returns the object which was clicked.";
        String failMsg = "trackCSEvents() does not returns the object "
        + "that was clicked.";
        // Add user information
        addInfo(intro);
        addInfo(instruction1);
        addInfo(instruction2);
        addInfo(instruction3);
        addInfo(instruction4);
     
        // Add test panel to frame
        testPanel = new ActionTest();
        addTestPanel((java.awt.Panel)testPanel);
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);
        // Set title of test frame
        setFrameTitle(" Instruction Frame ");
        setTimeout(600);
    }
    
    public void checkResult() {
    	
        if((testPanel.obj).equals(testPanel.b1)) {
            setStatus(Status.passed(passMessage));
        }
        else {
            setStatus(Status.failed(failMessage));
        }
    }
    
    public void doTestCleanup() {

        if (testPanel.ff != null)
            testPanel.ff.dispose();

    }
}

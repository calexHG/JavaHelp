/*
* @(#)ActionPerformedTest.java	1.1 99/03/05
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DisplayHelpAfterTracking;

import javasoft.sqe.javatest.lib.InteractiveTest;
import javasoft.sqe.javatest.Status;
import java.io.PrintWriter;
import java.io.PrintStream;
import java.io.OutputStreamWriter;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.net.*;
import java.io.*;
import java.util.*;
import javax.help.*;
import java.applet.*;
/**
* Tests for CSH.DisplayHelpAfterTracking.actionPerformed()
*
* @author Sudhakar.Adini
*/
public class ActionPerformedTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    class ActionTest extends Applet {
        private HelpSet masterHS;
        private URL masterURL;
        private ClassLoader myLoader;
        private HelpSet mainHS = null;
        private HelpBroker mainHB;
        JFrame ff;
        public ActionTest() {
            ff = new JFrame("CSH");
            try {
                ClassLoader cl = this.getClass().getClassLoader();
                URL url = new URL("file", null, HSLOC
                        + "/holidays/HolidayHistory.hs");
                mainHS = new HelpSet(cl, url);
                mainHB = mainHS.createHelpBroker();
            }
            catch(Exception ee) {
                //System.out.println(" Help Set Master not found");
                return ;
            }
            // Add a button to show the helpset
            JButton b = new JButton("StartTracking");
            JButton b1 = new JButton("HalloweenHelp");
	    JTextField tf = new JTextField(20);
	    tf.setText("ThanksGiving Help");
            CSH.setHelpIDString(b1, "halloween");
            CSH.setHelpIDString(tf, "thanksgiving");
            b.addActionListener(new CSH.DisplayHelpAfterTracking(mainHB));
            ff.getContentPane().setLayout(new FlowLayout()); 
            ff.getContentPane().add(b);
            ff.getContentPane().add(b1);
            ff.getContentPane().add(tf);
            ff.pack();
            ff.show();
        }        
        
    }
    protected ActionTest testPanel;
    // These interactive tests use the Done user interface
    
    public ActionPerformedTest() {
        super("YesNo");
    }
    /* Standalone interface */
    
    public static void main(String[] argv) {
        ActionPerformedTest test = new ActionPerformedTest();
        PrintWriter log = 
            new PrintWriter(new OutputStreamWriter(System.err), true);
        PrintWriter ref = 
            new PrintWriter(new OutputStreamWriter(System.out), true);
        Status status = test.run(argv, log, ref);
        status.exit();
    }
    /* Test interface */
    
    public Status init(String[] argv) {
        testCases = new String[1];
        testCases[0] = "xx";
        return Status.passed("");
    }
    
    public void xx() {
        String intro = "This test is to check the actionPerformed() "
        + "method of CSH.DisplayHelpAfterTracking";
	String instruction1 = "1. A Frame with two buttons and a textField " 
        + "will be displayed";
        String instruction2 = "2. If you are testing on jdk1.1.x Click \"Yes\" now."
	+ "If on jdk1.2 proceed to next instruction";
	String instruction3 = "3. Click button labeled \"StartTracking\" , the cursor" 
	+ "should change.";
	String instruction4 = "4. Click button labeled \"Halloween\" , the Help"
        + "window for Halloween should come up.";
	String instruction5 = "5. Click \"StartTracking\" button again , the cursor"
	+"should change.";
	String instruction6 = "6. Click on the TextField , the Help window for " 
	+ "ThanksGiving should come up";
	String instruction7= "7. Click \"Yes\" if it worked OK";
        String passCondition = "The Help Window must come.";
        String passMsg = "actionPerformed() method works as expected.";
        String failMsg= "actionPerformed() feature does NOT work as expected.";
        // Add user information
        addInfo(intro);
        addInfo(instruction1);
        addInfo(instruction2);
        addInfo(instruction3);
        addInfo(instruction4);
        addInfo(instruction5);
        addInfo(instruction6);
        addInfo(instruction7);
        addInfo(passCondition);
        // Add test panel to frame
        testPanel = new ActionTest();
        addTestPanel((java.awt.Panel)testPanel);
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);
        // Set title of test frame
        setFrameTitle(" CSH.DisplayHelpAfterTracking.actionPerformed() ");
        setTimeout(600);
    }  
      
    public void doTestCleanup() {

        if (testPanel.ff != null)
            testPanel.ff.dispose();
        if (testPanel.mainHB != null) {
             testPanel.mainHB.setDisplayed(false);
             testPanel.mainHB = null;
        }

    }    
 
}

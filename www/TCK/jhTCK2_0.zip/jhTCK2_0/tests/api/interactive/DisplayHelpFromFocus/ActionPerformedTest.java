/*
* @(#)ActionPerformedTest.java	1.1 99/03/05
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DisplayHelpFromFocus;
import java.io.PrintStream;
import javasoft.sqe.javatest.lib.InteractiveTest;
import javasoft.sqe.javatest.Status;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.awt.event.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.net.*;
import java.io.*;
import java.util.*;
import javax.help.*;
import java.applet.*;
/**
 * Tests for CSH.DisplayHelpFromFocus.actionPerformed()
 *
 * @author Sudhakar.Adini
 */
public class ActionPerformedTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    class ActionTest extends Applet {
        private HelpSet masterHS;
        private URL masterURL;
        private ClassLoader myLoader;
        private HelpSet mainHS = null;
        private HelpBroker mainHB;
        JFrame ff;
        public ActionTest() {
            ff = new JFrame("CSH");
            try {
                ClassLoader cl = this.getClass().getClassLoader();
                URL url = new URL("file", null, HSLOC 
                        + "/holidays/HolidayHistory.hs");
                mainHS = new HelpSet(cl, url);
                mainHB = mainHS.createHelpBroker();
            }
            catch(Exception ee) {
                //System.out.println(" Help Set Master not found");
                return ;
            }
            // Add a button to show the helpset
            JButton b = new JButton("HalloweenHelp");
            CSH.setHelpIDString(b, "halloween");
            b.addActionListener(new CSH.DisplayHelpFromFocus(mainHB));
            ff.getContentPane().add(b);
            ff.pack();
            ff.show();
        }        
      
    }
    protected ActionTest testPanel;
    // These interactive tests use the Done user interface
    
    public ActionPerformedTest() {
        super("YesNo");
    }
    /* Standalone interface */
    
    public static void main(String[] argv) {
        ActionPerformedTest test = new ActionPerformedTest();
        PrintWriter log = 
            new PrintWriter(new OutputStreamWriter(System.err), true);
        PrintWriter ref = 
            new PrintWriter(new OutputStreamWriter(System.out), true);
        Status status = test.run(argv, log, ref);
        status.exit();
    }
    /* Test interface */
    
    public Status init(String[] argv) {
        testCases = new String[1];
        testCases[0] = "xx";
        return Status.passed("");
    }
    
    public void xx() {
        String intro = "This test is to check the actionPerformed() "
        + "method of CSH.DisplayHelpFromFocus";
        String instruction1 = "1. A Frame with a button will be " 
        + " displayed." ;
	String instruction2 = "2. Click the button labeled \"HalloweenHelp\" " 
	+ " and observe whether Help for Halloween is visible." ;
	String instruction3 = "3. Click \"Yes\" if worked OK";
        String passCondition = "The Help Window must come.";
        String passMsg = "actionPerformed() method works as expected.";
        String failMsg ="actionPerformed() feature does NOT work as expected.";
        // Add user information
        addInfo(intro);
        addInfo(instruction1);
        addInfo(instruction2);
        addInfo(instruction3);
        addInfo(passCondition);
        // Add test panel to frame
        testPanel = new ActionTest();
        addTestPanel((java.awt.Panel)testPanel);
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);
        // Set title of test frame
        setFrameTitle(" CSH.DisplayHelpFromFocus.actionPerformed() ");
        setTimeout(600);
    }    
   
    public void doTestCleanup() {

        if (testPanel.ff != null)
            testPanel.ff.dispose();
        if (testPanel.mainHB != null) {
             testPanel.mainHB.setDisplayed(false);
             testPanel.mainHB = null;
        }

    }  
   
}

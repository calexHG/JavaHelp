/*
* @(#)HelpSetRemovedTest.java	1.1 99/03/05
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.JHelp;

import javasoft.sqe.javatest.lib.InteractiveTest;
import javasoft.sqe.javatest.Status;

import javax.help.HelpSet;
import javax.help.event.HelpSetEvent;
import javax.help.JHelp;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.help.DefaultHelpModel;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.io.PrintStream;
import java.awt.*;
import java.awt.event.*;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import java.applet.*;
/**
 * Tests for javax.help.JHelp
 *
 *
 * @author Sudhakar.Adini
 */
public class HelpSetRemovedTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    
    class ActionTest extends Applet implements ActionListener {
        private HelpSet hs,hs1;
        private URL url,url1;
        private ClassLoader l;
        private JHelp jhelp;       
        java.lang.Object ss;
        JButton b,b1;
        JFrame ff,ff1;
        HelpSetEvent ee,ee1;
        public ActionTest() {
            ff = new JFrame("JHelp");          
            try {
                ClassLoader l = this.getClass().getClassLoader();
                url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
                url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                hs = new HelpSet(l, url);
                hs1 = new HelpSet(l, url1);
                jhelp = new JHelp(new DefaultHelpModel(hs));            
                b1= new JButton("Remove");
                int action = HelpSetEvent.HELPSET_ADDED;
                int action1 = HelpSetEvent.HELPSET_REMOVED;
                ee = new HelpSetEvent(b1, hs1, action);
                ee1 = new HelpSetEvent(b1, hs1, action1);             
                jhelp.helpSetAdded(ee);
                ff1= new JFrame("Removed");
                ff1.getContentPane().add(jhelp);
                ff1.setResizable(true);
                ff1.pack();
                ff1.show();
            }
            catch(Exception ee) {
		//System.out.println(" Help Set Master not found");
                return ;
            }           
            
            b1.setEnabled(true);            
            b1.addActionListener(this);           
            Container cc = ff.getContentPane();
            cc.setLayout(new FlowLayout());
            cc.add(b1);          
            ff.setResizable(false);
            ff.pack();
            ff.show(); 
        }
        
        public void actionPerformed(ActionEvent e) {
      
        	if(e.getSource() == b1) {
        	    jhelp.helpSetRemoved(ee1);
                }
         
        }
        
        public boolean textChanged() {
            return true;
        }
   }
    
   protected ActionTest testPanel;
    // These interactive tests use the Done user interface
    
   public HelpSetRemovedTest() {
        super("YesNo");
    }
    /* Standalone interface */
    
    public static void main(String[] argv) {
        HelpSetRemovedTest test = new HelpSetRemovedTest();
        PrintWriter log = 
            new PrintWriter(System.err, true);
        PrintWriter ref = 
            new PrintWriter(System.out, true);
        Status status = test.run(argv, log, ref);
        status.exit();
    }
    /* Test interface */
    
    public Status init(String[] argv) {
        testCases = new String[1];
        testCases[0] = "xx";
        return Status.passed("");
    }
    
    public void xx() {
        String intro = "This test is to check the "
        + "helpSetRemoved(HelpSetEvent e) method of JHelp";
        String instruction1 = "1. A Frame with button \"Remove\" and a " 
	+ "Help Window will be displayed ";
	String instruction2 = "2. Click the button labeled \"Remove\" "
        + "and observe whether 'merging helpsets' is removed."  ;
        String instruction3 = "3. Click \"Yes\" if worked OK";
        String passCondition = "The merging helpsets should be removed";
        String passMsg="helpSetRemoved(HelpSetEvent e) method works as expected.";
        String failMsg = "helpSetRemoved(HelpSetEvent e) feature "
        + "does NOT work as expected.";
        // Add user information
        addInfo(intro);
        addInfo(instruction1);
        addInfo(instruction2);
        addInfo(instruction3);
        addInfo(passCondition);
        // Add test panel to frame
        testPanel = new ActionTest();
        addTestPanel((java.awt.Panel)testPanel);
        // Set messages that get printed upon pass and fail
        setStatusMessages(passMsg, failMsg);
        // Set title of test frame
        setFrameTitle(" JHelp.helpSetRemoved(HelpSetEvent e) ");
        setTimeout(600);
    }
    
    public void checkResult() {
        if(testPanel.textChanged()) {
            setStatus(Status.passed(passMessage));
        }
        else {
            setStatus(Status.failed(failMessage));
        }
    }
    
    public void doTestCleanup() {

        if (testPanel.ff != null)
            testPanel.ff.dispose();

        if (testPanel.ff1 != null)
            testPanel.ff1.dispose();            

    }
    
}

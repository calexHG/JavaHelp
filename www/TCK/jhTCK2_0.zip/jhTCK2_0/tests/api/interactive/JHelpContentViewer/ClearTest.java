/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... JHelpContentViewer(hs).clear() --> JHelpContentViewer(hs).clear()
 */

package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;

import java.io.PrintWriter;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import java.net.URL;

import javax.swing.JFrame;
import javax.swing.JButton;

import javax.help.HelpSet;
import javax.help.JHelpContentViewer;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.JHelpContentViewer ... clear()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class ClearTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public ClearTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        ClearTest test = new ClearTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "cleartest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void clear()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void cleartest() {
        addInfo("This test checks clear() method.");
        addInfo("1) A Frame with 'Thanksgiving' page will be displayed");
        addInfo("2) A Frame with 'Clear' button will be displayed");
        addInfo("3) Click the 'Clear' button and the the Frame with text should be clear");
        addInfo("4) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        ClearTestClass testPanel = new ClearTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("JHelpContentViewer.clear()");
        setTimeout(600);
    }


    /**
     * Help class with JHelpContentViewer construction and JFrame for clear button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class ClearTestClass extends Applet implements ActionListener {
        private JButton clearButton = null;
        private JHelpContentViewer jhviewer = null;

        public ClearTestClass() {
            try {
                //create JHelpContentViewer and setup HelpSet and page ... start
                ClassLoader cl = this.getClass().getClassLoader();
                URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs     = new HelpSet(cl, hsurl);
                jhviewer       = new JHelpContentViewer(hs);
                jhviewer.setCurrentURL(new URL("file", null, HSLOC+"/holidays/hol/thanks.html") );
                //create JHelpContentViewer and setup HelpSet and page ... end

                //create JFrame with previously created JHelpContentViewer and show it ... start
                JFrame frame = new JFrame("JHelpContentViewer.clear()");
                frame.getContentPane().add(jhviewer);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //create JFrame with previously created JHelpContentViewer and show it ... end

                //create a clearButton and setup action listener for it ... start
                clearButton = new JButton("Clear");
                clearButton.addActionListener(this);
                //create a clearButton and setup action listener for it ... end

                //setup JFrame with clearButton and show it ... start
                JFrame clearFrame        = new JFrame("Clear Frame");
                Container clearContainer = clearFrame.getContentPane();
                clearContainer.setLayout(new FlowLayout() );
                clearContainer.add(clearButton);
                clearFrame.setResizable(false);
                clearFrame.pack();
                clearFrame.show();
                //setup JFrame with clearButton and show it ... end
            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }


        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == clearButton) {
                //clear the JHelpContentViewer ... start
                jhviewer.clear();
                //clear the JHelpContentViewer ... end
            }
        }
    }

}

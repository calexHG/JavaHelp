/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... JHelpIndexNavigator(hs).collapseID(target) --> JHelpIndexNavigator(hs).collapseID(target)
 */

package javasoft.sqe.tests.api.javax.help.JHelpIndexNavigator;

import java.io.PrintWriter;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.swing.JFrame;
import javax.swing.JButton;

import javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.HelpModel;
import javax.help.NavigatorView;
import javax.help.DefaultHelpModel;
import javax.help.JHelpIndexNavigator;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.JHelpIndexNavigator ... collapseID(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class CollapseIDTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public CollapseIDTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        CollapseIDTest test = new CollapseIDTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "collapseIDtest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void collapseID(java.lang.String target)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>target</code> valid value
     */
    public void collapseIDtest() {
        addInfo("This test checks collapseID(java.lang.String target) method.");
        addInfo("1) A Frame with Index should be displayed ... all nodes should be expanded");
        addInfo("2) A Frame with 'CollapseID' button should be displayed");
        addInfo("3) Click the 'CollapseID' button and the 'Historical Figures' should be collapsed");
        addInfo("4) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        CollapseIDTestClass testPanel = new CollapseIDTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("JHelpIndexNavigator.collapseID(target)");
        setTimeout(600);
    }


    /**
     * Help class with JHelpIndexNavigator construction and JFrame for collapseID button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class CollapseIDTestClass extends Applet implements ActionListener {
        private JButton collapseIDButton = null;
        private JHelpIndexNavigator jhIndexNavigator = null;

        public CollapseIDTestClass() {
            try {
                //create a HelpSet object ... start
                HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
                //create a HelpSet object ... end

                //create a HelpModel object ... start
                HelpModel helpmodel = new DefaultHelpModel(hs);
                //create a HelpModel object ... end

                //get a JHelpIndexNavigator ... start
                jhIndexNavigator = (JHelpIndexNavigator)hs.getNavigatorView("Index").createNavigator(helpmodel);
                //get a JHelpIndexNavigator ... end

                //create JFrame with previously created JHelpIndexNavigator and show it ... start
                JFrame frame = new JFrame("JHelpIndexNavigator.collapseID(target)");
                frame.getContentPane().add(jhIndexNavigator);
                frame.setResizable(true);
                frame.pack();
                frame.setSize(220, 400);
                frame.show();
                //create JFrame with previously created JHelpIndexNavigator and show it ... end

                //create a collapseIDButton and setup action listener for it ... start
                collapseIDButton = new JButton("CollapseID");
                collapseIDButton.addActionListener(this);
                //create a collapseIDButton and setup action listener for it ... end

                //setup JFrame with collapseIDButton and show it ... start
                JFrame collapseIDFrame        = new JFrame("CollapseID Frame");
                Container collapseIDContainer = collapseIDFrame.getContentPane();
                collapseIDContainer.setLayout(new FlowLayout() );
                collapseIDContainer.add(collapseIDButton);
                collapseIDFrame.setResizable(false);
                collapseIDFrame.pack();
                collapseIDFrame.show();
                //setup JFrame with collapseIDButton and show it ... end
            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }


        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == collapseIDButton) {
                //collapseID the JHelpIndexNavigator ... start
                jhIndexNavigator.collapseID("hist_figures");
                //collapseID the JHelpIndexNavigator ... end
            }
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.append(master, slave) --> MergeHelpUtilities.append(master, slave)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... append(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class AppendTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public AppendTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        AppendTest test = new AppendTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "appendtest";
        return Status.passed("");
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode append(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void appendtest() {
        addInfo("This test checks 'append(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)' method.");
        addInfo("1) A 'MergeHelpUtilities.append(master, slave) Frame' frame with:");
        addInfo("1a) 'Vertebrates' as master");
        addInfo("1b) 'Invertebrates' as slave should come up");
        addInfo("2) An 'Append Frame' frame with 'Append' button have to come up");
        addInfo("3) Click the 'Append' button");
        addInfo("4a) A 'MergeHelpUtilities.append(master, slave) Final Frame' frame should come up");
        addInfo("4b) In the '... Final Frame' should be appended content of the slave after content of the master node");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        AppendTestClass testPanel = new AppendTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.append(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for append button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class AppendTestClass extends Applet implements ActionListener {
        private JButton appendButton = null;
        private DefaultMutableTreeNode master = null;
        private DefaultMutableTreeNode slave  = null;
        private JFrame finalFrame = null;

        public AppendTestClass() {
            try {
                //create HelpSet objects ... start
                HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
                HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
                //create HelpSet objects ... end

                //get TOCView objects ... start
                TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
                TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
                //get TOCView objects ... end

                //get nodes ... start
                master = (DefaultMutableTreeNode)tocviewmaster.getDataAsTree().getChildAt(0).getChildAt(0);
                slave  = (DefaultMutableTreeNode)tocviewslave.getDataAsTree().getChildAt(0).getChildAt(0);
                //get nodes ... end

                //create JTree objects for displaying the nodes structure ... start
                JTree jtreemaster = new JTree(master);
                JTree jtreeslave  = new JTree(slave);
                //create JTree objects for displaying the nodes structure ... end

                //create a JSplitPane object ... start
                JSplitPane jsplitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                jsplitpane.setDividerLocation((double)0.5);
                jsplitpane.setLeftComponent(jtreemaster);
                jsplitpane.setRightComponent(jtreeslave);
                //create a JSplitPane object ... end

                //display the JTree objects ... start
                JFrame frame = new JFrame("MergeHelpUtilities.append(master, slave) Frame");
                frame.getContentPane().add(jsplitpane);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree objects ... end


                //create a appendButton and setup action listener for it ... start
                appendButton = new JButton("Append");
                appendButton.addActionListener(this);
                //create a appendButton and setup action listener for it ... end

                //setup JFrame with appendButton and show it ... start
                JFrame appendFrame = new JFrame("Append Frame");
                Container backContainer = appendFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(appendButton);
                appendFrame.setResizable(false);
                appendFrame.pack();
                appendFrame.show();
                //setup JFrame with appendButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void append() {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.append(master, slave) Final Frame");
                finalFrame.getContentPane().add(new JTree(MergeHelpUtilities.append(this.master, this.slave)) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == appendButton) {
                //call method for appending a node and display it ... start
                this.append();
                //call method for appending a node and display it ... end
            }
        }
    }

}

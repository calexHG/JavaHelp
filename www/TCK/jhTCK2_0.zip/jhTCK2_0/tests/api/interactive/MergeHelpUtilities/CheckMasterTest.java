/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.checkMaster(master) --> MergeHelpUtilities.checkMaster(master)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.TOCItem;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... checkMaster(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class CheckMasterTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public CheckMasterTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        CheckMasterTest test = new CheckMasterTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "checkmastertest";
        return Status.passed("");
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode checkMaster(javax.swing.tree.DefaultMutableTreeNode master)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void checkmastertest() {
        addInfo("This test checks 'checkMaster(javax.swing.tree.DefaultMutableTreeNode master)' method.");
        addInfo("1) A 'MergeHelpUtilities.checkMaster(master) Frame' frame with tree of 'Pictures' should come up");
        addInfo("2) A 'CheckMaster Frame' frame with 'CheckMaster' button have to come up");
        addInfo("3) Click the 'CheckMaster' button");
        addInfo("4a) A 'MergeHelpUtilities.checkMaster(master) Final Frame' frame should come up");
        addInfo("4b) For the vertebrates && invertebrates:");
        addInfo("4ba) Nodes with same name and same ID should be represented only once");
        addInfo("4bb) Nodes with same name and different ID should be selected with theys HelpSet name ... name in the last prenthises");
        addInfo("6) For the animals should be simply appended nodes from the lower animals node to upper animals node");
        addInfo("7) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        CheckMasterTestClass testPanel = new CheckMasterTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.checkMaster(javax.swing.tree.DefaultMutableTreeNode master, java.util.Locale locale)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for checkMaster button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class CheckMasterTestClass extends Applet implements ActionListener {
        private JButton checkMasterButton = null;
        private DefaultMutableTreeNode master = null;
        private JFrame finalFrame = null;

        public CheckMasterTestClass() {
            try {
                //create a HelpSet object ... start
                HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/animals/Animals3.hs") );
                //create a HelpSet object ... end

                //get a TOCView object ... start
                TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
                //get a TOCView object ... end

                //get a master ... start
                master = (DefaultMutableTreeNode)tocview.getDataAsTree().getFirstChild();
                //get a master ... end

                //create a JTree object for displaying the master structure ... start
                JTree jtree = new JTree(master);
                //create a JTree object for displaying the master structure ... end

                //display the JTree object ... start
                JFrame frame = new JFrame("MergeHelpUtilities.checkMaster(master) Frame");
                frame.getContentPane().add(jtree);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree object ... end

                //create a checkMasterButton and setup action listener for it ... start
                checkMasterButton = new JButton("CheckMaster");
                checkMasterButton.addActionListener(this);
                //create a checkMasterButton and setup action listener for it ... end

                //setup JFrame with checkMasterButton and show it ... start
                JFrame checkMasterFrame = new JFrame("CheckMaster Frame");
                Container backContainer = checkMasterFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(checkMasterButton);
                checkMasterFrame.setResizable(false);
                checkMasterFrame.pack();
                checkMasterFrame.show();
                //setup JFrame with checkMasterButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void checkMaster() {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.checkMaster(master) Final Frame");
                MergeHelpUtilities.checkMaster(master);
                finalFrame.getContentPane().add(new JTree(master) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == checkMasterButton) {
                //call method for check a master and display it ... start
                this.checkMaster();
                //call method for check a master and display it ... end
            }
        }
    }

}

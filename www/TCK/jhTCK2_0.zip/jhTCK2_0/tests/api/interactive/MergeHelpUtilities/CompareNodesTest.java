/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.compareNodes(master, slave) --> MergeHelpUtilities.compareNodes(master, slave)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... compareNodes(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class CompareNodesTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public CompareNodesTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        CompareNodesTest test = new CompareNodesTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "comparenodestest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void compareNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void comparenodestest() {
        addInfo("This test checks 'compareNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)' method.");
        addInfo("1) A 'MergeHelpUtilities.compareNodes(master, slave) Frame' frame with:");
        addInfo("1a) 'Animal Categories' as master");
        addInfo("1b) 'Animal Categories X' as slave should come up");
        addInfo("2) An 'CompareNodes Frame' frame with 'CompareNodes' button have to come up");
        addInfo("3) Click a 'CompareNodes' button");
        addInfo("4) A 'MergeHelpUtilities.compareNodes(master, slave) Final Frame' frame should come up with nodes by the rules:");
        addInfo("4a) shoud be displayed each node with different ID (a help set name will be added to the end)");
        addInfo("4b) nodes with same name will be added from the master");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        CompareNodesTestClass testPanel = new CompareNodesTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.compareNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for compareNodes button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class CompareNodesTestClass extends Applet implements ActionListener {
        private JButton compareNodesButton = null;
        private DefaultMutableTreeNode master = null;
        private DefaultMutableTreeNode slave  = null;
        private JFrame finalFrame = null;

        public CompareNodesTestClass() {
            try {
                //create HelpSet objects ... start
                HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/animals/Animals1.hs") );
                HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/animals/Animals2.hs") );
                //create HelpSet objects ... end

                //get TOCView objects ... start
                TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
                TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
                //get TOCView objects ... end

                //get nodes ... start
                master = (DefaultMutableTreeNode)tocviewmaster.getDataAsTree().getFirstChild();
                slave  = (DefaultMutableTreeNode)tocviewslave.getDataAsTree().getFirstChild();
                //get nodes ... end

                //create JTree objects for displaying the nodes structure ... start
                JTree jtreemaster = new JTree(master);
                JTree jtreeslave  = new JTree(slave);
                //create JTree objects for displaying the nodes structure ... end

                //create a JSplitPane object ... start
                JSplitPane jsplitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                jsplitpane.setDividerLocation((double)0.5);
                jsplitpane.setLeftComponent(jtreemaster);
                jsplitpane.setRightComponent(jtreeslave);
                //create a JSplitPane object ... end

                //display the JTree objects ... start
                JFrame frame = new JFrame("MergeHelpUtilities.compareNodes(master, slave) Frame");
                frame.getContentPane().add(jsplitpane);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree objects ... end


                //create a compareNodesButton and setup action listener for it ... start
                compareNodesButton = new JButton("CompareNodes");
                compareNodesButton.addActionListener(this);
                //create a compareNodesButton and setup action listener for it ... end

                //setup JFrame with compareNodesButton and show it ... start
                JFrame compareNodesFrame = new JFrame("CompareNodes Frame");
                Container backContainer = compareNodesFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(compareNodesButton);
                compareNodesFrame.setResizable(false);
                compareNodesFrame.pack();
                compareNodesFrame.show();
                //setup JFrame with compareNodesButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void compareNodes() {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.compareNodes(master, slave) Final Frame");
                MergeHelpUtilities.compareNodes(this.master, this.slave);
                finalFrame.getContentPane().add(new JTree(this.master) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == compareNodesButton) {
                //call method for handling equal nodes and display it ... start
                this.compareNodes();
                //call method for handling equal nodes and display it ... end
            }
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.handleEqualNodes(master, slave) --> MergeHelpUtilities.handleEqualNodes(master, slave)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... handleEqualNodes(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class HandleEqualNodesTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public HandleEqualNodesTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        HandleEqualNodesTest test = new HandleEqualNodesTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "handleequalnodestest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void handleEqualNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void handleequalnodestest() {
        addInfo("This test checks 'handleEqualNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)' method.");
        addInfo("1) A 'MergeHelpUtilities.handleEqualNodes(master, slave) Frame' frame with:");
        addInfo("1a) 'Animal Categories' as master");
        addInfo("1b) 'Animal Categories X' as slave should come up");
        addInfo("2) An 'HandleEqualNodes Frame' frame with 'HandleEqualNodes' button have to come up");
        addInfo("3) Click a 'HandleEqualNodes' button");
        addInfo("4) A 'MergeHelpUtilities.handleEqualNodes(master, slave) Final Frame' frame should come up with nodes by the rules:");
        addInfo("4a) shoud be displayed each node with different ID (a help set name will be added to the end)");
        addInfo("4b) shoud be displayed each node with different name");
        addInfo("4c) same nodes will be added from the master");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        HandleEqualNodesTestClass testPanel = new HandleEqualNodesTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.handleEqualNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for handleEqualNodes button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class HandleEqualNodesTestClass extends Applet implements ActionListener {
        private JButton handleEqualNodesButton = null;
        private DefaultMutableTreeNode master = null;
        private DefaultMutableTreeNode slave  = null;
        private JFrame finalFrame = null;

        public HandleEqualNodesTestClass() {
            try {
                //create HelpSet objects ... start
                HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/animals/Animals1.hs") );
                HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/animals/Animals2.hs") );
                //create HelpSet objects ... end

                //get TOCView objects ... start
                TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
                TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
                //get TOCView objects ... end

                //get nodes ... start
                master = (DefaultMutableTreeNode)tocviewmaster.getDataAsTree().getFirstChild();
                slave  = (DefaultMutableTreeNode)tocviewslave.getDataAsTree().getFirstChild();
                //get nodes ... end

                //create JTree objects for displaying the nodes structure ... start
                JTree jtreemaster = new JTree(master);
                JTree jtreeslave  = new JTree(slave);
                //create JTree objects for displaying the nodes structure ... end

                //create a JSplitPane object ... start
                JSplitPane jsplitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                jsplitpane.setDividerLocation((double)0.5);
                jsplitpane.setLeftComponent(jtreemaster);
                jsplitpane.setRightComponent(jtreeslave);
                //create a JSplitPane object ... end

                //display the JTree objects ... start
                JFrame frame = new JFrame("MergeHelpUtilities.handleEqualNodes(master, slave) Frame");
                frame.getContentPane().add(jsplitpane);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree objects ... end


                //create a handleEqualNodesButton and setup action listener for it ... start
                handleEqualNodesButton = new JButton("HandleEqualNodes");
                handleEqualNodesButton.addActionListener(this);
                //create a handleEqualNodesButton and setup action listener for it ... end

                //setup JFrame with handleEqualNodesButton and show it ... start
                JFrame handleEqualNodesFrame = new JFrame("HandleEqualNodes Frame");
                Container backContainer = handleEqualNodesFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(handleEqualNodesButton);
                handleEqualNodesFrame.setResizable(false);
                handleEqualNodesFrame.pack();
                handleEqualNodesFrame.show();
                //setup JFrame with handleEqualNodesButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void handleEqualNodes() {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.handleEqualNodes(master, slave) Final Frame");
                MergeHelpUtilities.handleEqualNodes(this.master, this.slave);
                finalFrame.getContentPane().add(new JTree(this.master) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == handleEqualNodesButton) {
                //call method for handling equal nodes and display it ... start
                this.handleEqualNodes();
                //call method for handling equal nodes and display it ... end
            }
        }
    }

}

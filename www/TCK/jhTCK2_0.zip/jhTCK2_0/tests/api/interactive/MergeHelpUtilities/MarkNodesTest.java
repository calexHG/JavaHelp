/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.markNodes(master, slave) --> MergeHelpUtilities.markNodes(master, slave)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... markNodes(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class MarkNodesTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public MarkNodesTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        MarkNodesTest test = new MarkNodesTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "marknodestest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void markNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void marknodestest() {
        addInfo("This test checks 'markNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)' method.");
        addInfo("1) A 'MergeHelpUtilities.markNodes(master, slave) Frame' frame with:");
        addInfo("1a) 'Pictures' as master");
        addInfo("1b) 'Pistures' as slave should come up");
        addInfo("note) In the name 'Pistures' in not whole and is continued by '...', please collapse and expand this node");
        addInfo("2) An 'MarkNodes Frame' frame with 'MarkNodes' button have to come up");
        addInfo("3) Click a 'MarkNodes' button");
        addInfo("4a) A 'MergeHelpUtilities.markNodes(master, slave) Final Frame' frame should come up");
        addInfo("4b) In the '... Final Frame' should be marked root node by its help set name (Vertebrates)");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        MarkNodesTestClass testPanel = new MarkNodesTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.markNodes(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for markNodes button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class MarkNodesTestClass extends Applet implements ActionListener {
        private JButton markNodesButton = null;
        private DefaultMutableTreeNode master = null;
        private DefaultMutableTreeNode slave  = null;
        private JFrame finalFrame = null;

        public MarkNodesTestClass() {
            try {
                //create HelpSet objects ... start
                HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
                HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
                //create HelpSet objects ... end

                //get TOCView objects ... start
                TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
                TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
                //get TOCView objects ... end

                //get nodes ... start
                master = (DefaultMutableTreeNode)tocviewmaster.getDataAsTree().getChildAt(0).getChildAt(1);
                slave  = (DefaultMutableTreeNode)tocviewslave.getDataAsTree().getChildAt(0).getChildAt(1);
                //get nodes ... end

                //create JTree objects for displaying the nodes structure ... start
                JTree jtreemaster = new JTree(master);
                JTree jtreeslave  = new JTree(slave);
                //create JTree objects for displaying the nodes structure ... end

                //create a JSplitPane object ... start
                JSplitPane jsplitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                jsplitpane.setDividerLocation((double)0.5);
                jsplitpane.setLeftComponent(jtreemaster);
                jsplitpane.setRightComponent(jtreeslave);
                //create a JSplitPane object ... end

                //display the JTree objects ... start
                JFrame frame = new JFrame("MergeHelpUtilities.markNodes(master, slave) Frame");
                frame.getContentPane().add(jsplitpane);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree objects ... end


                //create a markNodesButton and setup action listener for it ... start
                markNodesButton = new JButton("MarkNodes");
                markNodesButton.addActionListener(this);
                //create a markNodesButton and setup action listener for it ... end

                //setup JFrame with markNodesButton and show it ... start
                JFrame markNodesFrame = new JFrame("MarkNodes Frame");
                Container backContainer = markNodesFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(markNodesButton);
                markNodesFrame.setResizable(false);
                markNodesFrame.pack();
                markNodesFrame.show();
                //setup JFrame with markNodesButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void markNodes() {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.markNodes(master, slave) Final Frame");
                MergeHelpUtilities.markNodes(this.master, this.slave);
                finalFrame.getContentPane().add(new JTree(this.master) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == markNodesButton) {
                //call method for marking a node and display it ... start
                this.markNodes();
                //call method for marking a node and display it ... end
            }
        }
    }

}

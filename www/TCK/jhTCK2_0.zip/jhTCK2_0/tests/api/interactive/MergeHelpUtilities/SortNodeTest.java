/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.sortNode(node, locale) --> MergeHelpUtilities.sortNode(node, locale)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import java.util.Locale;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... sortNode(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SortNodeTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SortNodeTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        SortNodeTest test = new SortNodeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "sortnodetest";
        return Status.passed("");
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode sortNode(javax.swing.tree.DefaultMutableTreeNode node, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void sortnodetest() {
        addInfo("This test checks 'sortNode(javax.swing.tree.DefaultMutableTreeNode node, java.util.Locale locale)' method.");
        addInfo("1) A 'MergeHelpUtilities.sortNode(node, locale) Frame' frame with tree of 'Pictures' should come up");
        addInfo("2) A 'SortNode Frame' frame with 'SortNode' button have to come up");
        addInfo("3) Click the 'SortNode' button");
        addInfo("4a) A 'MergeHelpUtilities.sortNode(node, locale) Final Frame' frame should come up");
        addInfo("4b) In the '... Final Frame' should be canonically sorted nodes ... by last name in the parenthesis");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        SortNodeTestClass testPanel = new SortNodeTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("MergeHelpUtilities.sortNode(javax.swing.tree.DefaultMutableTreeNode node, java.util.Locale locale)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for sortNode button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class SortNodeTestClass extends Applet implements ActionListener {
        private JButton sortNodeButton = null;
        private DefaultMutableTreeNode node = null;
        private JFrame finalFrame = null;

        public SortNodeTestClass() {
            try {
                //create a HelpSet object ... start
                HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
                //create a HelpSet object ... end

                //get a TOCView object ... start
                TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
                //get a TOCView object ... end

                //get a node ... start
                node = (DefaultMutableTreeNode)tocview.getDataAsTree().getChildAt(0).getChildAt(1);
                //get a node ... end

                //create a JTree object for displaying the node structure ... start
                JTree jtree = new JTree(node);
                //create a JTree object for displaying the node structure ... end

                //display the JTree object ... start
                JFrame frame = new JFrame("MergeHelpUtilities.sortNode(node, locale) Frame");
                frame.getContentPane().add(jtree);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree object ... end


                //create a sortNodeButton and setup action listener for it ... start
                sortNodeButton = new JButton("SortNode");
                sortNodeButton.addActionListener(this);
                //create a sortNodeButton and setup action listener for it ... end

                //setup JFrame with sortNodeButton and show it ... start
                JFrame sortNodeFrame = new JFrame("SortNode Frame");
                Container backContainer = sortNodeFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(sortNodeButton);
                sortNodeFrame.setResizable(false);
                sortNodeFrame.pack();
                sortNodeFrame.show();
                //setup JFrame with sortNodeButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void sortNode(DefaultMutableTreeNode node, Locale locale) {
            if(finalFrame == null) {
                finalFrame = new JFrame("MergeHelpUtilities.sortNode(node, locale) Final Frame");
                finalFrame.getContentPane().add(new JTree(MergeHelpUtilities.sortNode(node, locale)) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == sortNodeButton) {
                //call method for sorting a node and display it ... start
                this.sortNode(node, Locale.getDefault() );
                //call method for sorting a node and display it ... end
            }
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... PrintSetupAction(control).actionPerformed(event) --> PrintSetupAction(control).actionPerformed(event)
 */

package javasoft.sqe.tests.api.javax.help.PrintSetupAction;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.JHelp;
import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.PrintSetupAction;

import javax.swing.JFrame;
import javax.swing.JButton;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.PrintSetupAction ... actionPerformed(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class ActionPerformedTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public ActionPerformedTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        ActionPerformedTest test = new ActionPerformedTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "actionperformedtest";
        return Status.passed("");
    }


    /**
     * Method test: <code>void clear()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void actionperformedtest() {
        addInfo("This test checks actionPerformed(java.awt.event.ActionEvent event) method.");
        addInfo("1) A PrintSetup dialog have to come up");
        addInfo("2) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        ActionPerformedTestClass testPanel = new ActionPerformedTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("PrintSetupAction.actionPerformed(java.awt.event.ActionEvent event)");
        setTimeout(600);
    }



    /**
     * Help class with JFrame for actionPerformed button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class ActionPerformedTestClass extends Applet implements ActionListener {
        private JButton printSetupButton = null;
        private PrintSetupAction printSetupAction = null;

        public ActionPerformedTestClass() {
            try {
                //create a HelpSet object ... start
                HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
                //create a HelpSet object ... end

                //create a JHelp object ... start
                JHelp jhelp = new JHelp(hs);
                //create a JHelp object ... end

                //set an current ID to HelpSet object ... start
                ID currentID = ID.create("aprilfools", hs);
                jhelp.setCurrentID(currentID);
                //set an current ID to HelpSet object ... end

                //create a PrintSetupAction object ... start
                this.printSetupAction = new PrintSetupAction(jhelp);
                //create a PrintSetupAction object ... end

                //create a printSetupButton and setup action listener for it ... start
                printSetupButton = new JButton("PrintSetup");
                printSetupButton.addActionListener(this);
                //create a printSetupButton and setup action listener for it ... end

                //setup JFrame with printSetupButton and show it ... start
                JFrame printSetupFrame        = new JFrame("PrintSetup Frame");
                Container printSetupContainer = printSetupFrame.getContentPane();
                printSetupContainer.setLayout(new FlowLayout() );
                printSetupContainer.add(printSetupButton);
                printSetupFrame.setResizable(false);
                printSetupFrame.pack();
                printSetupFrame.show();
                //setup JFrame with printSetupButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }


        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == printSetupButton) {
                //perform action for PrintSetupAction ... start
                printSetupAction.actionPerformed(event);
                //perform action for PrintSetupAction ... end
            }
        }
    }


}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SortMerge.processMerge(node) --> SortMerge.processMerge(node)
 */

package javasoft.sqe.tests.api.javax.help.SortMerge;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Panel;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.applet.Applet;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.SortMerge;

import javax.swing.JTree;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSplitPane;

import javax.swing.tree.DefaultMutableTreeNode;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.InteractiveTest;

/**
 * Tests for javax.help.SortMerge ... processMerge(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class ProcessMergeTest extends InteractiveTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public ProcessMergeTest() {
        super("YesNo");
    }

    public static void main(String argv[]) {
        ProcessMergeTest test = new ProcessMergeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }

    protected Status init(String[] args) {
        testCases = new String[1];
        testCases[0] = "processmergetest";
        return Status.passed("");
    }


    /**
     * Method test: <code>javax.swing.tree.TreeNode processMerge(javax.swing.tree.TreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public void processmergetest() {
        addInfo("This test checks 'processMerge(node)' method.");
        addInfo("1) A 'SortMerge.processMerge(node) Frame' frame with:");
        addInfo("1a) 'Animal Categories' as master");
        addInfo("1b) 'Animal Categories' as slave should come up");
        addInfo("2) An 'ProcessMerge Frame' frame with 'ProcessMerge' button have to come up");
        addInfo("3) Click a 'ProcessMerge' button");
        addInfo("4) A 'SortMerge.processMerge(node) Final Frame' frame should come up");
        addInfo("4a) In the '... Final Frame' should be appended slave after master");
        addInfo("4b) Should be removed all duplicated nodes ('Pictures')");
        addInfo("4c) Should be sorted all levels of the tree structure");
        addInfo("4d) Should not be sorted 'Wolves' nodes, because the merge type for this folder is append");
        addInfo("4e) (check it by expanding nodes)");
        addInfo("5) Click 'Yes', if the functionality is OK otherwise click 'No' button");
        ProcessMergeTestClass testPanel = new ProcessMergeTestClass();
        addTestPanel((java.awt.Panel)testPanel);

        setStatusMessages("OK", "Did not work");
        setFrameTitle("SortMerge.processMerge(javax.swing.tree.TreeNode node)");
        setTimeout(600);
    }


    /**
     * Help class with JFrame for processMerge button
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    class ProcessMergeTestClass extends Applet implements ActionListener {
        private JButton processMergeButton = null;
        private DefaultMutableTreeNode node = null;
        private SortMerge sortmerge = null;
        private JFrame finalFrame = null;

        public ProcessMergeTestClass() {
            try {
                //create HelpSet objects ... start
                HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
                HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
                //create HelpSet objects ... end

                //get TOCView objects ... start
                TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
                TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
                //get TOCView objects ... end

                //create an SortMerge object ... start
                sortmerge = new SortMerge(tocviewmaster, tocviewslave);
                //create an SortMerge object ... end

                //get nodes ... start
                DefaultMutableTreeNode master = (DefaultMutableTreeNode)tocviewmaster.getDataAsTree();
                DefaultMutableTreeNode slave  = (DefaultMutableTreeNode)tocviewslave.getDataAsTree();
                node = master;
                //get nodes ... end

                //create JTree objects for displaying the nodes structure ... start
                JTree jtreemaster = new JTree(master);
                JTree jtreeslave  = new JTree(slave);
                //create JTree objects for displaying the nodes structure ... end

                //create a JSplitPane object ... start
                JSplitPane jsplitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
                jsplitpane.setDividerLocation((double)0.5);
                jsplitpane.setLeftComponent(jtreemaster);
                jsplitpane.setRightComponent(jtreeslave);
                //create a JSplitPane object ... end

                //display the JTree objects ... start
                JFrame frame = new JFrame("SortMerge.processMerge(node) Frame");
                frame.getContentPane().add(jsplitpane);
                frame.setResizable(true);
                frame.pack();
                frame.show();
                //display the JTree objects ... end


                //create a processMergeButton and setup action listener for it ... start
                processMergeButton = new JButton("ProcessMerge");
                processMergeButton.addActionListener(this);
                //create a processMergeButton and setup action listener for it ... end

                //setup JFrame with processMergeButton and show it ... start
                JFrame processMergeFrame = new JFrame("ProcessMerge Frame");
                Container backContainer = processMergeFrame.getContentPane();
                backContainer.setLayout(new FlowLayout() );
                backContainer.add(processMergeButton);
                processMergeFrame.setResizable(false);
                processMergeFrame.pack();
                processMergeFrame.show();
                //setup JFrame with processMergeButton and show it ... end

            } catch (Exception exc) {
                exc.printStackTrace();
                return;
            }
        }

        private void processMerge() {
            if(finalFrame == null) {
                finalFrame = new JFrame("SortMerge.processMerge(node) Final Frame");
                finalFrame.getContentPane().add(new JTree(sortmerge.processMerge(this.node)) );
                finalFrame.setResizable(true);
                finalFrame.pack();
                finalFrame.show();
            }

        }

        public void actionPerformed(ActionEvent event) {
            if(event.getSource() == processMergeButton) {
                //call method for sortinging a node and display it ... start
                this.processMerge();
                //call method for sortinging a node and display it ... end
            }
        }
    }

}

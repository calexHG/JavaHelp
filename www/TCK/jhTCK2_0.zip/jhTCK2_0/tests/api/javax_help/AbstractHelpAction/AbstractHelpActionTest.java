/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name) --> FooAbstractHelpAction(control, name)
 * testCase2 ... AbstractHelpAction(control, name) --> FooAbstractHelpAction(null, name)
 * testCase3 ... AbstractHelpAction(control, name) --> FooAbstractHelpAction(control, null)
 * testCase4 ... AbstractHelpAction(control, name) --> FooAbstractHelpAction(null, null)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.FooAbstractHelpAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... AbstractHelpAction(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class AbstractHelpActionTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public AbstractHelpActionTest() {
    }

    public static void main(String argv[]) {
        AbstractHelpActionTest test = new AbstractHelpActionTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>AbstractHelpAction(java.lang.Object control, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> valid value
     * @param <code>name</code>    valid value
     */
    public Status testCase1() {
        String apiTested = "AbstractHelpAction(java.lang.Object control, java.lang.String name): "
            + "TestCase: Construct with: 'control == valid; name == valid' "
            + "ExpectedResult: FooAbstractHelpAction object with given values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            Object object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end


            if(object instanceof FooAbstractHelpAction) { //is instance of FooAbstractHelpAction class
                if (control.equals(((FooAbstractHelpAction)object).getControl()) ) { //control value is correct
                    //if (name.equals(((FooAbstractHelpAction)object).getControl()) ) {
                        return Status.passed(apiTested + "OK");
                    //} else {
                    //}
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object with correct 'control' object: original: " + control + " obtained: " + ((FooAbstractHelpAction)object).getControl() );
                }
            } else { //is instance of FooAbstractHelpAction class
                return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>AbstractHelpAction(java.lang.Object control, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> <code>null</code> value
     * @param <code>name</code>    valid value
     */
    public Status testCase2() {
        String apiTested = "AbstractHelpAction(java.lang.Object control, java.lang.String name): "
            + "TestCase: Construct with: 'control == null; name == valid' "
            + "ExpectedResult: FooAbstractHelpAction object with given values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = null;
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            Object object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end


            if(object instanceof FooAbstractHelpAction) { //is instance of FooAbstractHelpAction class
                if (control == ((FooAbstractHelpAction)object).getControl() ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object with correct 'control' object: original: " + control + " obtained: " + ((FooAbstractHelpAction)object).getControl() );
                }
            } else { //is instance of FooAbstractHelpAction class
                return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>AbstractHelpAction(java.lang.Object control, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> valid value
     * @param <code>name</code>    <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "AbstractHelpAction(java.lang.Object control, java.lang.String name): "
            + "TestCase: Construct with: 'control == valid; name == null' "
            + "ExpectedResult: FooAbstractHelpAction object with given values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = null;
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            Object object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end


            if(object instanceof FooAbstractHelpAction) { //is instance of FooAbstractHelpAction class
                if (control.equals(((FooAbstractHelpAction)object).getControl()) ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object with correct 'control' object: original: " + control + " obtained: " + ((FooAbstractHelpAction)object).getControl() );
                }
            } else { //is instance of FooAbstractHelpAction class
                return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>AbstractHelpAction(java.lang.Object control, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> <code>null</code> value
     * @param <code>name</code>    <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "AbstractHelpAction(java.lang.Object control, java.lang.String name): "
            + "TestCase: Construct with: 'control == null; name == null' "
            + "ExpectedResult: FooAbstractHelpAction object with given values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = null;
            String name = null;
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            Object object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end


            if(object instanceof FooAbstractHelpAction) { //is instance of FooAbstractHelpAction class
                if (control == ((FooAbstractHelpAction)object).getControl() ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object with correct 'control' object: original: " + control + " obtained: " + ((FooAbstractHelpAction)object).getControl() );
                }
            } else { //is instance of FooAbstractHelpAction class
                return Status.failed(apiTested + "Did not construct FooAbstractHelpAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


}

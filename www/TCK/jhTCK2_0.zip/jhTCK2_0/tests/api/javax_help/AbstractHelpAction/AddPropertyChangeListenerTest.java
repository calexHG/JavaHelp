/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name).addPropertyChangeListener(l) --> FooAbstractHelpAction(control, name).addPropertyChangeListener(l)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import java.beans.PropertyChangeEvent;

import javax.help.AbstractHelpAction;
import javax.help.FooAbstractHelpAction;
import javax.help.FooAbstractHelpAction.FooPropertyChangeListener;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... addPropertyChangeListener(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class AddPropertyChangeListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public AddPropertyChangeListenerTest() {
    }

    public static void main(String argv[]) {
        AddPropertyChangeListenerTest test = new AddPropertyChangeListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void addPropertyChangeListener(java.beans.PropertyChangeListener l)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>l</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void addPropertyChangeListener(java.beans.PropertyChangeListener l): "
            + "TestCase: '(new AbstractHelpAction(control, name)).addPropertyChangeListener(l)' "
            + "ExpectedResult: Add 'l' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test add method by fire an property change; it should be mirrored in the 'listener' ... start
            String propertyName = new String("propertyName");
            Object oldValue = new Object();
            Object newValue = new Object();
            object.firePropertyChange(propertyName, oldValue, newValue);
            //test add method by fire an property change; it should be mirrored in the 'listener' ... end


            if ((l.getEvent() != null) && propertyName.equals(l.getEvent().getPropertyName()) && oldValue.equals(l.getEvent().getOldValue()) && newValue.equals(l.getEvent().getNewValue()) ) {
                return Status.passed(apiTested + "Added 'l'");
            } else {
                return Status.failed(apiTested + "Did not add 'l'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

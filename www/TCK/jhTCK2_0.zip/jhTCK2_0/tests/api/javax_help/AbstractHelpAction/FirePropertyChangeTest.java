/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, newValue) --> FooAbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, newValue)
 * testCase2 ... AbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, newValue) --> FooAbstractHelpAction(control, name).firePropertyChange(null, oldValue, newValue)
 * testCase3 ... AbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, newValue) --> FooAbstractHelpAction(control, name).firePropertyChange(propertyName, null, newValue)
 * testCase4 ... AbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, newValue) --> FooAbstractHelpAction(control, name).firePropertyChange(propertyName, oldValue, null)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import java.beans.PropertyChangeEvent;

import javax.help.AbstractHelpAction;
import javax.help.FooAbstractHelpAction;
import javax.help.FooAbstractHelpAction.FooPropertyChangeListener;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... firePropertyChange(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class FirePropertyChangeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public FirePropertyChangeTest() {
    }

    public static void main(String argv[]) {
        FirePropertyChangeTest test = new FirePropertyChangeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>propertyName</code> valid value
     * @param <code>oldValue</code>     valid value
     * @param <code>newValue</code>     valid value
     */
    public Status testCase1() {
        String apiTested = "void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue): "
            + "TestCase: '(new AbstractHelpAction(control, name)).firePropertyChange(propertyName, oldValue, newValue)' "
            + "ExpectedResult: Fire event with correct values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test fire method; it should be mirrored in the 'listener' ... start
            String propertyName = new String("propertyName");
            Object oldValue = new Object();
            Object newValue = new Object();
            object.firePropertyChange(propertyName, oldValue, newValue);
            //test fire method; it should be mirrored in the 'listener' ... end


            if ((l.getEvent() != null) && propertyName.equals(l.getEvent().getPropertyName()) && oldValue.equals(l.getEvent().getOldValue()) && newValue.equals(l.getEvent().getNewValue()) ) {
                return Status.passed(apiTested + "OK");
            } else {
                return Status.failed(apiTested + "Did not fire event with correct values");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>propertyName</code> <code>null</code> value
     * @param <code>oldValue</code>     valid value
     * @param <code>newValue</code>     valid value
     */
    public Status testCase2() {
        String apiTested = "void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue): "
            + "TestCase: '(new AbstractHelpAction(control, name)).firePropertyChange(null, oldValue, newValue)' "
            + "ExpectedResult: Fire event with correct values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test fire method; it should be mirrored in the 'listener' ... start
            String propertyName = null;
            Object oldValue = new Object();
            Object newValue = new Object();
            object.firePropertyChange(propertyName, oldValue, newValue);
            //test fire method; it should be mirrored in the 'listener' ... end


            if ((l.getEvent() != null) && propertyName == l.getEvent().getPropertyName() && oldValue.equals(l.getEvent().getOldValue()) && newValue.equals(l.getEvent().getNewValue()) ) {
                return Status.passed(apiTested + "OK");
            } else {
                return Status.failed(apiTested + "Did not fire event with correct values");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>propertyName</code> valid value
     * @param <code>oldValue</code>     <code>null</code> value
     * @param <code>newValue</code>     valid value
     */
    public Status testCase3() {
        String apiTested = "void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue): "
            + "TestCase: '(new AbstractHelpAction(control, name)).firePropertyChange(propertyName, null, newValue)' "
            + "ExpectedResult: Fire event with correct values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test fire method; it should be mirrored in the 'listener' ... start
            String propertyName = new String("propertyName");
            Object oldValue = null;
            Object newValue = new Object();
            object.firePropertyChange(propertyName, oldValue, newValue);
            //test fire method; it should be mirrored in the 'listener' ... end


            if ((l.getEvent() != null) && propertyName.equals(l.getEvent().getPropertyName()) && oldValue == l.getEvent().getOldValue() && newValue.equals(l.getEvent().getNewValue()) ) {
                return Status.passed(apiTested + "OK");
            } else {
                return Status.failed(apiTested + "Did not fire event with correct values");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>propertyName</code> valid value
     * @param <code>oldValue</code>     valid value
     * @param <code>newValue</code>     <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue): "
            + "TestCase: '(new AbstractHelpAction(control, name)).firePropertyChange(propertyName, oldValue, null)' "
            + "ExpectedResult: Fire event with correct values "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test fire method; it should be mirrored in the 'listener' ... start
            String propertyName = new String("propertyName");
            Object oldValue = new Object();
            Object newValue = null;
            object.firePropertyChange(propertyName, oldValue, newValue);
            //test fire method; it should be mirrored in the 'listener' ... end


            if ((l.getEvent() != null) && propertyName.equals(l.getEvent().getPropertyName()) && oldValue.equals(l.getEvent().getOldValue()) && newValue == l.getEvent().getNewValue() ) {
                return Status.passed(apiTested + "OK");
            } else {
                return Status.failed(apiTested + "Did not fire event with correct values");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

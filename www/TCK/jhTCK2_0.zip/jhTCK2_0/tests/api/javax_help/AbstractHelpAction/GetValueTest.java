/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name).getValue(key) --> FooAbstractHelpAction(control, name).getValue(invalid)
 * testCase2 ... AbstractHelpAction(control, name).getValue(key) --> FooAbstractHelpAction(control, name).getValue(invalid)
 * testCase3 ... AbstractHelpAction(control, name).getValue(key) --> FooAbstractHelpAction(control, name).getValue(key)
 * testCase4 ... AbstractHelpAction(control, name).getValue(key) --> FooAbstractHelpAction(control, name).getValue(null)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.AbstractHelpAction;
import javax.help.FooAbstractHelpAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... getValue(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetValueTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetValueTest() {
    }

    public static void main(String argv[]) {
        GetValueTest test = new GetValueTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.lang.Object getValue(java.lang.String key)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>key</code> invalid value
     */
    public Status testCase1() {
        String apiTested = "java.lang.Object getValue(java.lang.String key): "
            + "TestCase: '(new AbstractHelpAction(control, name)).getValue(invalid)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //testing key value ... start
            String keyInvalid = new String("keyInvalid");
            //testing key value ... end


            if(null == object.getValue(keyInvalid) ) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + object.getValue(keyInvalid) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.Object getValue(java.lang.String key)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>key</code> invalid value
     */
    public Status testCase2() {
        String apiTested = "java.lang.Object getValue(java.lang.String key): "
            + "TestCase: '(new AbstractHelpAction(control, name)).putValue(key, newValue).getValue(invalid)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create variables for the putValue() method ... start
            Object newValue = new Object();
            String key = new String("key");
            //create variables for the putValue() method ... end

            //put the values to the 'object' ... start
            object.putValue(key, newValue);
            //put the values to the 'object' ... end

            //testing key value ... start
            String keyInvalid = new String("keyInvalid");
            //testing key value ... end


            if(null == object.getValue(keyInvalid) ) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + object.getValue(keyInvalid) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.Object getValue(java.lang.String key)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>key</code> valid value
     */
    public Status testCase3() {
        String apiTested = "java.lang.Object getValue(java.lang.String key): "
            + "TestCase: '(new AbstractHelpAction(control, name)).putValue(key, newValue).getValud(key)' "
            + "ExpectedResult: 'newValue' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create variables for the putValue() method ... start
            Object newValue = new Object();
            String key = new String("key");
            //create variables for the putValue() method ... end

            //put the values to the 'object' ... start
            object.putValue(key, newValue);
            //put the values to the 'object' ... end


            if(newValue.equals(object.getValue(key)) ) {
                return Status.passed(apiTested + "Got 'newValue'");
            } else {
                return Status.failed(apiTested + "Did not get 'newValue': " + object.getValue(key) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.Object getValue(java.lang.String key)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>key</code> <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "java.lang.Object getValue(java.lang.String key): "
            + "TestCase: '(new AbstractHelpAction(null, name)).putValue(key, newValue).getValue(null)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = null;
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create variables for the putValue() method ... start
            Object newValue = new Object();
            String key = new String("key");
            //create variables for the putValue() method ... end

            //put the values to the 'object' ... start
            object.putValue(key, newValue);
            //put the values to the 'object' ... end

            //testing key value ... start
            String keynull = null;
            //testing key value ... end

            object.getValue(keynull);


            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

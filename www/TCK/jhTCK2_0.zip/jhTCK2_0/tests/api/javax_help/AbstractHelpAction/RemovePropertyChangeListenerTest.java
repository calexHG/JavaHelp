/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name).removePropertyChangeListener(l) --> FooAbstractHelpAction(control, name).removePropertyChangeListener(l)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import java.beans.PropertyChangeEvent;

import javax.help.AbstractHelpAction;
import javax.help.FooAbstractHelpAction;
import javax.help.FooAbstractHelpAction.FooPropertyChangeListener;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... removePropertyChangeListener(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class RemovePropertyChangeListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public RemovePropertyChangeListenerTest() {
    }

    public static void main(String argv[]) {
        RemovePropertyChangeListenerTest test = new RemovePropertyChangeListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void removePropertyChangeListener(java.beans.PropertyChangeListener l)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>l</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void removePropertyChangeListener(java.beans.PropertyChangeListener l): "
            + "TestCase: '(new AbstractHelpAction(control, name)).removePropertyChangeListener(l)' "
            + "ExpectedResult: Remove 'l' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            FooAbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //create testing listener ... start
            FooPropertyChangeListener l = object.new FooPropertyChangeListener();
            //create testing listener ... end

            //add the listener ... start
            object.addPropertyChangeListener(l);
            //add the listener ... end

            //test add method by fire an property change; it should be mirrored in the 'listener' ... start
            String propertyName1 = new String("propertyName");
            Object oldValue1 = new Object();
            Object newValue1 = new Object();
            object.firePropertyChange(propertyName1, oldValue1, newValue1);
            //test add method by fire an property change; it should be mirrored in the 'listener' ... end

            //remove the listener ... start
            object.removePropertyChangeListener(l);
            //remove the listener ... end

            //test remove method by fire an property change; it should not be mirrored in the 'listener' ... start
            String propertyName2 = new String("propertyName");
            Object oldValue2 = new Object();
            Object newValue2 = new Object();
            object.firePropertyChange(propertyName2, oldValue2, newValue2);
            //test remove method by fire an property change; it should not be mirrored in the 'listener' ... end

            //add listener
            //setup values1
            //remove listener
            //setup values2
            //the listener have to have values1


            if ((l.getEvent() != null) && propertyName1.equals(l.getEvent().getPropertyName()) && oldValue1.equals(l.getEvent().getOldValue()) && newValue1.equals(l.getEvent().getNewValue()) ) {
                return Status.passed(apiTested + "Removed 'l'");
            } else {
                return Status.failed(apiTested + "Did not remove 'l'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

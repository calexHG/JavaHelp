/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AbstractHelpAction(control, name).setEnabled(enabled) --> FooAbstractHelpAction(control, name).setEnabled(true)
 * testCase2 ... AbstractHelpAction(control, name).setEnabled(enabled) --> FooAbstractHelpAction(control, name).setEnabled(false)
 * testCase3 ... AbstractHelpAction(control, name).setEnabled(enabled) --> FooAbstractHelpAction(null, name).setEnabled(true)
 * testCase4 ... AbstractHelpAction(control, name).setEnabled(enabled) --> FooAbstractHelpAction(null, name).setEnabled(false)
 *
 * All tests in this class are done through FooAbstractHelpAction class ... workaround for abstract class
 */

package javasoft.sqe.tests.api.javax.help.AbstractHelpAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.AbstractHelpAction;
import javax.help.FooAbstractHelpAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AbstractHelpAction ... setEnabled(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetEnabledTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetEnabledTest() {
    }

    public static void main(String argv[]) {
        SetEnabledTest test = new SetEnabledTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void setEnabled(boolean enabled)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>enabled</code> <code>true</code>
     */
    public Status testCase1() {
        String apiTested = "void setEnabled(boolean enabled): "
            + "TestCase: '(new AbstractHelpAction(control, name)).setEnabled(true)' "
            + "ExpectedResult: Set 'true' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //set enabled value ... start
            object.setEnabled(true);
            //set enabled value ... end


            if(object.isEnabled() ) {
                return Status.passed(apiTested + "Set 'true'");
            } else {
                return Status.failed(apiTested + "Did not set 'true': " + object.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setEnabled(boolean enabled)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>enabled</code> <code>false</code>
     */
    public Status testCase2() {
        String apiTested = "void setEnabled(boolean enabled): "
            + "TestCase: '(new AbstractHelpAction(control, name)).setEnabled(false)' "
            + "ExpectedResult: Set 'false' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = new Object();
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //set enabled value ... start
            object.setEnabled(false);
            //set enabled value ... end


            if(object.isEnabled() ) {
                return Status.failed(apiTested + "Did not set 'flase': " + object.isEnabled() );
            } else {
                return Status.passed(apiTested + "Set 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setEnabled(boolean enabled)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>enabled</code> <code>true</code>
     */
    public Status testCase3() {
        String apiTested = "void setEnabled(boolean enabled): "
            + "TestCase: '(new AbstractHelpAction(null, name)).setEnabled(true)' "
            + "ExpectedResult: Set 'true' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = null;
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //set enabled value ... start
            object.setEnabled(true);
            //set enabled value ... end


            if(object.isEnabled() ) {
                return Status.passed(apiTested + "Set 'true'");
            } else {
                return Status.failed(apiTested + "Did not set 'true': " + object.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setEnabled(boolean enabled)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>enabled</code> <code>false</code>
     */
    public Status testCase4() {
        String apiTested = "void setEnabled(boolean enabled): "
            + "TestCase: '(new AbstractHelpAction(null, name)).setEnabled(false)' "
            + "ExpectedResult: Set 'false' "
            + "ObtainedResult: ";

        try {
            //set the necessary variables ... start
            Object control = null;
            String name = new String("FooAbstractHelpAction");
            //set the necessary variables ... end

            //create a FooAbstractHelpAction object ... start
            AbstractHelpAction object = new FooAbstractHelpAction(control, name);
            //create a FooAbstractHelpAction object ... end

            //set enabled value ... start
            object.setEnabled(false);
            //set enabled value ... end


            if(object.isEnabled() ) {
                return Status.failed(apiTested + "Did not set 'flase': " + object.isEnabled() );
            } else {
                return Status.passed(apiTested + "Set 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

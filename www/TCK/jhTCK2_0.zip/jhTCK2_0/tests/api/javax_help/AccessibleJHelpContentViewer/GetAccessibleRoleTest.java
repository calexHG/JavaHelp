/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... AccessibleJHelpContentViewer(...).getAccessibleRole() --> JHelpContentViewer(...).getAccessibleContext().getAcdcessibleRole()
 */

package javasoft.sqe.tests.api.javax.help.AccessibleJHelpContentViewer;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.JHelpContentViewer;

import javax.accessibility.AccessibleRole;
import javax.accessibility.AccessibleContext;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer.AccessibleJHelpContentViewer ... getAccessibleRole()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetAccessibleRoleTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetAccessibleRoleTest() {
    }

    public static void main(String argv[]) {
        GetAccessibleRoleTest test = new GetAccessibleRoleTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.accessibility.AccessibleRole getAccessibleRole()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "javax.accessibility.AccessibleRole getAccessibleRole(): "
            + "TestCase: '(new JHelpContentViewer()).getAccessibleContext().getAccessibleRole()' "
            + "ExpectedResult: Return 'AccessibleRole.PANEL' "
            + "ObtainedResult: ";

        try {
            //create JHelpContentViewer object ... start
            JHelpContentViewer jhviewer = new JHelpContentViewer();
            //create JHelpContentViewer object ... end


            if(jhviewer.getAccessibleContext().getAccessibleRole().equals(AccessibleRole.PANEL) ) {
                return Status.passed(apiTested + "Returned 'AccessibleRole.PANEL'");
            } else {
                return Status.failed(apiTested + "Did not return 'AccessibleRole.PANEL'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

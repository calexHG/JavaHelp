/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCaseN ... AppendMerge(master, slave) --> AppendMerge(master, slave)
 * testCaseN ... AppendMerge(master, slave) --> AppendMerge(master, null)
 * testCaseN ... AppendMerge(master, slave) --> AppendMerge(null, slave)
 */

package javasoft.sqe.tests.api.javax.help.AppendMerge;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.help.HelpSet;
import javax.help.NavigatorView;
import javax.help.AppendMerge;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.AppendMerge ... AppendMerge(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class AppendMergeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public AppendMergeTest() {
    }

    public static void main(String argv[]) {
        AppendMergeTest test = new AppendMergeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  valid value
     */
    public Status testCase1() {
        String apiTested = "AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave): "
            + "TestCase: Construct with: 'master == valid; slave == valid' "
            + "ExpectedResult: AppendMerge object with given values "
            + "ObtainedResult: ";

        try {
            // //create necessary NavigatorView objects ... start

            //create a master NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView master = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a master NavigatorView object ... end

            //create a slave NavigatorView object ... start
            hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView slave = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a slave NavigatorView object ... end

            // //create necessary NavigatorView objects ... end

            //create a AppendMerge object ... start
            Object merge = new AppendMerge(master, null);
            //create a AppendMerge object ... end

            if (merge instanceof AppendMerge) { //is instance of AppendMerge class
                return Status.passed(apiTested + "OK");
            } else { //is not instance of AppendMerge class
                return Status.failed(apiTested + "Did not construct AppendMerge object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave): "
            + "TestCase: Construct with: 'master == valid; slave == null' "
            + "ExpectedResult: AppendMerge object with given values "
            + "ObtainedResult: ";

        try {
            // //create necessary NavigatorView objects ... start

            //create a master NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView master = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a master NavigatorView object ... end

            //create a slave NavigatorView object ... start
            NavigatorView slave = null;
            //create a slave NavigatorView object ... end

            // //create necessary NavigatorView objects ... end

            //create a AppendMerge object ... start
            Object merge = new AppendMerge(master, slave);
            //create a AppendMerge object ... end

            if (merge instanceof AppendMerge) { //is instance of AppendMerge class
                return Status.passed(apiTested + "OK");
            } else { //is not instance of AppendMerge class
                return Status.failed(apiTested + "Did not construct AppendMerge object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> <code>null</code> value
     * @param <code>slave</code>  valid value
     */
    public Status testCase3() {
        String apiTested = "AppendMergeTest(javax.help.NavigatorView master, javax.help.NavigatorView slave): "
            + "TestCase: Construct with: 'master == null; slave == valid' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            // //create necessary NavigatorView objects ... start

            //create a master NavigatorView object ... start
            NavigatorView master = null;
            //create a master NavigatorView object ... end

            //create a slave NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView slave = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a slave NavigatorView object ... end

            // //create necessary NavigatorView objects ... end

            //create a AppendMerge object ... start
            Object merge = new AppendMerge(master, slave);
            //create a AppendMerge object ... end


            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

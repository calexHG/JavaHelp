/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... BackAction(control) --> BackAction(control)
 * testCase2 ... BackAction(control) --> BackAction(null)
 */

package javasoft.sqe.tests.api.javax.help.BackAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.BackAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.BackAction ... BackAction(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class BackActionTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public BackActionTest() {
    }

    public static void main(String argv[]) {
        BackActionTest test = new BackActionTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>BackAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> valid value
     */
    public Status testCase1() {
        String apiTested = "BackAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == valid' "
            + "ExpectedResult: BackAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new BackAction object ... start
            Object control = new Object();
            Object object = new BackAction(control);
            //create new BackAction object ... end

            if(object instanceof BackAction) { //is instance of BackAction class
                if (control.equals(((BackAction)object).getControl()) ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct BackAction object with correct 'control' object: original: " + control + " obtained: " + ((BackAction)object).getControl() );
                }
            } else { //is instance of BackAction class
                return Status.failed(apiTested + "Did not construct BackAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>BackAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "BackAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == null' "
            + "ExpectedResult: BackAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new BackAction object ... start
            Object control = null;
            Object object = new BackAction(control);
            //create new BackAction object ... end

            if(object instanceof BackAction) { //is instance of BackAction class
                if (control == ((BackAction)object).getControl() ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct BackAction object with correct 'control' object: original: " + control + " obtained: " + ((BackAction)object).getControl() );
                }
            } else { //is instance of BackAction class
                return Status.failed(apiTested + "Did not construct BackAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... CSH.addManager(m) --> CSH.addManager(m)
 * testCase2 ... CSH.addManager(m) --> CSH.addManager(null)
 *
 * testCase3 ... CSH.addManager(i, m) --> CSH.addManager(i, m)
 * testCase4 ... CSH.addManager(i, m) --> CSH.addManager(i, null)
 * testCase5 ... CSH.addManager(i, m) --> CSH.addManager(invalid, m)
 * testCase6 ... CSH.addManager(i, m) --> CSH.addManager(invalid, m)
 */

package javasoft.sqe.tests.api.javax.help.CSH;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.CSH;
import javax.help.CSH.Manager;

import com.sun.help.jck.harness.FooCSHManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.CSH ... addManager(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class AddManagerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public AddManagerTest() {
    }

    public static void main(String argv[]) {
        AddManagerTest test = new AddManagerTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void addManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void addManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(m)' "
            + "ExpectedResult: Add 'm' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(m);
            //add a manager ... end


            if(m.equals(CSH.getManager(0)) ) {
                return Status.passed(apiTested + "Added 'm'");
            } else {
                return Status.failed(apiTested + "Did not add 'm': " + CSH.getManager(0) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void addManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "void addManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(null)' "
            + "ExpectedResult: Add 'null' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = null;
            CSH.addManager(m);
            //add a manager ... end


            if(m == CSH.getManager(0) ) {
                return Status.passed(apiTested + "Added 'null'");
            } else {
                return Status.failed(apiTested + "Did not add 'null': " + CSH.getManager(0) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void addManager(int i, javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> valid value
     * @param <code>m</code> valid value
     */
    public Status testCase3() {
        String apiTested = "void addManager(int i, javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(1, m)' "
            + "ExpectedResult: Add 'm' at 'i' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            CSH.addManager(new FooCSHManager() );
            Manager m = new FooCSHManager();
            int i = 1;
            CSH.addManager(i, m);
            //add a manager ... end


            if(m.equals(CSH.getManager(i)) ) {
                return Status.passed(apiTested + "Added 'm' at 'i'");
            } else {
                return Status.failed(apiTested + "Did not add 'm' at 'i': " + CSH.getManager(i) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void addManager(int i, javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> valid value
     * @param <code>m</code> <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "void addManager(int i, javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(1, null)' "
            + "ExpectedResult: Add 'null' at 'i' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            CSH.addManager(new FooCSHManager() );
            Manager m = null;
            int i = 1;
            CSH.addManager(i, m);
            //add a manager ... end


            if(m == CSH.getManager(i) ) {
                return Status.passed(apiTested + "Added 'null' at 'i'");
            } else {
                return Status.failed(apiTested + "Did not add 'null' at 'i': " + CSH.getManager(i) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void addManager(int i, javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     * @param <code>m</code> valid value
     */
    public Status testCase5() {
        String apiTested = "void addManager(int i, javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(-1, m)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            CSH.addManager(new FooCSHManager() );
            Manager m = new FooCSHManager();
            int i = -1;
            CSH.addManager(i, m);
            //add a manager ... end


            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void addManager(int i, javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     * @param <code>m</code> valid value
     */
    public Status testCase6() {
        String apiTested = "void addManager(int i, javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.addManager(10, m)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            CSH.addManager(new FooCSHManager() );
            Manager m = new FooCSHManager();
            int i = 10;
            CSH.addManager(i, m);
            //add a manager ... end


            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

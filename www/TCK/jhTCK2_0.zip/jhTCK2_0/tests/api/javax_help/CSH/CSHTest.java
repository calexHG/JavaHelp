/*
* @(#)CSHTest.java	1.2 01/08/06
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.CSH;
import java.io.PrintWriter;
import java.lang.reflect.*;
import java.util.Hashtable;
import javax.help.*;
import javax.help.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Component;
import java.net.URL;
import javax.help.Map.ID;
import java.util.Stack;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.CSH
* Constructor Test
* Create a CSH
*
* @author Sudhakar.Adini
*/
public class CSHTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CSHTest() {
        
    }
    
    public static void main(String argv[]) {
        CSHTest test = new CSHTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Constructor: CSHTest()" 
        	+ "\nTestCase : Call CSHTest()  " 
        	+ "\nExpected Result :It should  Construct CSH object" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            if(csh instanceof CSH) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not Construct CSH object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
}

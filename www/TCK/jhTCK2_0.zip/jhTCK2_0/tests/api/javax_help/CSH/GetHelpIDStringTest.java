/*
* @(#)GetHelpIDStringTest.java	1.2 01/08/06
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.CSH;
import java.io.PrintWriter;
import java.lang.reflect.*;
import java.util.Hashtable;
import javax.help.HelpSet;
import javax.help.CSH;
import java.lang.ClassLoader;
import javax.help.event.*;
import java.awt.MenuItem;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Button;
import java.net.URL;
import javax.help.Map.ID;
import java.util.Stack;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.CSH
* Method: getHelpIDString(Component comp) & 
* Method: getHelpIDString(MenuItem comp)
*
* @author Sudhakar.Adini
*/
public class GetHelpIDStringTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpIDStringTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHelpIDStringTest test = new GetHelpIDStringTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: getHelpIDString(Component comp)" 
        	+ "\nTestCase : Call getHelpIDString(Component comp) " 
        	+ "\nExpected Result :It should return the HelpIDString" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();            
            Button comp = new Button("OK");
            String s = "OKAY";
            CSH.setHelpIDString(comp, s);
            String s1 = CSH.getHelpIDString(comp);
            if(s1.equals(s)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not return HelpIDString");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
    
    public Status testCase2() {
        String apiTested = " Method: getHelpIDString(Component comp)" 
        	+ "\nTestCase : Call getHelpIDString with  comp as null  " 
       		+ "\nExpected Result :NullPoiterException should be thrown." 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();           
            Button comp = new Button("OK");
            Button comp1 = null;
            String s = "OKAY";
            CSH.setHelpIDString(comp, s);
            String s1 = CSH.getHelpIDString(comp1);
            if(s1.equals(s)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return HelpIDString");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got NullPoiterException ");
            }
            else {
                return Status.failed(apiTested + "Got OtherException : " 
                	+ e.toString());
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = " Method: getHelpIDString(MenuItem comp)" 
        	+ "\nTestCase : Call getHelpIDString(MenuItem comp)  " 
        	+ "\nExpected Result :It should return the HelpIDString" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();           
            MenuItem comp = new MenuItem("OK");
            String s = "OKAY";
            CSH.setHelpIDString(comp, s);
            String s1 = CSH.getHelpIDString(comp);
            if(s1.equals(s)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return HelpIDString");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase3 finished	
    
    public Status testCase4() {
        String apiTested = " Method: getHelpIDString(MenuItem comp)" 
        	+ "\nTestCase : Call getHelpIDString with  comp as null  " 
        	+ "\nExpected Result :NullPoiterException should be thrown." 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();            
            MenuItem comp = new MenuItem("OK");
            Button comp1 = null;
            String s = "OKAY";
            CSH.setHelpIDString(comp, s);
            String s1 = CSH.getHelpIDString(comp1);
            if(s1.equals(s)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return HelpIDString");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got NullPoiterException ");
            }
            else {
                return Status.failed(apiTested + "Got OtherException : " 
                	+ e.toString());
            }
        }
    } //testCase4 finished		
}

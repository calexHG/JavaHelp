/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... CSH.getManagerCount() --> CSH.getManagerCount()
 * testCase2 ... CSH.addManager(...).addManager(...).getManagerCount() --> CSH.addManager(...).addManager(...).getManagerCount()
 */

package javasoft.sqe.tests.api.javax.help.CSH;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.CSH;
import javax.help.CSH.Manager;

import com.sun.help.jck.harness.FooCSHManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.CSH ... getManagerCount()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetManagerCountTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetManagerCountTest() {
    }

    public static void main(String argv[]) {
        GetManagerCountTest test = new GetManagerCountTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>int getManagerCount()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "int getManagerCount(): "
            + "TestCase: 'CSH.getManagerCount()' "
            + "ExpectedResult: '0' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens


            if(CSH.getManagerCount() == 0) {
                return Status.passed(apiTested + "'0'");
            } else {
                return Status.failed(apiTested + "Did not get '0': " + CSH.getManagerCount() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>int getManagerCount()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "int getManagerCount(): "
            + "TestCase: 'CSH.addManager(...).addManager(...).getManagerCount()' "
            + "ExpectedResult: '2' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add new managers ... start
            CSH.addManager(new FooCSHManager() );
            CSH.addManager(new FooCSHManager() );
            //add new managers ... end


            if(CSH.getManagerCount() == 2) {
                return Status.passed(apiTested + "'2'");
            } else {
                return Status.failed(apiTested + "Did not get '2': " + CSH.getManagerCount() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

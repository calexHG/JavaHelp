/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... CSH.getManager(i) --> CSH.getManager(i)
 * testCase2 ... CSH.getManager(i) --> CSH.getManager(i???)
 * testCase3 ... CSH.getManager(i) --> CSH.getManager(invlid)
 * testCase4 ... CSH.getManager(i) --> CSH.getManager(invlid)
 */

package javasoft.sqe.tests.api.javax.help.CSH;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.CSH;
import javax.help.CSH.Manager;

import com.sun.help.jck.harness.FooCSHManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.CSH ... getManager(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetManagerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetManagerTest() {
    }

    public static void main(String argv[]) {
        GetManagerTest test = new GetManagerTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.help.CSH.Manager getManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> valid value
     */
    public Status testCase1() {
        String apiTested = "javax.help.CSH.Manager getManager(int i): "
            + "TestCase: 'CSH.addManager(...).getManager(i)' "
            + "ExpectedResult: 'm' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(m);
            //add a manager ... end

            int pos = 0;

            if(m.equals(CSH.getManager(pos)) ) {
                return Status.passed(apiTested + "Got 'm'");
            } else {
                return Status.failed(apiTested + "Did not get 'm': " + CSH.getManager(pos) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager getManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     */
    public Status testCase2() {
        String apiTested = "javax.help.CSH.Manager getManager(int i): "
            + "TestCase: 'CSH.getManager(0)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //get a manager ... start
            Manager m = CSH.getManager(0);
            //get a manager ... end

            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager getManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     */
    public Status testCase3() {
        String apiTested = "javax.help.CSH.Manager getManager(int i): "
            + "TestCase: 'CSH.getManager(-1)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            //add a manager ... end

            //get a manager ... start
            Manager m = CSH.getManager(-1);
            //get a manager ... end

            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager getManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     */
    public Status testCase4() {
        String apiTested = "javax.help.CSH.Manager getManager(int i): "
            + "TestCase: 'CSH.getManager(1)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            //add a manager ... end

            //get a manager ... start
            Manager m = CSH.getManager(1);
            //get a manager ... end

            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... CSH.getManagers() --> CSH.getManagers()
 * testCase2 ... CSH.getManagers() --> CSH.getManagers() ... over empty managers set
 */

package javasoft.sqe.tests.api.javax.help.CSH;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.CSH;
import javax.help.CSH.Manager;

import com.sun.help.jck.harness.FooCSHManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.CSH ... removeManager(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetManagersTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetManagersTest() {
    }

    public static void main(String argv[]) {
        GetManagersTest test = new GetManagersTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.help.CSH.Manager[] getManager()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "javax.help.CSH.Manager[] getManagers(): "
            + "TestCase: 'CSH.getManagers()' "
            + "ExpectedResult: 'm[n]' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add managers ... start
            Manager m1 = new FooCSHManager();
            Manager m2 = new FooCSHManager();
            CSH.addManager(m1);
            CSH.addManager(m2);
            //add managers ... end

            Manager m[] = CSH.getManagers();

            if (m.length != 2) {
                return Status.failed(apiTested + "Did not get array of Managrs with correct length: expectedLength '2'" + " gotLength '" + m.length + "'");
            }

            if(m[0].equals(m1) && m[1].equals(m2) ) {
                return Status.passed(apiTested + "Got 'm[n]'");
            } else {
                return Status.failed(apiTested + "Did not get 'm[n]': " + CSH.getManagers() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager[] getManager()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "javax.help.CSH.Manager[] getManagers(): "
            + "TestCase: 'CSH.getManagers()' "
            + "ExpectedResult: 'm[0]' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            Manager m[] = CSH.getManagers();


            if(m.length == 0 ) {
                return Status.passed(apiTested + "Got 'm[0]'");
            } else {
                return Status.failed(apiTested + "Did not get 'm[0]': " + CSH.getManagers() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

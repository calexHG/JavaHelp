/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... CSH.removeManager(m) --> CSH.removeManager(m)
 * testCase2 ... CSH.removeManager(m) --> CSH.removeManager(invalid)
 * testCase3 ... CSH.removeManager(m) --> CSH.removeManager(null) ... does not exist in the managers set
 * testCase4 ... CSH.removeManager(m) --> CSH.removeManager(null) ... exist in the managers set
 * testCase5 ... CSH.removeManager(m) --> CSH.removeManager(m) ... over empty managers set
 *
 * testCase6 ... CSH.removeManager(i) --> CSH.removeManager(i)
 * testCase7 ... CSH.removeManager(i) --> CSH.removeManager(invalid)
 * testCase8 ... CSH.removeManager(i) --> CSH.removeManager(invalid)
 * testCase9 ... CSH.removeManager(i) --> CSH.removeManager(invalid) ... over empty managers set
 */

package javasoft.sqe.tests.api.javax.help.CSH;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.CSH;
import javax.help.CSH.Manager;

import com.sun.help.jck.harness.FooCSHManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.CSH ... removeManager(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class RemoveManagerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public RemoveManagerTest() {
    }

    public static void main(String argv[]) {
        RemoveManagerTest test = new RemoveManagerTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>boolean removeManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> valid value
     */
    public Status testCase1() {
        String apiTested = "boolean removeManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.removeManager(m)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(m);
            //add a manager ... end


            if(CSH.removeManager(m) && CSH.getManagerCount() == 0) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + CSH.removeManager(m) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean removeManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> invalid value
     */
    public Status testCase2() {
        String apiTested = "boolean removeManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.removeManager(m)' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(new FooCSHManager() );
            //add a manager ... end


            if(CSH.removeManager(m) ) {
                return Status.failed(apiTested + "Did not get 'false': " + CSH.removeManager(m) );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean removeManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> <code>null</code> value ... does not exist in the managers set
     */
    public Status testCase3() {
        String apiTested = "boolean removeManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.removeManager(null)' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(new FooCSHManager() );
            //add a manager ... end


            if(CSH.removeManager(null) ) {
                return Status.failed(apiTested + "Did not get 'false': " + CSH.removeManager(null) );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean removeManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> <code>null</code> value ... exist in the managers set
     */
    public Status testCase4() {
        String apiTested = "boolean removeManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.removeManager(null)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            CSH.addManager(null);
            //add a manager ... end


            if(CSH.removeManager(null) && CSH.getManagerCount() == 0) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + CSH.removeManager(null) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean removeManager(javax.help.CSH.Manager m)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>m</code> valid value  ... over empty managers set
     */
    public Status testCase5() {
        String apiTested = "boolean removeManager(javax.help.CSH.Manager m): "
            + "TestCase: 'CSH.removeManager(m)' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            Manager m = new FooCSHManager();


            if(CSH.removeManager(m) ) {
                return Status.failed(apiTested + "Did not get 'false': " + CSH.removeManager(m) );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager addManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> valid value
     */
    public Status testCase6() {
        String apiTested = "javax.help.CSH.Manager addManager(int i): "
            + "TestCase: 'CSH.removeManager(i)' "
            + "ExpectedResult: Remove 'm' at 'i' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m1 = new FooCSHManager();
            Manager m2 = new FooCSHManager();
            CSH.addManager(m1);
            CSH.addManager(m2);
            //add a manager ... end

            //remove one of the managers ... start
            CSH.removeManager(0);
            //remove one of the managers ... end


            if(CSH.getManagerCount() == 1 && m2.equals(CSH.getManager(0)) ) {
                return Status.passed(apiTested + "Removed 'm' at 'i'");
            } else {
                return Status.failed(apiTested + "Did not remove 'm' at 'i'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


   /**
     * Method test: <code>javax.help.CSH.Manager addManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     */
    public Status testCase7() {
        String apiTested = "javax.help.CSH.Manager addManager(int i): "
            + "TestCase: 'CSH.removeManager(-1)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(m);
            //add a manager ... end

            CSH.removeManager(-1);


            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager addManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value
     */
    public Status testCase8() {
        String apiTested = "javax.help.CSH.Manager addManager(int i): "
            + "TestCase: 'CSH.removeManager(10)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            //add a manager ... start
            Manager m = new FooCSHManager();
            CSH.addManager(m);
            //add a manager ... end

            CSH.removeManager(10);


            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.CSH.Manager addManager(int i)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>i</code> invalid value ... over empty managers set
     */
    public Status testCase9() {
        String apiTested = "javax.help.CSH.Manager addManager(int i): "
            + "TestCase: 'CSH.removeManager(0)' "
            + "ExpectedResult: 'java.lang.ArrayIndexOutOfBoundsException' "
            + "ObtainedResult: ";

        try {
            //remove all current managers ... this is necessary, because all methods for managers are static ... start
            CSH.removeAllManagers();
            //remove all current managers ... this is necessary, because all methods for managers are static ... ens

            CSH.removeManager(0);


            return Status.failed(apiTested + "Did not get 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (ArrayIndexOutOfBoundsException exc) {
            return Status.passed(apiTested + "Got 'java.lang.ArrayIndexOutOfBoundsException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

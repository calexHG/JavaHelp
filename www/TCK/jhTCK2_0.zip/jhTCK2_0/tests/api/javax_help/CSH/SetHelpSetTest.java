/*
* @(#)SetHelpSetTest.java	1.2 99/03/10
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.CSH;
import java.io.PrintWriter;
import java.lang.reflect.*;
import java.util.Hashtable;
import javax.help.HelpSet;
import javax.help.CSH;
import java.lang.ClassLoader;
import javax.help.event.*;
import java.awt.MenuItem;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Button;
import java.net.URL;
import javax.help.Map.ID;
import java.util.Stack;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.CSH
* Method: setHelpSet(Component comp,HelpSet hs) &
* Method: setHelpSet(MenuItem comp,HelpSet hs)
*
* @author Sudhakar.Adini
*/
public class SetHelpSetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetHelpSetTest() {
        
    }
    
    public static void main(String argv[]) {
        SetHelpSetTest test = new SetHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: setHelpSet(Component comp,HelpSet hs)" 
        	+ "\nTestCase :Call setHelpSet with valid values for comp & hs" 
        	+ "\nExpected Result :It should set the helpset" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            Button comp = new Button("OK");
            CSH.setHelpSet(comp, hs);
            CSH.setHelpIDString(comp, "OkAY");
            HelpSet hs1 = CSH.getHelpSet(comp);
            if(hs1.equals(hs)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
    
    public Status testCase2() {
        String apiTested = " Method: setHelpSet(Component comp,HelpSet hs)" 
        	+ "\nTestCase : Call setHelpSet(null,HelpSet hs) "
        	+ "\nExpected Result :IllegalArgumentException should be thrown" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            Button comp = null;
            CSH.setHelpSet(comp, hs);
            HelpSet hs1 = CSH.getHelpSet(comp);
            if(hs1 == hs) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            if(e instanceof IllegalArgumentException) {
                return Status.passed(apiTested +"Got IllegalArgumentException");
            }
            else {
                return Status.failed(apiTested + "Got Otherexception : " 
                	+ e.toString());
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = " Method: setHelpSet(Component comp,HelpSet hs)" 
        	+ "\nTestCase : Call setHelpSet(Component comp,null) " 
        	+ "\nExpected Result :It should return null" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = null;
            Button comp = new Button("OK");
            CSH.setHelpSet(comp, hs);
            CSH.setHelpIDString(comp, "OkAY");
            HelpSet hs1 = CSH.getHelpSet(comp);
            if(hs1 == hs) {
                return Status.passed(apiTested + hs1 + "   Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = " Method: setHelpSet(MenuItem comp,HelpSet hs)" 
        	+ "\nTestCase : Call setHelpSet with valid values for comp & hs" 
        	+ "\nExpected Result :It should set the helpset" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            MenuItem comp = new MenuItem("OK");
            CSH.setHelpSet(comp, hs);
            CSH.setHelpIDString(comp, "OkAY");
            HelpSet hs1 = CSH.getHelpSet(comp);
            if(hs1.equals(hs)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase4 finished	
    
    public Status testCase5() {
        String apiTested = " Method: setHelpSet(MenuItem comp,HelpSet hs)" 
        	+ "\nTestCase : Call setHelpSet(null,HelpSet hs)" 
        	+ "\nExpected Result : IllegalArgumentException should be thrown" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            MenuItem comp = null;
            CSH.setHelpSet(comp, hs);            
            HelpSet hs1 = CSH.getHelpSet(comp);            
            if(hs1 == hs) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            if(e instanceof IllegalArgumentException) {
                return Status.passed(apiTested +"Got IllegalArgumentException");
            }
            else {
                return Status.failed(apiTested + "Got Otherexception : " 
                	+ e.toString());
            }
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = " Method: setHelpSet(MenuItem comp,HelpSet hs)" 
        	+ "\nTestCase : Call setHelpSet(MenuItem comp,null) " 
        	+ "\nExpected Result :It should return null" 
        	+ "\nObtained Result : ";
        try {
            CSH csh = new CSH();
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = null;
            MenuItem comp = new MenuItem("OK");
            CSH.setHelpSet(comp, hs);
            CSH.setHelpIDString(comp, "OkAY");
            HelpSet hs1 = CSH.getHelpSet(comp);
            if(hs1 == hs) {
                return Status.passed(apiTested + hs1 + "   Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the helpset");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase6 finished
}


/*
* 
* 
* @(#)EnableHelpOnButtonTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;
import java.io.PrintWriter;
import javax.help.DefaultHelpBroker;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import java.net.URL;
import java.awt.Button;
import java.awt.MenuItem;
import javax.swing.JButton;
import java.awt.Label;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpBroker
 *
 *
 
 * @author Ben John.
 */

public class EnableHelpOnButtonTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public EnableHelpOnButtonTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        EnableHelpOnButtonTest test = new EnableHelpOnButtonTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp," 
                           + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelpOnButton(myButton, "myid", hs);
            return Status.passed(apiTested + "Okay");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "raised " + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp," 
                           +" java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Label myLabel = new Label("Help");
            dhbr.enableHelpOnButton(myLabel, "myid", hs);
            return Status.failed(apiTested + " taking Invalid component ");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + "Okay; " + ee 
                + " raised for Invalid component");
            }
            else {
                return Status.failed(apiTested + "raised " + ee);
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp," 
                           + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelpOnButton(myButton, null, hs);
            return Status.failed(apiTested + "Exception not raised for null id.");
        }
        catch(Exception ee) {
			if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + " raised " + ee 
                + "  with null id." );
            }
            else {
                return Status.failed(apiTested + " raised " + ee 
                + "  with null id." );
			}
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp," 
                           + "java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelpOnButton(myButton, "myid", null);
            return Status.passed(apiTested + "Okay for null HelpSet");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Got Exception for null HelpSet :"
             + ee);
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp,"
                           + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = null;
            dhbr.enableHelpOnButton(myButton, "myid", hs);
            return Status.failed(apiTested + "Exception not raised for null component.");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + " raised " + ee 
                + " for null component." );
            }
            else {
                return Status.failed(apiTested + " raised " + ee 
                + " for null component." );
            }
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.MenuItem comp,"
                            + "java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelpOnButton(myMenuItem, "myid", hs);
            return Status.passed(apiTested + "Okay");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Got Exception :" + ee);
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.MenuItem comp,"
                            + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Label myLabel = new Label("Help");
            dhbr.enableHelpOnButton(myLabel, "myid", hs);
            return Status.failed(apiTested + "Okay for Invalid Component.");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + "Okay; " + ee 
                + "  raised for Invalid Component" );
            }
            else {
                return Status.failed(apiTested + "Got wrong  Exception :" + ee);
            }
        }
    } //testCase7 finished
    
    public Status testCase8() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.MenuItem comp,"
                           + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelpOnButton(myMenuItem, null, hs);
            return Status.failed(apiTested + "Exception not raised for null id.");
        }
        catch(Exception ee) {
			if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + " raised " + ee 
	                + "  with null id." );
            }
            else {
                return Status.failed(apiTested + " raised " + ee 
	                + "  with null id." );							          
			}
        }
    } //testCase8 finished
    
    public Status testCase9() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.MenuItem comp,"
                            + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelpOnButton(myMenuItem, "myid", null);
            return Status.passed(apiTested + "Okay for null HelpSet");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Got Exception for null HelpSet :" 
            + ee);
        }
    } //testCase9 finished
    
    public Status testCase10() {
        String apiTested = "Method \"enableHelpOnButton(java.awt.MenuItem comp,"
                            + " java.lang.String id, HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = null;
            dhbr.enableHelpOnButton(myMenuItem, "myid", hs);
            return Status.failed(apiTested + "Exception not raised for null MenuItem");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + "Got Exception for null MenuItem :" 
                + ee);
            }
            else {
                return Status.failed(apiTested + "Got Exception for null MenuItem :" 
                + ee);
            }
        }
    } //testCase10 finished
	
	 public Status testCase11() {
	        String apiTested = "Method \"enableHelpOnButton(java.awt.Component comp," 
	                           + " java.lang.String id, HelpSet hs) \" ";
	        try {
	            ClassLoader loader = this.getClass().getClassLoader();
	            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	            HelpSet hs = new HelpSet(loader, url);
	            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
	            JButton myJButton = new JButton("Help");
	            dhbr.enableHelpOnButton(myJButton, "myid", hs);
	            return Status.passed(apiTested + "Okay for JButton Component");
	        }
	        catch(Exception ee) {
	            return Status.failed(apiTested + "raised for JButton" + ee);
	        }
	    } //testCase11 finished
}

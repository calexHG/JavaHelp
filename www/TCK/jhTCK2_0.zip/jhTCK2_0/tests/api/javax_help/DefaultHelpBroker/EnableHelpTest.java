
/*
* 
* 
* @(#)EnableHelpTest.java	1.3 99/03/10 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;

import java.io.PrintWriter;
import javax.help.DefaultHelpBroker;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import java.net.URL;
import java.awt.MenuItem;
import java.awt.Button;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpBroker
 *
 *
 
 * @author Ben John.
 */

public class EnableHelpTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public EnableHelpTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        EnableHelpTest test = new EnableHelpTest();
        Status s = test.run(argv, new PrintWriter(System.out),
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"enableHelp(java.awt.Component comp,"
                            + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelp(myButton, "myid", hs);
            return Status.passed(apiTested + "Okay");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised :" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \"enableHelp(java.awt.Component comp,"
                            + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = null;
            dhbr.enableHelp(myButton, "Id", hs);
            return Status.failed(apiTested + "No Exception for null component.");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + " raised " + ee 
                + "  with null component." );
            }
            else {
                return Status.failed(apiTested + " raised " + ee 
                + "  with null component." );
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \"enableHelp(java.awt.Component comp,"
                            + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelp(myButton, null, hs);
            return Status.failed(apiTested + "Exception not raised for null id.");
        }
        catch(Exception ee) {
			if(ee instanceof NullPointerException) {
		        return Status.passed(apiTested + " raised " + ee 
		                + "  with null id." );
            }
            else {
                return Status.failed(apiTested + " raised " + ee 
                + "  with null id." );
			}						
            
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \"enableHelp(java.awt.Component comp,"
                           + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            Button myButton = new Button("Help");
            dhbr.enableHelp(myButton, "myid", null);
            return Status.passed(apiTested + "Okay with null HelpSet");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "raised " + ee 
            + " for null HelpSet:" );
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method \"enableHelp(java.awt.MenuItem comp,"
                           + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelp(myMenuItem, "myid", hs);
            return Status.passed(apiTested + "Okay");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised :" + ee);
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = "Method \"enableHelp(java.awt.MenuItem comp,"
                            + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelp(myMenuItem, null, hs);
            return Status.failed(apiTested + "Exception not raised with null id.");
        }
        catch(Exception ee) {
			if(ee instanceof NullPointerException) {
		        return Status.passed(apiTested + " raised " + ee 
                + "  with null id." );
           }
           else {
              return Status.failed(apiTested + " raised " + ee 
                + "  with null id." );
			}						
            
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = "Method \"enableHelp(java.awt.MenuItem comp,"
                           + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = new MenuItem("Help");
            dhbr.enableHelp(myMenuItem, "myid", null);
            return Status.passed(apiTested + "Okay with null HelpSet");
        }
        catch(Exception ee) {
            return Status.failed(apiTested +"Exception raised with null HelpSet" 
            + ee);
        }
    } //testCase7 finished
    
    public Status testCase8() {
        String apiTested = "Method \"enableHelp(java.awt.MenuItem comp," 
                            + " java.lang.String id,HelpSet hs) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            MenuItem myMenuItem = null;
            dhbr.enableHelp(myMenuItem, "myid", hs);
            return Status.failed(apiTested 
            + " return no Exception with null MenuItem");
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested 
                + "Exception raised with null MenuItem" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Exception raised with null MenuItem" + ee);
            }
        }
    } //testCase8 finished
}

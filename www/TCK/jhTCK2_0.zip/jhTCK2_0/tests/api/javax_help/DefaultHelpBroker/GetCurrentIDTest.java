/*
   * %W% %E%
   *
   * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
   *
   * This software is the confidential and proprietary information of Sun
   * Microsystems, Inc. ("Confidential Information").  You shall not
   * disclose such Confidential Information and shall use it only in
   * accordance with the terms of the license agreement you entered into
   * with Sun.
   *
   * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
   * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
   * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
   * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
   * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
   * THIS SOFTWARE OR ITS DERIVATIVES.
   *
   * CopyrightVersion 1.0
   */

  package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;
  import java.io.PrintWriter;

  import javax.help.DefaultHelpBroker;
  import javax.help.HelpSet;
  import javax.help.Map;
  import javax.help.FlatMap;
  import javax.help.BadIDException;

  import java.net.URL;
  import java.awt.MenuItem;
  import java.awt.Button;

  import javasoft.sqe.javatest.Status;
  import javasoft.sqe.javatest.lib.MultiTest;

  /**
    * Tests for javax.javahelp.DefaultHelpBroker
    *
    *

    * @author Ben John.
    */

  public class GetCurrentIDTest extends MultiTest {

      public static String HSLOC = System.getProperty("HS_LOC");
      public GetCurrentIDTest(){//constructor
      }

      public static void main(String argv[]) {
          GetCurrentIDTest test  = new GetCurrentIDTest();

          Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
          s.exit();
      }



      public Status testCase1() {
            String   apiTested = "Method \"getCurrentID() \" ";
            DefaultHelpBroker dhbr=null;
          try{
              ClassLoader loader = this.getClass().getClassLoader();
              URL url = new URL("file", null, HSLOC +"/merge/Master.hs" );
              HelpSet mhs = new HelpSet(loader, url);

              url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs" );
              HelpSet hs = new HelpSet(loader, url);

              mhs.add(hs);

              dhbr = new DefaultHelpBroker(mhs);

              dhbr.setCurrentID("ben");
              return Status.failed(apiTested 
              + "Didn't throw exception for Invalid String id");
          } catch (Exception ee) {
              if (ee instanceof BadIDException) {
                  return Status.passed (apiTested 
                  + "Got a valid Exception thrown for an invalid  id to set." 
                  + ee + " Okay");
              } else {
                  return Status.failed (apiTested 
                  + "Didn't throw proper exception for Invalid String id");
              }
          }
          finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
      } //testCase1 finished

          public Status testCase2() {
          String   apiTested = "Method \" getCurrentID() \" ";
          DefaultHelpBroker dhbr=null;
          try{
              ClassLoader loader = this.getClass().getClassLoader();
              URL url = new URL("file", null, HSLOC +"/merge/Master.hs" );
              HelpSet mhs = new HelpSet(loader, url);

              url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs" );
              HelpSet hs = new HelpSet(loader, url);

              mhs.add(hs);
              dhbr = new DefaultHelpBroker(mhs);
              dhbr.setCurrentID("halloween");
			  if(( dhbr.getCurrentID() instanceof Map.ID) 
			  	&& (dhbr.getCurrentID().id.equals("halloween")))
                  return Status.passed (apiTested + "Okay for String id set"); 
              else
                  return Status.failed(apiTested+"Didn't return valid object");
          } catch (Exception ee) {
              ee.printStackTrace();
              return Status.failed (apiTested + "Got Exception :" + ee);
          }
          finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
      } //testCase2 finished

      public Status testCase3() {
          String   apiTested = "Method \" getCurrentID() \" ";
          DefaultHelpBroker dhbr=null;
          try{
              ClassLoader loader = this.getClass().getClassLoader();
              URL url = new URL("file", null, HSLOC +"/merge/Master.hs" );
              HelpSet mhs = new HelpSet(loader, url);

              url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs" );
              HelpSet hs = new HelpSet(loader, url);

              mhs.add(hs);
              dhbr = new DefaultHelpBroker(mhs);
              Map.ID mid = Map.ID.create("halloween",hs);
              dhbr.setCurrentID(mid);
              if(( dhbr.getCurrentID() instanceof Map.ID) 
			  	&& (dhbr.getCurrentID().equals(mid) ))
                  return Status.passed (apiTested + "Okay for Map.ID set"); 
              else
                  return Status.failed (apiTested+"Didn't return valid object");
          } catch (Exception ee) {
              ee.printStackTrace();
              return Status.failed (apiTested + "Got Exception :" + ee);
          }
          finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
      } //testCase3 finished
  }

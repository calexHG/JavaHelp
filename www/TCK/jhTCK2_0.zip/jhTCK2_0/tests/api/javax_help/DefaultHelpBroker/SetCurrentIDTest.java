
/*
* 
* 
* @(#)SetCurrentIDTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;

import java.io.PrintWriter;
import javax.help.DefaultHelpBroker;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.BadIDException;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpBroker
 *
 *
 
 * @author Ben John.
 */

public class SetCurrentIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetCurrentIDTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        SetCurrentIDTest test = new SetCurrentIDTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"setCurrentID(java.lang.String id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
	    dhbr = new DefaultHelpBroker(hs);
            dhbr.setCurrentID("Ben");
            return Status.failed(apiTested 
            + "Didn't throw exception for Invalid String id");
        }
        catch(Exception ee) {
            if(ee instanceof BadIDException) {
                return Status.passed(apiTested 
                + "Exception raised for invalid id to set." + ee); 
            }
            else {
                return Status.failed(apiTested 
                + "Didn't throw proper exception for Invalid String id" + ee );
            }
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" setCurrentID(java.lang.String id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            HelpSet mhs = new HelpSet(loader, url2);
            mhs.add(hs);
            dhbr = new DefaultHelpBroker(mhs);
            dhbr.setCurrentID("halloween");
	    Map.ID curid = dhbr.getCurrentID();
	    if (curid.id.equals("halloween")) {
                return Status.passed(apiTested + "Okay for Valid Id string.");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for valid ID" 
            + ee);
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \" setCurrentID(Map.ID id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet mhs = new HelpSet(loader, url2);
            mhs.add(hs);
            dhbr = new DefaultHelpBroker(mhs);
            Map.ID mid = Map.ID.create("halloween", hs);
            dhbr.setCurrentID(mid);
	    Map.ID curid = dhbr.getCurrentID();
	    if (curid.equals(mid)) {
                return Status.passed(apiTested + "Okay");
            } else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised :" + ee);
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \" setCurrentID(Map.ID id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            dhbr = new DefaultHelpBroker(hs);
            Map.ID mid = null;
            dhbr.setCurrentID(mid);
            if(dhbr.getCurrentID().equals(hs.getHomeID())) {
                return Status.passed(apiTested + "Okay for null ID");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised :" + ee);
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase4 finished
    
    public Status testCase5() { // InvalidHelpSetContextException
        String apiTested = "Method \" setCurrentID(Map.ID id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            HelpSet hs2 = new HelpSet(loader, url1);
            dhbr = new DefaultHelpBroker(hs);
            Map.ID mid = Map.ID.create("main", hs2);
            dhbr.setCurrentID(mid);
            return Status.failed(apiTested + "javax.help.InvalidHelpSetContextException not raised");
        }
        catch(Exception ee) {
            if(ee instanceof javax.help.InvalidHelpSetContextException) {
                return Status.passed(apiTested 
                + "Exception Raised for Invalid Helpset id." + ee);
            }
            else {
                return Status.failed(apiTested + "Exception raised :" + ee);
            }
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase5 finished
    
     public Status testCase6() {
        String apiTested = "Method \"setCurrentID(java.lang.String id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            dhbr = new DefaultHelpBroker(hs);
            String str = null;
            dhbr.setCurrentID(str);
            if(dhbr.getCurrentID().equals(hs.getHomeID())) {
                return Status.passed(apiTested 
               + "Okay for null id.");
            }else {
                return Status.failed(apiTested 
                + "Didn't proper for null String id");
            } 
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
                + "Exception raised for null String id" + ee );
            }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
        
    } //testCase6 finished


	public Status testCase7() {
        String apiTested = "Method \"setCurrentID(java.lang.String id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            HelpSet mhs = new HelpSet(loader, url2);
            mhs.add(hs);
            dhbr = new DefaultHelpBroker(mhs);
            dhbr.setCurrentID("Ben");
            return Status.failed(apiTested 
            + "Didn't throw exception for Invalid String id");
        }
        catch(Exception ee) {
            if(ee instanceof BadIDException) {
                return Status.passed(apiTested 
                + "Exception raised for invalid String id"
					+ " against Merged HelpSet" + ee); 
            }
            else {
                return Status.failed(apiTested 
                + "Didn't throw proper exception for Invalid String id" + ee );
            }
        }
       finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase7 finished    

	public Status testCase8() {  
        String apiTested = "Method \" setCurrentID(Map.ID id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            HelpSet mhs = new HelpSet(loader, url1);
	    mhs.add(hs);
            dhbr = new DefaultHelpBroker(mhs);
            Map.ID mid = Map.ID.create("main", mhs);
            dhbr.setCurrentID(mid);
	    Map.ID curid = dhbr.getCurrentID();
	    if (curid.equals(mid)) {
		return Status.passed(apiTested
				     + "Okay; Valid ID with Merged Helpset");
            }else {
		return Status.failed(apiTested 
				     + "Valid ID with Merged Helpset");
	    }
	}
        catch(Exception ee) {
                return Status.failed(apiTested + "Exception raised " + ee);
        }
       finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase8 finished

    public Status testCase9() {
        String apiTested = "Method \"setCurrentID(java.lang.String id) \" ";
        DefaultHelpBroker dhbr=null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
	    dhbr = new DefaultHelpBroker(hs);
            dhbr.setCurrentID("hal");
            return Status.failed(apiTested 
            + "Didn't throw exception for Invalid String id");
        }
        catch(Exception ee) {
            if(ee instanceof BadIDException) {
                return Status.passed(apiTested 
                + "Exception raised for invalid id to set." + ee); 
            }
            else {
                return Status.failed(apiTested 
                + "Didn't throw proper exception for Invalid String id" + ee );
            }
        }
        finally {
            dhbr.setDisplayed(false);
            dhbr=null;
        }
    } //testCase9 finished
    
	
	
}

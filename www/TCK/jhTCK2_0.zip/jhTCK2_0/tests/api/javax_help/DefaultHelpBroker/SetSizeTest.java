/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... DefaultHelpBroker(hs).setSize(d) --> DefaultHelpBroker(hs).setSize(d[10,10])
 * testCase2 ... DefaultHelpBroker(hs).setSize(d) --> DefaultHelpBroker(hs).setSize(d[0,0])
 * testCase3 ... DefaultHelpBroker(hs).setSize(d) --> DefaultHelpBroker(hs).setSize(null)
 * testCase4 ... DefaultHelpBroker(hs).setSize(d) --> DefaultHelpBroker(hs).setSize(d[-10,-10])
 */

package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Dimension;

import javax.help.HelpSet;
import javax.help.DefaultHelpBroker;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpBroker ... setSize(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetSizeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetSizeTest() {
    }

    public static void main(String argv[]) {
        SetSizeTest test = new SetSizeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>setSize(java.awt.Dimension d)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>d</code> valid value[10,10]
     */
    public Status testCase1() {
        String apiTested = "setSize(java.awt.Dimension d): "
            + "TestCase: '(new DefaultHelpBroker(hs)).setSize(d[10,10])' "
            + "ExpectedResult: Set 'd' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //create DefaultHelpBroker object ... start
            DefaultHelpBroker defaultHelpBroker = new DefaultHelpBroker(hs);
            //create DefaultHelpBroker object ... end

            //set size ... start
            Dimension d = new Dimension(10, 10);
            defaultHelpBroker.setSize(d);
            //set size ... end

            if(d.equals(defaultHelpBroker.getSize()) ) {
                return Status.passed(apiTested + "Set 'd'");
            } else {
                return Status.failed(apiTested + "Did not set 'd': " + defaultHelpBroker.getSize() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSize(java.awt.Dimension d)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>d</code> valid value[0,0]
     */
    public Status testCase2() {
        String apiTested = "setSize(java.awt.Dimension d): "
            + "TestCase: '(new DefaultHelpBroker(hs)).setSize(d[0,0])' "
            + "ExpectedResult: Set 'd' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //create DefaultHelpBroker object ... start
            DefaultHelpBroker defaultHelpBroker = new DefaultHelpBroker(hs);
            //create DefaultHelpBroker object ... end

            //set size ... start
            Dimension d = new Dimension(0, 0);
            defaultHelpBroker.setSize(d);
            //set size ... end

            if(d.equals(defaultHelpBroker.getSize()) ) {
                return Status.passed(apiTested + "Set 'd'");
            } else {
                return Status.failed(apiTested + "Did not set 'd': " + defaultHelpBroker.getSize() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSize(java.awt.Dimension d)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>d</code> <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "setSize(java.awt.Dimension d): "
            + "TestCase: '(new DefaultHelpBroker(hs)).setSize(null)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //create DefaultHelpBroker object ... start
            DefaultHelpBroker defaultHelpBroker = new DefaultHelpBroker(hs);
            //create DefaultHelpBroker object ... end

            //set size ... start
            Dimension d = null;
            defaultHelpBroker.setSize(d);
            //set size ... end

            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSize(java.awt.Dimension d)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>d</code> valid value[-10,-10]
     */
    public Status testCase4() {
        String apiTested = "setSize(java.awt.Dimension d): "
            + "TestCase: '(new DefaultHelpBroker(hs)).setSize(d[-10,-10])' "
            + "ExpectedResult: Set 'd' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //create DefaultHelpBroker object ... start
            DefaultHelpBroker defaultHelpBroker = new DefaultHelpBroker(hs);
            //create DefaultHelpBroker object ... end

            //set size ... start
            Dimension d = new Dimension(-10, -10);
            defaultHelpBroker.setSize(d);
            //set size ... end

            if(d.equals(defaultHelpBroker.getSize()) ) {
                return Status.passed(apiTested + "Set 'd'");
            } else {
                return Status.failed(apiTested + "Did not set 'd': " + defaultHelpBroker.getSize() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}


/*
* 
* 
* @(#)SetViewDisplayedTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultHelpBroker;

import java.io.PrintWriter;
import javax.help.DefaultHelpBroker;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import javax.help.BadIDException;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpBroker
 *
 *
 
 * @author Ben John.
 */

public class SetViewDisplayedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetViewDisplayedTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        SetViewDisplayedTest test = new SetViewDisplayedTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"setViewDisplayed(boolean b) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            dhbr.setViewDisplayed(true);
            if(dhbr.isViewDisplayed()) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid value ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \"setViewDisplayed(boolean b) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            DefaultHelpBroker dhbr = new DefaultHelpBroker(hs);
            dhbr.setViewDisplayed(false);
            if(!(dhbr.isViewDisplayed())) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid value ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised" + ee);
        }
    } //testCase2 finished
}

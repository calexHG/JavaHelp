/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooHelpModelListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.event.HelpModelListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class AddHelpModelListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public AddHelpModelListenerTest() {
        
    }
        
    public static void main(String argv[]) {
        AddHelpModelListenerTest test =
                new AddHelpModelListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "addHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : addHelpModelListener , Call setCurrentURL(url) and " 
        + "check if listener for HelpModelEvent is notified" 
        + "\nExpected Result :idChanged() of HelpModelListener shd be called." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooHelpModelListener l = new FooHelpModelListener();
            defaultHelpModel.addHelpModelListener(l);
            URL url2 = new URL("file", null, HSLOC+"/holidays/hol/thanks.html");
            defaultHelpModel.setCurrentURL(url2);
            
            /* StaticInfo.bool is set to true within idChanged() 
             * of FooHelpModelListener 
             */
            if(StaticInfo.bool == true) {
                return Status.passed(apiTested + "idChanged() of " 
                    + "HelpModelListener is called.\n");
            } else {
                return Status.failed(apiTested + "idChanged() of " 
                    + "HelpModelListener is not called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not add HelpModelListener, " 
                + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "addHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : pass null to addHelpModelListener " 
        + "\nExpected Result :IllegalArgumentException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooHelpModelListener l = null;
            defaultHelpModel.addHelpModelListener(l);
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not get IllegalArgument" 
                + "Exception , Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "addHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : Create HelpModelListener object and pass it to " 
        + "addHelpModelListener" 
        + "\nExpected Result :Shd add HelpModelListener." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooHelpModelListener l = new FooHelpModelListener();
            defaultHelpModel.addHelpModelListener(l);
            return Status.passed(apiTested + "Added HelpModelListener.\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not add HelpModelListener ," 
                + "Got Exception : " + e + "\n");
        }
    }

}

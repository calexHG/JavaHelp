/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooTextHelpModelListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.event.TextHelpModelListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class AddTextHelpModelListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public AddTextHelpModelListenerTest() {
        
    }
        
    public static void main(String argv[]) {
        AddTextHelpModelListenerTest test =
                new AddTextHelpModelListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }    
    
    public Status testCase1() {
        
        String apiTested = "addTextHelpModelListener(TextHelpModelListener l)" 
        + "\nTestCase : addTextHelpModelListener,Call addHighlight(int pos0 ," 
        + "int pos1) and check if listener for TextHelpModelEvent is notified" 
        + "\nExpected Result :highlightsChanged() of TextHelpModelListener " 
        + "shd be called." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooTextHelpModelListener l = new FooTextHelpModelListener();
            defaultHelpModel.addTextHelpModelListener(l);
            defaultHelpModel.addHighlight(10, 20);
            
            /* StaticInfo.bool is set to true within highlightsChanged() 
             * of FooTextHelpModelListener 
             */
            if(StaticInfo.bool == true) {
                return Status.passed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is called.\n");
            } else {
                return Status.failed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is not called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not add " 
                + "TextHelpModelListener , Got Exception : " + e + "\n");
        }
    }
    

    public Status testCase2() {
        
        String apiTested = "addTextHelpModelListener(TextHelpModelListener l)" 
        + "\nTestCase : pass null to addTextHelpModelListener " 
        + "\nExpected Result :IllegalArgumentException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooTextHelpModelListener l = null;
            defaultHelpModel.addTextHelpModelListener(l);
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not get IllegalArgument" 
                + "Exception , Got Exception : " + e + "\n");
        }
    }
    
}

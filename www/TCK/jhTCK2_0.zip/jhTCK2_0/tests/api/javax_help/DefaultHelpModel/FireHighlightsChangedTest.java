/*
 * @(#)FireHighlightsChangedTest.java	1.2 01/08/06
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooTextHelpModelListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import com.sun.help.jck.harness.TestDefaultHelpModel;
import javax.help.event.TextHelpModelListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class FireHighlightsChangedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public FireHighlightsChangedTest() {
        
    }
        
    public static void main(String argv[]) {
        FireHighlightsChangedTest test =
                new FireHighlightsChangedTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }    
    
    public Status testCase1() {
        
        String apiTested = "fireHighlightsChanged(Object source)" 
        + "\nTestCase : addTextHelpModelListener,Call fireHighlightsChanged" 
        + "(Object source) with valid source and check if listener for " 
        + "TextHelpModelEvent is notified." 
        + "\nExpected Result :highlightsChanged() of TextHelpModelListener " 
        + "should be called." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            TestDefaultHelpModel defaultHelpModel = new TestDefaultHelpModel(hs);
            FooTextHelpModelListener l = new FooTextHelpModelListener();
            defaultHelpModel.addTextHelpModelListener(l);
            Object source = new Object();
            defaultHelpModel.testFireHighlightsChanged(source);
            
            /* StaticInfo.bool is set to true within highlightsChanged() 
             * of FooTextHelpModelListener 
             */
            if(StaticInfo.bool == true) {
                return Status.passed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is called.\n");
            } else {
                return Status.failed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is not called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "fireHighlightsChanged(Object source)" 
        + "\nTestCase : addTextHelpModelListener,Call fireHighlightsChanged" 
        + "(Object source) with null source." 
        + "\nExpected Result :Should throw IllegalArgumentException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            TestDefaultHelpModel defaultHelpModel = new TestDefaultHelpModel(hs);
            FooTextHelpModelListener l = new FooTextHelpModelListener();
            defaultHelpModel.addTextHelpModelListener(l);
            Object source = null;
            defaultHelpModel.testFireHighlightsChanged(source);
            
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "fireHighlightsChanged(Object source)" 
        + "\nTestCase : Call fireHighlightsChanged(Object source) with valid " 
        + "source without adding TextHelpModelListener and check if listener " 
        + "for TextHelpModelEvent is not notified." 
        + "\nExpected Result :highlightsChanged() of TextHelpModelListener " 
        + "should not be called." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            TestDefaultHelpModel defaultHelpModel = new TestDefaultHelpModel(hs);
            
            Object source = new Object();
            defaultHelpModel.testFireHighlightsChanged(source);
            
            /* StaticInfo.bool is set to true within highlightsChanged() 
             * of FooTextHelpModelListener 
             */
            if(StaticInfo.bool == true) {
                return Status.failed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is  called.\n");                
            } else {
                return Status.passed(apiTested + "highlightsChanged() of " 
                    + "TextHelpModelListener is not called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.DefaultHelpModel;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class GetCurrentIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetCurrentIDTest() {
        
    }

    public static void main(String argv[]) {
        GetCurrentIDTest test = new GetCurrentIDTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
        
    public Status testCase1() {
        
        String apiTested = "getCurrentID() : " 
        + "\nTestCase : Construct DefaultHelpModel object and call " 
        + "getCurrentID() without setting ID" 
        + "\nExpected Result : Shd return null." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            ID gotMapID = defaultHelpModel.getCurrentID();
            if(gotMapID == null) {
                return Status.passed(apiTested + "Returned null ID.\n");
            } else {
                return Status.failed(apiTested + "Did not return null ID.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
            
    public Status testCase2() {
        
        String apiTested = "getCurrentID() : " 
        + "\nTestCase : Construct DefaultHelpModel object and call " 
        + "getCurrentID() after setting ID" 
        + "\nExpected Result : Shd return given ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            defaultHelpModel.setCurrentID(mapID);
            ID gotMapID = defaultHelpModel.getCurrentID();
            if(gotMapID.equals(mapID)) {
                return Status.passed(apiTested + "Returned given Id." 
                    + "\nGiven Id = " + mapID + " \nGot ID = " 
                    + gotMapID + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given ID." 
                    + "\nGiven Id = " + mapID + " \nGot ID = " 
                    + gotMapID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e);
        }
    }

}

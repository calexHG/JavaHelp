/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.DefaultHelpModel;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class GetHelpSetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpSetTest() {
        
    }
        
    public static void main(String argv[]) {
        GetHelpSetTest test = new GetHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getHelpSet() : " 
        + "\nTestCase : Construct DefaultHelpModel and call getHelpSet " 
        + "without setting HelpSet." 
        + "\nExpected Result :Shd return the HelpSet given to the constructor" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            HelpSet gotHelpSet = defaultHelpModel.getHelpSet();
            if(gotHelpSet.equals(hs)) {
                return Status.passed(apiTested + "Returned HelpSet given to " 
                    + "the constructor.\nGiven HelpSet " + hs 
                    + "\nGot HelpSet " + gotHelpSet + "\n");
            } else {
                return Status.failed(apiTested + "Did not return HelpSet " 
                    + "given to the constructor.\nGiven HelpSet " + hs 
                    + "\nGot HelpSet " + gotHelpSet + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
            
    public Status testCase2() {
        
        String apiTested = "getHelpSet() : " 
        + "\nTestCase : Construct DefaultHelpModel and call getHelpSet after " 
        + "setting HelpSet." 
        + "\nExpected Result : Shd return the given HelpSet." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            HelpSet hs2 = new HelpSet(cl, url2);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            defaultHelpModel.setHelpSet(hs2);
            HelpSet gotHelpSet = defaultHelpModel.getHelpSet();
            if(gotHelpSet.equals(hs2)) {
                return Status.passed(apiTested + "Returned given HelpSet." 
                    + "\nGiven HelpSet = " + hs2 + " \nGot HelpSet = " 
                    + gotHelpSet + "\n");
            } else {
                return Status.failed(apiTested + "Did not get Correct HelpSet" 
                    + "\nGiven HelpSet = " + hs2 
                    + " \nGot HelpSet = " + gotHelpSet + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "getHelpSet() : " 
        + "\nTestCase : Construct DefaultHelpModel and call getHelpSet after " 
        + "setting HelpSet as null." 
        + "\nExpected Result : Shd return null HelpSet." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            HelpSet hs2 = null;
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            defaultHelpModel.setHelpSet(hs2);
            HelpSet gotHelpSet = defaultHelpModel.getHelpSet();
            if(gotHelpSet == hs2) {
                return Status.passed(apiTested + "Returned null HelpSet." 
                    + "\nGiven HelpSet = " + hs2 + " \nGot HelpSet = " 
                    + gotHelpSet + "\n");
            } else {
                return Status.failed(apiTested + "Did not return null HelpSet" 
                    + "\nGiven HelpSet = " + hs2 + " \nGot HelpSet = " 
                    + gotHelpSet + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

}

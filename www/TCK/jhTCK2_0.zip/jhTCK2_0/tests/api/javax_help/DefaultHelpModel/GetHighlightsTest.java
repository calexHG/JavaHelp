/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.TextHelpModel.Highlight;
import javax.help.DefaultHelpModel;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class GetHighlightsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
           
    public GetHighlightsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHighlightsTest test = new GetHighlightsTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getHighlights() : " 
        + "\nTestCase : Construct DefaultHelpModel object and call " 
        + "getHighlights() after adding one highlight" 
        + "\nExpected Result :Shd return an Highlight array with the added " 
        + "highlight." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = 0;
            int pos1 = 10;
            defaultHelpModel.addHighlight(pos0, pos1);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            if(highlights.length == 1) {
                if(gotPos0 == pos0) {
                    if(gotPos1 == pos1) {
                        return Status.passed(apiTested + "Got proper " 
                            + "Highlight\n");
                    } else {
                        return Status.failed(apiTested + "Did not add " 
                            + "Highlight with proper Pos1.\nGiven Pos1 = " 
                            + pos1 + " , Got Pos1 = " + gotPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not get Highlight " 
                        + "with proper Pos0.\nGiven Pos0 = " + pos0 
                        + " , Got Pos0 = " + gotPos0 + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not add Highlight");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
        
    public Status testCase2() {
        
        String apiTested = "getHighlights() : " 
        + "\nTestCase :Construct DefaultHelpModel object and call " 
        + "getHighlights() after adding two highlights" 
        + "\nExpected Result :Shd return an Highlight array with the given " 
        + "highlights added in proper order." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = 10;
            int pos1 = 20;
            int mpos0 = 10;
            int mpos1 = 20;
            defaultHelpModel.addHighlight(pos0, pos1);
            defaultHelpModel.addHighlight(mpos0, mpos1);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            int gotmPos0 = highlights[1].getStartOffset();
            int gotmPos1 = highlights[1].getEndOffset();
            if(highlights.length == 2) {
                if(gotPos0 == pos0 && gotmPos0 == mpos0) {
                    if(gotPos1 == pos1 && gotmPos1 == mpos1) {
                        return Status.passed(apiTested + "Returned Highlight " 
                            + " array with given highlights.\n");
                    } else {
                        return Status.failed(apiTested + "Did not get " 
                            + "highlights with proper Pos1\nGiven Pos1's = " 
                            + pos1 + "," + mpos1 + " Got Pos1's = " + gotPos1 
                            + "," + gotmPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not get highlights" 
                        + " with proper Pos0.\nGiven Pos0's = " + pos0 + "," 
                        + mpos0 + " Got Pos0's = " + gotPos0 + "," 
                        + gotmPos0 + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Highlights " 
                    + "array with two elements.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "getHighlights() : " 
        + "\nTestCase : Construct DefaultHelpModel object and call " 
        + "getHighlights() without adding a highlight" 
        + "\nExpected Result:Shd return an Highlight array with zero elements" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            if(highlights.length == 0) {
                return Status.passed(apiTested + "Got Highlight array with " 
                    + "zero elements.\n");
            } else {
                return Status.failed(apiTested + "Did not get Highlight " 
                    + "array with zero elements.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooPropertyChangeListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import java.beans.PropertyChangeListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class RemovePropertyChangeListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public RemovePropertyChangeListenerTest() {
        
    }
        
    public static void main(String argv[]) {
        RemovePropertyChangeListenerTest test =
                new RemovePropertyChangeListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested="removePropertyChangeListener(PropertyChangeListener l):" 
        + "\nTestCase : Call removePropertyChangeListener after adding a " 
        + "listener.Call setHelpSet(HelpSet hs) and check if listener " 
        + "is not notified" 
        + "\nExpected Result : Shd remove PropertyChangeListener. " 
        + "propertyChange() of PropertyChangeListener shd not be called." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooPropertyChangeListener l = new FooPropertyChangeListener();
            defaultHelpModel.addPropertyChangeListener(l);
            defaultHelpModel.removePropertyChangeListener(l);
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs2 = new HelpSet(cl, url2);
            defaultHelpModel.setHelpSet(hs2);
            
            /* StaticInfo.bool is set to true within propertyChange() 
             * of FooPropertyChangeListener 
             */
            if(StaticInfo.bool == false) {
                return Status.passed(apiTested + "propertyChange() of " 
                    + "PropertyChangeListener is not called.\n");
            } else {
                return Status.failed(apiTested + "propertyChange() of " 
                    + "PropertyChangeListener is called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not remove " 
                + "PropertyChangeListener , Got Exception : " + e + "\n");
        }
    }
            
    public Status testCase2() {
        
        String apiTested="removePropertyChangeListener(PropertyChangeListener l):" 
        + "\nTestCase : Call removePropertyChangeListener without adding a " 
        + "listener." 
        + "\nExpected Result : No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooPropertyChangeListener l = new FooPropertyChangeListener();
            defaultHelpModel.removePropertyChangeListener(l);
            return Status.passed(apiTested + "Okay.No Exception Thrown\n");
        } catch(Exception e) {
            return Status.failed(apiTested + " Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested="removePropertyChangeListener(PropertyChangeListener l):" 
        + "\nTestCase : pass null to removePropertyChangeListener " 
        + "\nExpected Result : No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            FooPropertyChangeListener l = null;
            defaultHelpModel.removePropertyChangeListener(l);
            return Status.passed(apiTested + "No Exception thrown\n");
        
        } catch(Exception e) {
            return Status.failed(apiTested + " Got Exception : " + e + "\n");
        }
    }
 }

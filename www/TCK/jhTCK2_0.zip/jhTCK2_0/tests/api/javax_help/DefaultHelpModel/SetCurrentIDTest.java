/*
 * %W% %E%
 *
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... DefaultHelpModel(hs).setCurrentID(ident) --> DefaultHelpModel(hs).setCurrentID(ident)
 * testCase2 ... DefaultHelpModel(hs).setCurrentID(ident) --> DefaultHelpModel(hs).setCurrentID(null)
 * testCase3 ... DefaultHelpModel(hs).setCurrentID(ident) --> DefaultHelpModel(hs).setCurrentID(invalid)
 *
 * testCase4 ... DefaultHelpModel(hs).setCurrentID(ident, historyName, navigator) --> DefaultHelpModel(hs).setCurrentID(ident, historyName, navigator)
 * testCase5 ... DefaultHelpModel(hs).setCurrentID(ident, historyName, navigator) --> DefaultHelpModel(hs).setCurrentID(null, historyName, navigator)
 * testCase6 ... DefaultHelpModel(hs).setCurrentID(ident, historyName, navigator) --> DefaultHelpModel(hs).setCurrentID(invalid, historyName, navigator)
 */

package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.NavigatorView;
import javax.help.JHelpNavigator;
import javax.help.DefaultHelpModel;
import javax.help.InvalidHelpSetContextException;

import javax.swing.UIDefaults;
import javax.swing.UIManager;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 * @author Patrik Knakal
 */

public class SetCurrentIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetCurrentIDTest() {
    }

    public static void main(String argv[]) {
        SetCurrentIDTest test = new SetCurrentIDTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }

    public Status testCase1() {

        String apiTested = "setCurrentID(Map.ID id) : "
        + "\nTestCase : Construct DefaultHelpModel and call setCurrentID with"
        + " a valid ID"
        + "\nExpected Result : Shd set the given ID."
        + "\nObtained Result : ";

        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            defaultHelpModel.setCurrentID(mapID);
            ID gotMapID = defaultHelpModel.getCurrentID();
            if(gotMapID.equals(mapID)) {
                return Status.passed(apiTested + "Set the given ID.\nGiven "
                    + "Id = " + mapID + " \nGot ID = " + gotMapID + "\n");
            } else {
                return Status.failed(apiTested +"Did not set given ID.\nGiven "
                    + "Id = " + mapID + " \nGot ID = " + gotMapID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

    public Status testCase2() {

        String apiTested = "setCurrentID(Map.ID id) : "
        + "\nTestCase :Construct DefaultHelpModel and call setCurrentID with "
        + "a null ID"
        + "\nExpected Result : Shd set HomeID of helpset ."
        + "\nObtained Result : ";

        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            ID mapID = null;
            ID homeID = hs.getHomeID();
            defaultHelpModel.setCurrentID(mapID);
            ID gotMapID = defaultHelpModel.getCurrentID();
            if(gotMapID.equals(homeID)) {
                return Status.passed(apiTested + "Set the homeID\nGiven Id = "
                    + mapID + " \nGot ID = " + gotMapID + "\n");
            } else {
                return Status.failed(apiTested + "Did not set homeID\nGiven "
                    + " Id = " + mapID + " \nGot ID = " + gotMapID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

    public Status testCase3() {

        String apiTested = "setCurrentID(Map.ID id) : "
        + "\nTestCase : Construct DefaultHelpModel and call setCurrentID with"
        + " a invalid ID"
        + "\nExpected Result : InvalidHelpSetContextException shd be thrown."
        + "\nObtained Result : ";

        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs2 = new HelpSet(cl, url2);
            String id = "merge.intro";
            ID mapID = ID.create(id, hs2);
            defaultHelpModel.setCurrentID(mapID);
            ID gotMapID = defaultHelpModel.getCurrentID();
            return Status.failed(apiTested + "Did not get "
                + "InvalidHelpSetContextException\n");

        } catch(InvalidHelpSetContextException ihe) {
            return Status.passed(apiTested + "Got " 
                + "InvalidHelpSetContextException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }


    /**
     * Method test: <code>setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase4() {
        String apiTested = "setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator): "
            + "TestCase: '(new DefaultHelpModel(hs)).setCurrentID(ident, historyName, navigator)' "
            + "ExpectedResult: Set 'ident' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsUrl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsUrl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            String id = "hol_intro";
            ID mapID  = ID.create(id, hs);
            //creating Map.ID object ... end

            //seting a name for bookmark ... start
            String historyName = "holidays";
            //seting a name for bookmark ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView navigator = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(navigator, new DefaultHelpModel(navigator.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //creating DefaultHelpModel object from given parameters ... start
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            //creating DefaultHelpModel object from given parameters ... end

            //set given parameters to DefaultHelpModel object ... start
            defaultHelpModel.setCurrentID(mapID, historyName, jhnavigator);
            //set given parameters to DefaultHelpModel object ... end

            if(mapID.equals(defaultHelpModel.getCurrentID()) ) {
                return Status.passed(apiTested + "Set 'ident'");
            } else {
                return Status.failed(apiTested + "Did not set 'ident': " + defaultHelpModel.getCurrentID() );
            }

        } catch(Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase5() {
        String apiTested = "setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator): "
            + "TestCase: '(new DefaultHelpModel(hs)).setCurrentID(null, historyName, navigator)' "
            + "ExpectedResult: Set 'HomeID' of 'hs' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsUrl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsUrl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            ID mapID = null;
            //creating Map.ID object ... end

            //seting a name for bookmark ... start
            String historyName = "holidays";
            //seting a name for bookmark ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView navigator = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(navigator, new DefaultHelpModel(navigator.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //creating DefaultHelpModel object from given parameters ... start
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            //creating DefaultHelpModel object from given parameters ... end

            //set given parameters to DefaultHelpModel object ... start
            defaultHelpModel.setCurrentID(mapID, historyName, jhnavigator);
            //set given parameters to DefaultHelpModel object ... end

            if((hs.getHomeID() ).equals(defaultHelpModel.getCurrentID()) ) {
                return Status.passed(apiTested + "Set 'HomeID' of 'hs'");
            } else {
                return Status.failed(apiTested + "Did not set 'HomeID' of 'hs': " + defaultHelpModel.getCurrentID() );
            }

        } catch(Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase6() {
        String apiTested = "setCurrentID(javax.help.Map.ID ident, java.lang.String historyName, javax.help.JHelpNavigator navigator): "
            + "TestCase: '(new DefaultHelpModel(hs)).setCurrentID(invalid, historyName, navigator)' "
            + "ExpectedResult: 'java.lang.InvalidHelpSetContextException' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsUrl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsUrl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            URL url2    = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs2 = new HelpSet(cl, url2);
            String id   = "merge.intro";
            ID mapID    = ID.create(id, hs2);
            //creating Map.ID object ... end

            //seting a name for bookmark ... start
            String historyName = "holidays";
            //seting a name for bookmark ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView navigator = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(navigator, new DefaultHelpModel(navigator.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //creating DefaultHelpModel object from given parameters ... start
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            //creating DefaultHelpModel object from given parameters ... end

            //set given parameters to DefaultHelpModel object ... start
            defaultHelpModel.setCurrentID(mapID, historyName, jhnavigator);
            //set given parameters to DefaultHelpModel object ... end

            return Status.failed(apiTested + "Did not get 'java.lang.InvalidHelpSetContextException'");
        } catch (InvalidHelpSetContextException exc) {
            return Status.passed(apiTested + "Got 'java.lang.InvalidHelpSetContextException'");
        } catch(Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * %W% %E%
 *
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... DefaultHelpModel(hs).setCurrentURL(url) --> DefaultHelpModel(hs).setCurrentURL(url)
 * testCase2 ... DefaultHelpModel(hs).setCurrentURL(url) --> DefaultHelpModel(hs).setCurrentURL(null)
 *
 * testCase4 ... DefaultHelpModel(hs).setCurrentURL(url, historyName, navigator) --> DefaultHelpModel(hs).setCurrentURL(url, historyName, navigator)
 * testCase5 ... DefaultHelpModel(hs).setCurrentURL(url, historyName, navigator) --> DefaultHelpModel(hs).setCurrentURL(null, historyName, navigator)
 */

package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.NavigatorView;
import javax.help.JHelpNavigator;
import javax.help.DefaultHelpModel;

import javax.swing.UIDefaults;
import javax.swing.UIManager;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 * @author Patrik Knakal
 */

public class SetCurrentURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetCurrentURLTest() {
    }

    public static void main(String argv[]) {
        SetCurrentURLTest test = new SetCurrentURLTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }

    public Status testCase1() {

        String apiTested = "setCurrentURL(URL url) : "
        + "\nTestCase : Construct DefaultHelpModel and call setCurrentURL "
        + "with valid URL"
        + "\nExpected Result : Shd set the given URL."
        + "\nObtained Result : ";

        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl =new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            String id = "hol_intro";
            ID tempID = ID.create(id, hs);
            URL url = (hs.getCombinedMap()).getURLFromID(tempID);
            defaultHelpModel.setCurrentURL(url);
            URL gotURL = defaultHelpModel.getCurrentURL();
            if(gotURL.equals(url)) {
                return Status.passed(apiTested + "Set the given URL."
                    + "\nGiven URL = " + url + " \nGot URL = " +gotURL+"\n");
            } else {
                return Status.failed(apiTested + "Did not set given URL."
                    + "\nGiven URL = " + url + " \nGot URL = " +gotURL+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

    public Status testCase2() {

        String apiTested = "setCurrentURL(URL url) : "
        + "\nTestCase : Construct DefaultHelpModel and call setCurrentURL "
        + "with null URL"
        + "\nExpected Result : Shd set the null URL."
        + "\nObtained Result : ";

        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl =new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            URL url = null;
            defaultHelpModel.setCurrentURL(url);
            URL gotURL = defaultHelpModel.getCurrentURL();
            if(gotURL == url) {
                return Status.passed(apiTested + "Set null URL.\n");
            } else {
                return Status.failed(apiTested + "Did not set null URL.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }


    /**
     * Method test: <code>setCurrentURL(java.net.URL url, java.lang.String historyName, javax.help.JHelpNavigator navigator)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "setCurrentURL(java.net.URL url, java.lang.String historyName, javax.help.JHelpNavigator navigator): "
            + "TestCase: '(new DefaultHelpModel(hs)).setCurrentURL(url, historyName, navigator)' "
            + "ExpectedResult: Set 'url' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsUrl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsUrl);
            //creating HelpSet object ... end

            //creating temporary Map.ID object for getting URL object ... start
            String id = "hol_intro";
            ID tmpID  = ID.create(id, hs);
            //creating temporary Map.ID object for getting URL object ... end

            //construct URL for HelpModelEvent construction ... start
            URL url = (hs.getCombinedMap() ).getURLFromID(tmpID);
            //construct URL for HelpModelEvent construction ... end

            //seting a name for bookmark ... start
            String historyName = "holidays";
            //seting a name for bookmark ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView navigator = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(navigator, new DefaultHelpModel(navigator.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //creating DefaultHelpModel object from given parameters ... start
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            //creating DefaultHelpModel object from given parameters ... end

            //set given parameters to DefaultHelpModel object ... start
            defaultHelpModel.setCurrentURL(url, historyName, jhnavigator);
            //set given parameters to DefaultHelpModel object ... end

            if(url.equals(defaultHelpModel.getCurrentURL()) ) {
                return Status.passed(apiTested + "Set 'url'");
            } else {
                return Status.failed(apiTested + "Did not set 'url': " + defaultHelpModel.getCurrentURL() );
            }

        } catch(Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setCurrentURL(java.net.URL url, java.lang.String historyName, javax.help.JHelpNavigator navigator)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase4() {
        String apiTested = "setCurrentURL(java.net.URL url, java.lang.String historyName, javax.help.JHelpNavigator navigator): "
            + "TestCase: '(new DefaultHelpModel(hs)).setCurrentURL(null, historyName, navigator)' "
            + "ExpectedResult: Set 'null' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsUrl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsUrl);
            //creating HelpSet object ... end

            //construct URL for HelpModelEvent construction ... start
            URL url = null;
            //construct URL for HelpModelEvent construction ... end

            //seting a name for bookmark ... start
            String historyName = "holidays";
            //seting a name for bookmark ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView navigator = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(navigator, new DefaultHelpModel(navigator.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //creating DefaultHelpModel object from given parameters ... start
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            //creating DefaultHelpModel object from given parameters ... end

            //set given parameters to DefaultHelpModel object ... start
            defaultHelpModel.setCurrentURL(url, historyName, jhnavigator);
            //set given parameters to DefaultHelpModel object ... end

            if(url == defaultHelpModel.getCurrentURL() ) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + defaultHelpModel.getCurrentURL() );
            }

        } catch(Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

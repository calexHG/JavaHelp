/*
 * %W% %E%
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpModel;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.TextHelpModel.Highlight;
import javax.help.DefaultHelpModel;
import javax.help.DefaultHelpModel.DefaultHighlight;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class SetHighlightsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetHighlightsTest() {
        
    }
        
    public static void main(String argv[]) {
        SetHighlightsTest test = new SetHighlightsTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "setHighlights(TextHelpModel.Highlight[] h) : " 
        + "\nTestCase : Construct DefaultHelpModel and call setHighlights " 
        + "with Max value for pos0 and pos1" 
        + "\nExpected Result :Shd set the given Highlight." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = Integer.MAX_VALUE;
            int pos1 = Integer.MAX_VALUE;
            DefaultHighlight dh[] = new DefaultHighlight[1];
            dh[0] = new DefaultHighlight(pos0, pos1);
            defaultHelpModel.setHighlights(dh);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            if(highlights.length == 1) {
                if(gotPos0 == pos0) {
                    if(gotPos1 == pos1) {
                        return Status.passed(apiTested + "Set the given " 
                            + "Highlight.\nGiven Pos1 = " + pos1 
                            + " Got Pos1 = " + gotPos1 + "\n Given Pos0 = " 
                            + pos0 + "Got Pos0 = " + gotPos0 + "\n");
                    } else {
                        return Status.failed(apiTested + "Did not set the " 
                            +"given Highlight with proper Pos1\nGiven Pos1 = " 
                            + pos1 + " Got Pos1 = " + gotPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not set  Highlight " 
                        + "with proper Pos0.\nGiven Pos0 = " + pos0 
                        + " Got Pos0 = " + gotPos0 + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not set Highlight.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
        
    public Status testCase2() {
        
        String apiTested = "setHighlights(TextHelpModel.Highlight[] h) : " 
        + "\nTestCase : Construct DefaultHelpModel and call setHighlights " 
        + "with Min value for pos0 and value > 0 for pos1" 
        + "\nExpected Result :Shd throw IllegalArgumentException." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = Integer.MIN_VALUE;
            int pos1 = 30;
            DefaultHighlight dh[] = new DefaultHighlight[1];
            dh[0] = new DefaultHighlight(pos0, pos1);
            defaultHelpModel.setHighlights(dh);
            return Status.failed(apiTested + "Did not get IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException : " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "setHighlights(TextHelpModel.Highlight[] h) : " 
        + "\nTestCase : Construct DefaultHelpModel and call setHighlights " 
        + "with value > 0 for pos0 and Min value for pos1" 
        + "\nExpected Result :Shd throw IllegalArgumentException." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = 30;
            int pos1 = Integer.MIN_VALUE;
            DefaultHighlight dh[] = new DefaultHighlight[1];
            dh[0] = new DefaultHighlight(pos0, pos1);
            defaultHelpModel.setHighlights(dh);
            return Status.failed(apiTested + "Did not get IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException : " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase4() {
        
        String apiTested = "setHighlights(TextHelpModel.Highlight[] h) : " 
        + "\nTestCase : Construct DefaultHelpModel and call setHighlights " 
        + "with two highlights" 
        + "\nExpected Result :Shd set the given Highlights in proper order." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            int pos0 = 10;
            int pos1 = 20;
            int mpos0 = 30;
            int mpos1 = 40;
            DefaultHighlight dh[] = new DefaultHighlight[2];
            dh[0] = new DefaultHighlight(pos0, pos1);
            dh[1] = new DefaultHighlight(mpos0, mpos1);
            defaultHelpModel.setHighlights(dh);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            int gotmPos0 = highlights[1].getStartOffset();
            int gotmPos1 = highlights[1].getEndOffset();
            if(highlights.length == 2) {
                if(gotPos0 == pos0 && gotmPos0 == mpos0) {
                    if(gotPos1 == pos1 && gotmPos1 == mpos1) {
                        return Status.passed(apiTested + "Set the Highlights " 
                            + "in proper order.\n");
                    } else {
                        return Status.failed(apiTested + "Did not set " 
                            + "Highlights with proper Pos1.\nGiven Pos1's = " 
                            + pos1 + " , " + mpos1 + "\nGot Pos1's = " 
                            + gotPos1 + "," + gotmPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not set Highlights " 
                        + "with proper Pos0.\nGiven Pos0's = " + pos0 + "," 
                        + mpos0 + "\nGot Pos0's = " + gotPos0 + "," 
                        + gotmPos0 + "\n");
                }
            } else {
                return Status.failed(apiTested +"Did not set the Highlights\n");
            }
        } catch(Exception e) {
             return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        
        String apiTested = "setHighlights(TextHelpModel.Highlight[] h) : " 
        + "\nTestCase : Construct DefaultHelpModel and call setHighlights " 
        + "with null" 
        + "\nExpected Result : Shd get a zero array highlight." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel defaultHelpModel = new DefaultHelpModel(hs);
            DefaultHighlight dh[] = null;
            defaultHelpModel.setHighlights(dh);
            Highlight highlights[] = defaultHelpModel.getHighlights();
            if(highlights.length == 0) {
                return Status.passed(apiTested + "Got zero array highlight." 
                    + "Did not get any Exception\n");
            } else {
                return Status.failed(apiTested + "Did not get zero array " 
                    + "highlight. Did not get any Exception\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

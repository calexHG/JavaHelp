/*
 * @(#)DefaultHelpSetFactoryTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */

package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class DefaultHelpSetFactoryTest extends MultiTest {
        
    public DefaultHelpSetFactoryTest() {
        
    }
    
    public static void main(String argv[]) {
        DefaultHelpSetFactoryTest test = new DefaultHelpSetFactoryTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "DefaultHelpSetFactory() : " 
        + "\nTestCase : Construct DefaultHelpSetFactory using Constructor" 
        + "\nExpected Result : Should create DefaultHelpSetFactory object." 
        + "\nObtained Result : ";

        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            if(defaultFactory instanceof DefaultHelpSetFactory) {
                return Status.passed(apiTested + "Constructed default " 
                	+ "DefaultHelpSetFactory object.\n");
            } else {
                return Status.failed(apiTested + "Did not Construct default " 
                + " DefaultHelpSetFactory object.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

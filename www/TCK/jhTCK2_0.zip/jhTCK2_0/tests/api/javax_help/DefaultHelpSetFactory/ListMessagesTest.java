/*
 * @(#)ListMessagesTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ListMessagesTest extends MultiTest {
   
    
    public ListMessagesTest() {
        
    }
    
    public static void main(String argv[]) {
        ListMessagesTest test = new ListMessagesTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "listMessages( ) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call listMessages" 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration. \n");
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "listMessages( ) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call listMessages" 
        + " after calling reportMessage." 
        + "\nExpected Result : Shd return an enumeration with the given msg." 
        + "\nObtained Result : ";
        
        try {
            String msg[] =  {
                "TestMessage1", "TestMessage2"
            };
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            defaultFactory.reportMessage(msg[0], true);
            defaultFactory.reportMessage(msg[1], false);
            int i = 0;
            int len = msg.length;
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                String str = (String)e.nextElement();
                if(!str.equals(msg[i])) {
                    break;
                }
                i++;
            }
            if(i == len) {
                return Status.passed(apiTested + "Got Enumeration with the " 
                	+ "given strings. \n");
            } else {
                return Status.failed(apiTested + "Did not get enumeretion " 
                	+ "with the given strings\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

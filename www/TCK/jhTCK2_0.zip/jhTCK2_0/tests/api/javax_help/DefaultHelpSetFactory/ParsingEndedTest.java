/*
 * @(#)ParsingEndedTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ParsingEndedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ParsingEndedTest() {
        
    }
    
    public static void main(String argv[]) {
        ParsingEndedTest test = new ParsingEndedTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "parsingEnded(HelpSet hs) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call parsingEnded"
        + " with a valid hs. Call listMessage() and check that no warning or " 
	+ " error message is reported."
        + "\nExpected Result :Should return the given helpset.listMessage() " 
        + "should return empty Enumeration." 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            HelpSet gotHS = defaultFactory.parsingEnded(hs);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check && hs.equals(gotHS)) {
                return Status.passed(apiTested + "Returned the given HelpSet." 
                	+ "listMessage returned Empty Enumeration.\nGiven Helpset = " 
                	+ hs + " , Got HelpSet = " + gotHS + "\n");
            } else {
                return Status.failed(apiTested + "Did not return the given HelpSet."
                +"listMessage did not return Empty Enumeration.\nGiven Helpset = " 
                + hs + " , Got HelpSet = " + gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "parsingEnded(HelpSet hs) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call parsingEnded" 
        + "  with a valid hs after calling reportMessage with false." 
        + "Call listMessage and check if the given error message is reported"
        + "\nExpected Result :Should return the null helpset.listMessage should " 
        + "return only the given msg" 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String msg = "Test Error Message";
            defaultFactory.reportMessage(msg, false);
            HelpSet gotHS = defaultFactory.parsingEnded(hs);
            Enumeration e = defaultFactory.listMessages();
            int i = 0;
            for(;e.hasMoreElements();) {
                String str = (String)e.nextElement();
		System.out.println("str=" + str);
                if(str.equals(msg)) {
		    System.out.println("check=true");
                    check = true;
                }
                i++;
            }
            if(check && i == 2 && gotHS == null) {
                return Status.passed(apiTested + "Returned the null HelpSet." 
                	+ "listMessage returned the given message\nGiven Helpset = " 
                	+ hs + " , Got HelpSet = " + gotHS + "\n");
            } else {
                return Status.failed(apiTested + "Did not return the null " 
                	+ "HelpSet.listMessage did not return given msg.\nGiven Helpset = " 
                	+ hs + " , Got HelpSet = " + gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "parsingEnded(HelpSet hs) : "
        + "\nTestCase : Construct DefaultHelpSetFactory and call parsingEnded" 
        + " with a valid hs after calling reportMessage with true.Call listMessage" 
        + " and check if the given warning message is reported"
        + "\nExpected Result :Shd return the given helpset.listMessage() should " 
        + "return only the given message." 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String msg = "Test Error Message";
            defaultFactory.reportMessage(msg, true);
            HelpSet gotHS = defaultFactory.parsingEnded(hs);
            Enumeration e = defaultFactory.listMessages();
            int i = 0;
            for(;e.hasMoreElements();) {
                String str = (String)e.nextElement();
                if(str.equals(msg)) {
                    check = true;
                }
                i++;
            }
            if(check && i == 1 && hs.equals(gotHS)) {
                return Status.passed(apiTested + "Returned the given HelpSet." 
                	+ "listMessage returned the given msg\nGiven Helpset = " 
                	+ hs + " , Got HelpSet = " + gotHS + "\n");
            } else {
                return Status.failed(apiTested + "Did not return the given " 
                	+ "HelpSet.listMessage did not return the given msg." 
                	+ "\nGiven Helpset = " + hs + " , Got HelpSet = " 
                	+ gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "parsingEnded(HelpSet hs) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call parsingEnded" 
        + " with a null hs.Call listMessage and verify that no warning or error" 
        + " message is reported "
        + "\nExpected Result :Should return the null helpset.listMessage should " 
        + "return an empty Enumeration"
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            HelpSet hs = null;
            HelpSet gotHS = defaultFactory.parsingEnded(hs);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check && hs == gotHS) {
                return Status.passed(apiTested + "Returned the null HelpSet."
                	+ "listMessage returned empty enumeration\nGiven Helpset = " 
                	+ hs + " , Got HelpSet = " + gotHS + "\n");
            } else {
                return Status.failed(apiTested + "Did not return the null " 
			+ "HelpSet.listMessage did not return empty enumeration."
			+ "\nGiven Helpset = " + hs + " , Got HelpSet = " 
			+ gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

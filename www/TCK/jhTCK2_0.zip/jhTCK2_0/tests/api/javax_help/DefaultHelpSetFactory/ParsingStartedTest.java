/*
 * @(#)ParsingStartedTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ParsingStartedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");   
          
    public ParsingStartedTest() {
        
    }
    
    public static void main(String argv[]) {
        ParsingStartedTest test = new ParsingStartedTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "parsingStarted(URL source) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "parsingStarted with a valid url." 
        + "\nExpected Result : Should not throw any exception" 
        + "\nObtained Result : ";
        
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            defaultFactory.parsingStarted(url);
            return Status.passed(apiTested + "Did not throw any Exception \n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "parsingStarted(URL source) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "parsingStarted with a null url." 
        + "\nExpected Result : Should throw NullPointerException." 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            URL url = null;
            defaultFactory.parsingStarted(url);
            return Status.failed(apiTested + "Did not throw NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException : " 
                + npe + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

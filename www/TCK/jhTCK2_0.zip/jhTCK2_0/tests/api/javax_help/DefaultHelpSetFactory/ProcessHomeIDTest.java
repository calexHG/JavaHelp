/*
 * @(#)ProcessHomeIDTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javax.help.Map.ID;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ProcessHomeIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ProcessHomeIDTest() {
        
    }
    
    public static void main(String argv[]) {
        ProcessHomeIDTest test = new ProcessHomeIDTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "processHomeID(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processHomeID with a valid hs  ( with no homeid  ) and value " 
        + "that is valid id for hs." 
        + "\nExpected Result :listMessages shd return empty enumeration ," 
        + " homeId shd be set to given id." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = "halloween";
            hs.setHomeID("");
            defaultFactory.processHomeID(hs, value);
            ID gotID = hs.getHomeID();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                if(gotID.id.equals(value)) {
                    return Status.passed(apiTested + "Got Empty Enumeration " 
                    	+ "and set the homeid.\n");
                } else {
                    return Status.passed(apiTested + "Got Empty Enumeration " 
                    	+ "but did not  set the homeid.\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "processHomeID(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processHomeID with a valid hs  ( with a homeid  ) and value " 
        + "that is a valid id." 
        + "\nExpected Result :listMessages shd return a non empty enumeration" 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = "halloween";
            defaultFactory.processHomeID(hs, value);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(check) {
                return Status.passed(apiTested+"Got Non Empty Enumeration\n");
            } else {
                return Status.failed(apiTested + "Did not get Non Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "processHomeID(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processHomeID with a valid hs  ( with no homeid  ) and value " 
        + "that is invalid id for hs." 
        + "\nExpected Result :listMessages shd return empty enumeration , " 
        + "getHomeID shd return null." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = "invalid";
            hs.setHomeID("");
            defaultFactory.processHomeID(hs, value);
            ID gotID = hs.getHomeID();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                if(gotID == null) {
                    return Status.passed(apiTested + "Got Empty Enumeration " 
                    	+ "and got homeID as null.\n");
                } else {
                    return Status.failed(apiTested + "Got Empty Enumeration " 
                    	+ "but did not get homeID as null.\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "processHomeID(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processHomeID with a null hs ." 
        + "\nExpected Result :NullPointerException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            HelpSet hs = null;
            String value = "halloween";
            defaultFactory.processHomeID(hs, value);
            ID gotID = hs.getHomeID();
            return Status.failed(apiTested + "Did not get " 
            	+ "NullPointerException.\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException : " 
            	+ npe + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = "processHomeID(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processHomeID with a null value ." 
        + "\nExpected Result :listMessages shd return empty enumeration , " 
        + "homeId shd be set to null id." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = null;
            hs.setHomeID("");
            defaultFactory.processHomeID(hs, value);
            ID gotID = hs.getHomeID();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                if(gotID == null) {
                    return Status.passed(apiTested + "Got Empty Enumeration " 
                    	+ "and set the homeid to null.\n");
                } else {
                    return Status.passed(apiTested + "Got Empty Enumeration " 
                    	+ " but did not  set the homeid to null.\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

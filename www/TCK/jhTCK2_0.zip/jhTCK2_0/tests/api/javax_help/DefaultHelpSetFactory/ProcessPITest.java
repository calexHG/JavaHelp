/*
 * @(#)ProcessPITest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ProcessPITest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ProcessPITest() {
        
    }
    
    public static void main(String argv[]) {
        ProcessPITest test = new ProcessPITest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "processPI(HelpSet hs,String target,String data):" 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processPI " 
        + "with a valid values." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String target = "TARGET";
            String data = "DATA";
            defaultFactory.processPI(hs, target, data);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration. \n");
            } else {
                return Status.failed(apiTested + "Did not get " 
                	+ "Empty enumeretion\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "processPI(HelpSet hs,String target,String data):" 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processPI " 
        + "with a null value for hs." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            HelpSet hs = null;
            String target = "TARGET";
            String data = "DATA";
            defaultFactory.processPI(hs, target, data);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration. \n");
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "processPI(HelpSet hs,String target,String data):" 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processPI " 
        + "with a null value for target." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String target = null;
            String data = "DATA";
            defaultFactory.processPI(hs, target, data);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration.\n");
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeretion\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "processPI(HelpSet hs,String target,String data):" 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processPI " 
        + "with null value for data." 
        + "\nExpected Result : listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String target = "TARGET";
            String data = null;
            defaultFactory.processPI(hs, target, data);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration. \n");
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

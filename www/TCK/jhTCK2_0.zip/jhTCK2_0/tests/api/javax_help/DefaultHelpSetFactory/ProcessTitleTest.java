/*
 * @(#)ProcessTitleTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ProcessTitleTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ProcessTitleTest() {
        
    }
    
    public static void main(String argv[]) {
        ProcessTitleTest test = new ProcessTitleTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "processTitle(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processTitle with a valid hs  ( with no Title  ) and value." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "Shd set the given title. " 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = "TestTitle";
            hs.setTitle("");
            defaultFactory.processTitle(hs, value);
            String gotTitle = hs.getTitle();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                if(value.equals(gotTitle)) {
                    return Status.passed(apiTested + "Got Empty Enumeration." 
                    	+ "Set given title\nGiven title = " + value 
                    	+ " , Got Title = " + gotTitle + "\n");
                } else {
                    return Status.failed(apiTested + "Got Empty Enumeration." 
                    	+ "Did not set given title\nGiven title = " + value 
                    	+ " , Got Title = " + gotTitle + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "processTitle(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processTitle with a valid hs  ( with a Title  ) and value." 
        + "\nExpected Result :listMessages shd return non empty enumeration." 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = "TestTitle";
            defaultFactory.processTitle(hs, value);
            String gotTitle = hs.getTitle();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                return Status.failed(apiTested + "Got Empty Enumeration.\n");
            } else {
                return Status.passed(apiTested + "Got Non Empty Enumeration" 
                    + "\nGiven title = " + value + " , Got Title = " 
                    + gotTitle + "\n");
            }
           
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "processTitle(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processTitle with a null hs." 
        + "\nExpected Result : NullPointerException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = null;
            String value = "TestTitle";
            defaultFactory.processTitle(hs, value);
            return Status.failed(apiTested + "Did not get " 
            	+ "NullPointerException \n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException : " 
            	+ npe + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "processTitle(HelpSet hs, String value) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call " 
        + "processTitle with a valid hs and null value." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "Shd set the given title. " 
        + "\nObtained Result : ";
        
        try {
            boolean check = false;
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String value = null;
            hs.setTitle("");
            defaultFactory.processTitle(hs, value);
            String gotTitle = hs.getTitle();
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();
            }
            if(!check) {
                if(gotTitle == "") {
                    return Status.passed(apiTested + "Got Empty Enumeration." 
                    	+ "Set empty title\nGiven title = " + value 
                    	+ " , Got Title = " + gotTitle + "\n");
                } else {
                    return Status.failed(apiTested + "Got Empty Enumeration." 
                    	+ "Did not set empty title\nGiven title = " + value 
                    	+ " , Got Title = " + gotTitle + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

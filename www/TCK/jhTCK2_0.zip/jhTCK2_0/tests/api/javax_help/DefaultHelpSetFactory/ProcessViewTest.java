/*
 * @(#)ProcessViewTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.DefaultHelpSetFactory;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.NavigatorView;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.DefaultHelpSetFactory
 *
 * @author Meena C
 */

public class ProcessViewTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ProcessViewTest() {
        
    }
    
    public static void main(String argv[]) {
        ProcessViewTest test = new ProcessViewTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "processView(HelpSet hs,String name,String label," 
        + "String type,Hashtable viewAttr,String data,Hashtable dataAttr," 
        + "  Locale locale) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processView" 
        + " with a valid values." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "View shd be created." 
        + "\nObtained Result : ";
        
        boolean check = false;
        boolean bool = true;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String name = "MyIndex";
            String label = "MyIndex";
            String type = "javax.help.IndexView";
            Hashtable viewAttr = new Hashtable();
            Hashtable dataAttr = new Hashtable();
            dataAttr.put("data", "HolidayIndex.xml");
            String data = "HolidayIndex.xml";
            Locale locale = Locale.getDefault();
            defaultFactory.processView(hs, name, label, type, viewAttr,
            	 data, dataAttr, locale);
            NavigatorView[] views = hs.getNavigatorViews();
            for(int i = 0;i < views.length;i++) {
                if((views[i].getName()).equals(name)) {
                    bool = true;
                }
            }
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check && bool) {
                return Status.passed(apiTested + "Got Empty Enumeration." 
                	+ "Created view\n");
            } else {
                return Status.failed(apiTested + "Did not get Empty" 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "processView(HelpSet hs,String name,String label," 
        + "String type,Hashtable viewAttr,String data,Hashtable dataAttr," 
        + " Locale locale) : " 
        + "\nTestCase : Construct DefaultHelpSetFactory and call processView" 
        + " with  null values." 
        + "\nExpected Result :listMessages shd return  empty enumeration." 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            DefaultHelpSetFactory defaultFactory =new DefaultHelpSetFactory();
            HelpSet hs = null;
            String name = null;
            String label = null;
            String type = null;
            Hashtable viewAttr = null;
            Hashtable dataAttr = null;
            String data = null;
            Locale locale = null;
            defaultFactory.processView(hs,name,label,type,viewAttr,data,
            	 dataAttr, locale);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
                e.nextElement();
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration. \n");
            } else {
                return Status.failed(apiTested + "Did not get Empty " 
                	+ "Enumeration\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
* @(#)GetStartOffsetTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultHighlight;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.awt.Button;
import javax.help.DefaultHelpModel.DefaultHighlight;
import javax.help.event.HelpSetEvent;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.DefaultHelpModel.DefaultHighlightTest 
* Method: getStartOffset() Test
*
* @author Sudhakar.Adini
*/
public class GetStartOffsetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetStartOffsetTest() {
        
    }
    
    public static void main(String argv[]) {
        GetStartOffsetTest test = new GetStartOffsetTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: getStartOffset()" 
        	+ "\nTestCase : Call getStartOffset()" 
        	+ "\nExpected Result :It should return the start offset" 
        	+ "\nObtained Result : ";
        try {
            int start = 10;
            int end = 20;
            DefaultHighlight dd = new DefaultHighlight(start, end);
            int start1 = dd.getStartOffset();
            if((start1 == start)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return startoffset");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
}

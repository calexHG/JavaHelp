/*
* @(#)CreateItemTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultIndexFactory;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.util.Locale;
import java.util.Hashtable;
import javax.help.TreeItem;
import javax.help.DefaultHelpModel.DefaultHighlight;
import javax.help.IndexView.DefaultIndexFactory;
import javax.help.Map.ID;
import javax.help.event.HelpSetEvent;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.IndexView.DefaultIndexFactoryTest
* 
* Method: createItem()
*
* @author Sudhakar.Adini
*/
public class CreateItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateItemTest() {
        
    }
    
    public static void main(String argv[]) {
        CreateItemTest test = new CreateItemTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: createItem()" 
        	+ "\nTestCase : Call createItem () " 
       		+ "\nExpected Result :It should return the TreeItem object." 
        	+ "\nObtained Result : ";
        try {
            DefaultIndexFactory df = new DefaultIndexFactory();
            TreeItem item = df.createItem();
            if(item instanceof TreeItem) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem with valid parameters" 
       		+ "\nExpected Result :It should return the TreeItem object." 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            ClassLoader l = this.getClass().getClassLoader();
            HelpSet hs = new HelpSet(l, url);
            String tagName = "indexitem";
            Hashtable atts = new Hashtable();
            atts.put("target", "july4");
			atts.put("text", "hellow");
            Locale locale = Locale.getDefault();
            DefaultIndexFactory df = new DefaultIndexFactory();
            TreeItem item = df.createItem(tagName, atts, hs, locale);
			ID id1=item.getID();
			Locale l1=item.getLocale();
			String name=item.getName();			
            if(item instanceof TreeItem&&((id1.id).equals("july4"))&&
				((id1.hs).equals(hs))&&(l1.equals(locale))&&
				name.equals("hellow")){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase2 finished	
    
    public Status testCase3() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem(null,Hashtable atts,"
        	+ "HelpSet hs,Locale locale) " 
        	+ "\nExpected Result :It should throw IllegalArgumentException" 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            ClassLoader l = this.getClass().getClassLoader();
            HelpSet hs = new HelpSet(l, url);
            String tagName = null;
            Hashtable atts = new Hashtable();
            atts.put("target", "july4");
			atts.put("text", "hellow");
            DefaultIndexFactory df = new DefaultIndexFactory();
            Locale locale = Locale.getDefault();
            TreeItem item = df.createItem(tagName, atts, hs, locale);			
            if(item instanceof TreeItem) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the object");
            }
        }
        catch(Exception e) {
            if(e instanceof IllegalArgumentException)
				return Status.passed(apiTested+"Got Exception :"+e.toString());
			else	
				return Status.failed(apiTested+"Got Exception :"+e.toString());
        }
    } //testCase3 finished	
    
    public Status testCase4() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem(String tagName,Hashtable atts,"
        	+ "null,Locale locale) " 
        	+ "\nExpected Result :It should return the TreeItem object." 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = null;
            String tagName = "indexitem";
            Hashtable atts = new Hashtable();
            atts.put("target", "july4");
			atts.put("text", "hellow");
            DefaultIndexFactory df = new DefaultIndexFactory();
            Locale locale = Locale.getDefault();
            TreeItem item = df.createItem(tagName, atts, hs, locale);
			ID id1=item.getID();
			Locale l1=item.getLocale();	
			String name=item.getName();			
            if(item instanceof TreeItem &&(l1.equals(locale))&&(id1==null)&&
				(name.equals("hellow"))){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem(String tagName,null,"
        	+ "HelpSet hs,Locale locale) " 
        	+ "\nExpected Result :It should return the TreeItem object." 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            ClassLoader l = this.getClass().getClassLoader();
            HelpSet hs = new HelpSet(l, url);
            String tagName = "indexitem";
            Hashtable atts = null;
            DefaultIndexFactory df = new DefaultIndexFactory();
            Locale locale = Locale.getDefault();
            TreeItem item = df.createItem(tagName, atts, hs, locale);
			ID id1=item.getID();
			Locale l1=item.getLocale();	
			String name=item.getName();			
            if(item instanceof TreeItem&&(l1.equals(locale))&&(id1==null)){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase5 finished	
    
    public Status testCase6() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,null) " 
        	+ "\nExpected Result :It should return the TreeItem object." 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            ClassLoader l = this.getClass().getClassLoader();
            HelpSet hs = new HelpSet(l, url);
            String tagName = "indexitem";
            Hashtable atts = new Hashtable();
			atts.put("target", "july4");
			atts.put("text", "hellow");
            DefaultIndexFactory df = new DefaultIndexFactory();
            Locale locale = null;
            TreeItem item = df.createItem(tagName, atts, hs, locale);
			ID id1=item.getID();
			Locale l1=item.getLocale();	
			String name=item.getName();
            if(item instanceof TreeItem&&((id1.id).equals("july4"))&&
				((id1.hs).equals(hs))&& name.equals("hellow")){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the sobject");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase6 finished	
	
    public Status testCase7() {
        String apiTested = " Method: createItem(String tagName,Hashtable atts,"
        	+ "HelpSet hs,Locale locale)" 
        	+ "\nTestCase : Call createItem with invalid tagName ie with Index"        	 
        	+ "\nExpected Result :It should throw IllegalArgumentException" 
        	+ "\nObtained Result : ";
        try {
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            ClassLoader l = this.getClass().getClassLoader();
            HelpSet hs = new HelpSet(l, url);
            String tagName = "Index";
            Hashtable atts = new Hashtable();
            DefaultIndexFactory df = new DefaultIndexFactory();
            Locale locale = Locale.getDefault();
            TreeItem item = df.createItem(tagName, atts, hs, locale);
            if(item instanceof TreeItem) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the sobject");
            }
        }
        catch(Exception e) {
			if(e instanceof IllegalArgumentException)
				return Status.passed(apiTested+"Got Exception:"+e.toString());
			else	
				return Status.failed(apiTested+"Got Exception:"+e.toString());
        }
    } //testCase7 finished	
}

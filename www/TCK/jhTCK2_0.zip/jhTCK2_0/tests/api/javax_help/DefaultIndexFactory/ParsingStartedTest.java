/*
* @(#)ParsingStartedTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultIndexFactory;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.awt.Button;
import java.util.Enumeration;
import javax.help.DefaultHelpModel.DefaultHighlight;
import javax.help.IndexView.DefaultIndexFactory;
import javax.help.event.HelpSetEvent;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
/**
* Tests for javax.help.IndexView.DefaultIndexFactoryTest
* 
* Method:parsingStarted(java.net.URL source)
*
* @author Sudhakar.Adini
*/
public class ParsingStartedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ParsingStartedTest() {
        
    }
    
    public static void main(String argv[]) {
        ParsingStartedTest test = new ParsingStartedTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "parsingStarted(URL source) : " 
        + "\nTestCase : Call parsingStarted with a valid url." 
        + "\nExpected Result : No Exception shd be thrown."         
        + "\nObtained Result : ";
        boolean check = false;
        try {
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            defaultFactory.parsingStarted(url);
            return Status.passed(apiTested +" Okay");
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        String apiTested = "parsingStarted(URL source) : " 
        + "\nTestCase : Call parsingStarted with a null url." 
        + "\nExpected Result : It should throw NullPointerException."         
        + "\nObtained Result : ";
        boolean check = false;
        try {
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            URL url = null;
            defaultFactory.parsingStarted(url);
            return Status.failed(apiTested +" Okay");           
        }
        catch(Exception e) {
		if(e instanceof NullPointerException)
			return Status.passed(apiTested+"Got Exception :"+e.toString());
		else
			return Status.failed(apiTested+"Got Exception :"+e.toString());
        }
    }
}

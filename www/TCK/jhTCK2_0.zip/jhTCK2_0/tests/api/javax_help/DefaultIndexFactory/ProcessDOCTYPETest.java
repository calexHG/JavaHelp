/*
* @(#)ProcessDOCTYPETest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DefaultIndexFactory;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.util.Locale;
import java.util.Hashtable;
import java.lang.Class;
import java.net.URL;
import java.awt.Button;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.help.DefaultHelpModel.DefaultHighlight;
import javax.help.IndexView.DefaultIndexFactory;
import javax.help.IndexView;
import javax.help.event.HelpSetEvent;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import java.util.Enumeration;
/**
* Tests for javax.help.IndexView.DefaultIndexFactoryTest
* 
* Method:processDOCTYPE(java.lang.String root,
java.lang.String publicID,
java.lang.String systemID)
*
* @author Sudhakar.Adini
*/
public class ProcessDOCTYPETest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ProcessDOCTYPETest() {
        
    }
    
    public static void main(String argv[]) {
        ProcessDOCTYPETest test = new ProcessDOCTYPETest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "processDocType(String root , Sring publicID ,"
        + " String systemID) : " 
        + "\nTestCase :Call processDocType with valid values " 
        + "\nExpected Result :listMessages shd return  empty enumeration."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            boolean check = false;
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            String root = "ROOT";
            String systemID = "SYSTEM";
            String publicID = "-//Sun Microsystems Inc.//DTD JavaHelp Index" 
            	+ " Version 1.0//EN";
            defaultFactory.processDOCTYPE(root, publicID, systemID);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
				e.nextElement();               
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration.\n");
            }
            else {
                return Status.failed(apiTested + "Not get Empty enumeretion\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        String apiTested = "processDocType(String root , Sring publicID ,"
        + " String systemID) : " 
        + "\nTestCase : Call processDocType with invalid publicId " 
        + "\nExpected Result :listMessages shd return non empty enumeration."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            boolean check = false;
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            String root = "ROOT";
            String systemID = "SYSTEM";
            String publicID = "MyPublicID";
            defaultFactory.processDOCTYPE(root, publicID, systemID);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
		e.nextElement();                
            }
            if(!check) {
                return Status.failed(apiTested + "Got Empty Enumeration\n");
            }
            else {
                return Status.passed(apiTested +"Got Non Empty Enumeration.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        String apiTested = "processDocType(String root , Sring publicID , "
        + " String systemID) : " 
        + "\nTestCase : Call processDocType with null publicId  ." 
        + "\nExpected Result :listMessages shd return non empty enumeration."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            boolean check = false;
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            String root = "ROOT";
            String systemID = "SYSTEM";
            String publicID = null;
            defaultFactory.processDOCTYPE(root, publicID, systemID);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
				e.nextElement();                
            }
            if(!check) {
                return Status.failed(apiTested + "Got Empty Enumeration\n");
            }
            else {
                return Status.passed(apiTested +"Got Non Empty Enumeration.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        String apiTested = "processDocType(String root , Sring publicID , "
        + " String systemID) : " 
        + "\nTestCase : Call processDocType with null root  ." 
        + "\nExpected Result :listMessages shd return empty enumeration."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            boolean check = false;
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            String root = null;
            String systemID = "SYSTEM";
  	    String publicID = "-//Sun Microsystems Inc.//DTD JavaHelp Index" 
            	+ " Version 1.0//EN";
            defaultFactory.processDOCTYPE(root, publicID, systemID);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
				e.nextElement();                
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration\n");
            }
            else {
                return Status.failed(apiTested +"Got Non Empty Enumeration.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        String apiTested = "processDocType(String root , Sring publicID , "
        + " String systemID) : " 
        + "\nTestCase : Call processDocType with null systemID  ." 
        + "\nExpected Result :listMessages shd return empty enumeration."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            boolean check = false;
            DefaultIndexFactory defaultFactory = new DefaultIndexFactory();
            String root = "ROOT";
            String systemID = null;
            String publicID = "-//Sun Microsystems Inc.//DTD JavaHelp Index" 
            	+ " Version 1.0//EN";
            defaultFactory.processDOCTYPE(root, publicID, systemID);
            Enumeration e = defaultFactory.listMessages();
            for(;e.hasMoreElements();) {
                check = true;
				e.nextElement();                
            }
            if(!check) {
                return Status.passed(apiTested + "Got Empty Enumeration\n");
            }
            else {
                return Status.failed(apiTested +"Got Non Empty Enumeration.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

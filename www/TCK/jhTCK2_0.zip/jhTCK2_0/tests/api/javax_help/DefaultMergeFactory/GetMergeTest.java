/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... DefaultMergeFactory.getMerge(masterView, slaveView) --> DefaultMergeFactory.getMerge(masterView, slaveView)
 * testCase2 ... DefaultMergeFactory.getMerge(masterView, slaveView) --> DefaultMergeFactory.getMerge(null, slaveView)
 * testCase3 ... DefaultMergeFactory.getMerge(masterView, slaveView) --> DefaultMergeFactory.getMerge(masterView, null)
 */

package javasoft.sqe.tests.api.javax.help.DefaultMergeFactory;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.Merge;
import javax.help.HelpSet;
import javax.help.NavigatorView;
import javax.help.Merge.DefaultMergeFactory;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.Merge.DefaultMergeFactory ... getMerge(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetMergeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetMergeTest() {
    }

    public static void main(String argv[]) {
        GetMergeTest test = new GetMergeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>masterView</code> valid value
     * @param <code>slaveView</code>  valid value
     */
    public Status testCase1() {
        String apiTested = "javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView): "
            + "TestCase: 'DefaultMergeFactory.getMerge(masterView, slaveView)' "
            + "ExpectedResult: Merge object with a given values "
            + "ObtainedResult: ";

        try {
            //create HelpSet objects ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
            //create HelpSet objects ... end

            //get TOCView objects ... start
            NavigatorView masterView = hsmaster.getNavigatorView("TOC");
            NavigatorView slaveView  = hsslave.getNavigatorView("TOC");
            //get TOCView objects ... end

            //create a Merge object ... start
            Object merge = DefaultMergeFactory.getMerge(masterView, slaveView);
            //create a Merge object ... end

            if (merge instanceof Merge) { //is instance of Merge class
                return Status.passed(apiTested + "OK");
            } else { //is not instance of Merge class
                return Status.failed(apiTested + "Did not construct Merge object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>masterView</code> <code>null</code> value
     * @param <code>slaveView</code>  valid value
     */
    public Status testCase2() {
        String apiTested = "javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView): "
            + "TestCase: 'DefaultMergeFactory.getMerge(null, slaveView)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
            //create HelpSet object ... end

            //get TOCView objects ... start
            NavigatorView masterView = null;
            NavigatorView slaveView  = hsslave.getNavigatorView("TOC");
            //get TOCView objects ... end

            //create a Merge object ... start
            Object merge = DefaultMergeFactory.getMerge(masterView, slaveView);
            //create a Merge object ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
	    exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>masterView</code> valid value
     * @param <code>slaveView</code>  <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "javax.help.Merge getMerge(javax.help.NavigatorView masterView, javax.help.NavigatorView slaveView): "
            + "TestCase: 'DefaultMergeFactory.getMerge(null, slaveView)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create HelpSet object ... end

            //get TOCView objects ... start
            NavigatorView masterView = hsmaster.getNavigatorView("TOC");
            NavigatorView slaveView  = null;
            //get TOCView objects ... end

            //create a Merge object ... start
            Merge merge = DefaultMergeFactory.getMerge(masterView, slaveView);
            //create a Merge object ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

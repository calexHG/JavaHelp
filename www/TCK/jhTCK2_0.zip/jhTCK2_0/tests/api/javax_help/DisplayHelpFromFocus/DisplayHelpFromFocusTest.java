/*
* @(#)DisplayHelpFromFocusTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.DisplayHelpFromFocus;
import java.io.PrintWriter;
import java.lang.reflect.*;
import java.util.Hashtable;
import javax.help.*;
import javax.help.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Component;
import java.net.URL;
import javax.help.Map.ID;
import java.util.Stack;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.help.CSH.DisplayHelpFromFocus;
import javax.help.CSH.DisplayHelpFromFocus;
import javax.help.DefaultHelpBroker;
/**
* Tests for CSH.DisplayHelpFromFocus

* Constructor Test
* Create a DisplayHelpFromFocus
*
* @author Sudhakar.Adini
*/
public class DisplayHelpFromFocusTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public DisplayHelpFromFocusTest() {
        
    }
    
    public static void main(String argv[]) {
        DisplayHelpFromFocusTest test = new DisplayHelpFromFocusTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }    
    public Status testCase1() {
        String apiTested ="Constructor:DisplayHelpFromFocus(HelpBroker hb)"
        + "\nTestCase : Call DisplayHelpFromFocus with  proper hb  " 
        + "\nExpected Result :It should Construct DisplayHelpFromFocus object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpBroker hb = new DefaultHelpBroker(hs);
            DisplayHelpFromFocus dat = new DisplayHelpFromFocus(hb);
            if(dat instanceof DisplayHelpFromFocus) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
    
    public Status testCase2() {
        String apiTested ="Constructor: DisplayHelpFromFocusTest(HelpBroker hb)" 
        + "\nTestCase : Call DisplayHelpFromFocus with  hb as null  " 
        + "\nExpected Result :It should throw NullPointerException" 
        + "\nObtained Result : ";
        try { //DefaultHelpBroker hb=new DefaultHelpBroker();
            DisplayHelpFromFocus dat = new DisplayHelpFromFocus(null);
            return Status.failed(apiTested +"No Exception raised");
        }
        catch(Exception e) {
			if(e instanceof NullPointerException)
				return Status.passed(apiTested+"GotException :"+e.toString());
			else	
            	return Status.failed(apiTested+"GotException :"+e.toString());
        }
    } //testCase2 finished	
}

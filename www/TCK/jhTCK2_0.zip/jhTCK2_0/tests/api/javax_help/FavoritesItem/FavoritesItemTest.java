/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... FavoritesItem() --> FavoritesItem()
 *
 * testCase2 ... FavoritesItem(name) --> FavoritesItem(name)
 * testCase3 ... FavoritesItem(name) --> FavoritesItem(null)
 *
 * testCase4  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(name, target, url, title, locale)
 * testCase5  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(null, target, url, title, locale)
 * testCase6  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(name, null, url, title, locale)
 * testCase7  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(name, target, null, title, locale)
 * testCase8  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(name, target, url, null, locale)
 * testCase9  ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(name, target, url, title, null)
 * testCase10 ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem(null, null, null, null, null)
 * testCase11 ... FavoritesItem(name, target, url, title, locale) --> FavoritesItem("", "", "", "", null)
 */

package javasoft.sqe.tests.api.javax.help.FavoritesItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.HelpSet;
import javax.help.FavoritesItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FavoritesItem ... FavoritesItem()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class FavoritesItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public FavoritesItemTest() {
    }

    public static void main(String argv[]) {
        FavoritesItemTest test = new FavoritesItemTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>FavoritesItem()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "FavoritesItem(): "
            + "TestCase: 'FavoritesItem()' "
            + "ExpectedResult: FavoritesItem object "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem();
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                return Status.passed(apiTested + "OK");
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code> valid value
     */
    public Status testCase2() {
        String apiTested = "FavoritesItem(java.lang.String name): "
            + "TestCase: Construct with: 'name == valid' "
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            String name = "favorites item";
            FavoritesItem fItem = new FavoritesItem(name);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    return Status.passed(apiTested + "OK");
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code> <code>null<code> value
     */
    public Status testCase3() {
        String apiTested = "FavoritesItem(java.lang.String name): "
            + "TestCase: Construct with: 'name == null' "
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            String name = null;
            FavoritesItem fItem = new FavoritesItem(name);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name == fItem.toString() ) { //name object is correct
                    return Status.passed(apiTested + "OK");
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   valid value
     * @param <code>target</code> valid value
     * @param <code>url</code>    valid value
     * @param <code>title</code>  valid value
     * @param <code>locale</code> valid value
     */
    public Status testCase4() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == valid, target == valid, url == valid, title == valid, locale == valid"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale.equals(fItem.getLocale()) ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   <code>null</code> value
     * @param <code>target</code> valid value
     * @param <code>url</code>    valid value
     * @param <code>title</code>  valid value
     * @param <code>locale</code> valid value
     */
    public Status testCase5() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == null, target == valid, url == valid, title == valid, locale == valid"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = null;
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name == fItem.toString() ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale.equals(fItem.getLocale()) ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   valid value
     * @param <code>target</code> <code>null</code> value
     * @param <code>url</code>    valid value
     * @param <code>title</code>  valid value
     * @param <code>locale</code> valid value
     */
    public Status testCase6() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == valid, target == null, url == valid, title == valid, locale == valid"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = null;
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target == fItem.getTarget() ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale.equals(fItem.getLocale()) ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   valid value
     * @param <code>target</code> valid value
     * @param <code>url</code>    <code>null</code> value
     * @param <code>title</code>  valid value
     * @param <code>locale</code> valid value
     */
    public Status testCase7() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == valid, target == valid, url == null, title == valid, locale == valid"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = null;
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url == fItem.getURLSpec() ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale.equals(fItem.getLocale()) ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   valid value
     * @param <code>target</code> valid value
     * @param <code>url</code>    valid value
     * @param <code>title</code>  <code>null</code> value
     * @param <code>locale</code> valid value
     */
    public Status testCase8() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == valid, target == valid, url == valid, title == null, locale == valid"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = null;
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title == fItem.getHelpSetTitle() ) { //title object is correct
                                if (locale.equals(fItem.getLocale()) ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   valid value
     * @param <code>target</code> valid value
     * @param <code>url</code>    valid value
     * @param <code>title</code>  valid value
     * @param <code>locale</code> <code>null</code> value
     */
    public Status testCase9() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == valid, target == valid, url == valid, title == valid, locale == null"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = null;
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale == fItem.getLocale() ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   <code>null</code> value
     * @param <code>target</code> <code>null</code> value
     * @param <code>url</code>    <code>null</code> value
     * @param <code>title</code>  <code>null</code> value
     * @param <code>locale</code> <code>null</code> value
     */
    public Status testCase10() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == null, target == null, url == null, title == null, locale == null"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //setting necessary String objects ... start
            String name = null;
            String target = null;
            String url = null;
            String title = null;
            Locale locale = null;
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name == fItem.toString() ) { //name object is correct
                    if (target == fItem.getTarget() ) { //target object is correct
                        if (url == fItem.getURLSpec() ) { //url object is correct
                            if (title == fItem.getHelpSetTitle() ) { //title object is correct
                                if (locale == fItem.getLocale() ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>   "" value
     * @param <code>target</code> "" value
     * @param <code>url</code>    "" value
     * @param <code>title</code>  "" value
     * @param <code>locale</code> <code>null</code> value
     */
    public Status testCase11() {
        String apiTested = "FavoritesItem(java.lang.String name, java.lang.String target, java.lang.String url, java.lang.String title, java.util.Locale locale): "
            + "TestCase: Construct with: 'name == \"\", target == \"\", url == \"\", title == \"\", locale == null"
            + "ExpectedResult: FavoritesItem object with given values "
            + "ObtainedResult: ";

        try {
            //setting necessary String objects ... start
            String name = "";
            String target = "";
            String url = "";
            String title = "";
            Locale locale = null;
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(fItem instanceof FavoritesItem) { //is instance of FavoritesItem class
                if (name.equals(fItem.toString()) ) { //name object is correct
                    if (target.equals(fItem.getTarget()) ) { //target object is correct
                        if (url.equals(fItem.getURLSpec()) ) { //url object is correct
                            if (title.equals(fItem.getHelpSetTitle()) ) { //title object is correct
                                if (locale == fItem.getLocale() ) { //locale object is correct
                                    return Status.passed(apiTested + "OK");
                                } else { //locale object is not correct
                                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'locale' value: original: '" + locale + "' obtained: '" + fItem.getLocale() + "'");
                                }
                            } else { //title object is not correct
                                return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'title' value: original: '" + title + "' obtained: '" + fItem.getHelpSetTitle() + "'");
                            }
                        } else { //url object is not correct
                            return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'url' value: original: '" + url + "' obtained: '" + fItem.getURLSpec() + "'");
                        }
                    } else { //target object is not correct
                        return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'target' value: original: '" + target + "' obtained: '" + fItem.getTarget() + "'");
                    }
                } else { //name object is not correct
                    return Status.failed(apiTested + "Did not construct FavoritesItem object with correct 'name' value: original: '" + name + "' obtained: '" + fItem.toString() + "'");
                }
            } else { //is not instance of FavoritesItem class
                return Status.failed(apiTested + "Did not construct FovoritesItem object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}


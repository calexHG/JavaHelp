/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... FavoritesItem().getTarget() --> FavoritesItem().getTarget()
 *
 * testCase2 ... FavoritesItem(name).getTarget() --> FavoritesItem(name).getTarget()
 *
 * testCase3 ... FavoritesItem(name, target, url, title, locale).getTarget() --> FavoritesItem(name, target, url, title, locale).getTarget()
 * testCase4 ... FavoritesItem(name, target, url, title, locale).getTarget() --> FavoritesItem(name, null, url, title, locale).getTarget()
 * testCase5 ... FavoritesItem(name, target, url, title, locale).getTarget() --> FavoritesItem(name, "", url, title, locale).getTarget()
 */

package javasoft.sqe.tests.api.javax.help.FavoritesItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.HelpSet;
import javax.help.FavoritesItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FavoritesItem ... getTarget()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetTargetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetTargetTest() {
    }

    public static void main(String argv[]) {
        GetTargetTest test = new GetTargetTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.lang.String getTarget()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.lang.String getTarget(): "
            + "TestCase: '(new FavoritesItem()).getTarget()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem();
            //construc a object ... end


            if(fItem.getTarget() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + fItem.getTarget() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getTarget()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "java.lang.String getTarget(): "
            + "TestCase: '(new FavoriteItem(name)).getTarget()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            String name = "favorites item";
            FavoritesItem fItem = new FavoritesItem(name);
            //construc a object ... end


            if(fItem.getTarget() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + fItem.getTarget() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getTarget()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "java.lang.String getTarget(): "
            + "TestCase: '(new FavoritesItem(name, target, url, title, locale)).getTarget()' "
            + "ExpectedResult: 'target' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(target.equals(fItem.getTarget()) ) {
                return Status.passed(apiTested + "Got 'target'");
            } else {
                return Status.failed(apiTested + "Did not get 'target': " + fItem.getTarget() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getTarget()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase4() {
        String apiTested = "java.lang.String getTarget(): "
            + "TestCase: '(new FavoritesItem(name, null, url, title, locale)).getTarget()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = null;
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(target == fItem.getTarget() ) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + fItem.getTarget() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getTarget()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase5() {
        String apiTested = "java.lang.String getTarget(): "
            + "TestCase: '(new FavoritesItem(name, \"\", url, title, locale)).getTarget()' "
            + "ExpectedResult: '\"\"' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end


            if(target.equals(fItem.getTarget()) ) {
                return Status.passed(apiTested + "Got '\"\"'");
            } else {
                return Status.failed(apiTested + "Did not get '\"\"': " + fItem.getTarget() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

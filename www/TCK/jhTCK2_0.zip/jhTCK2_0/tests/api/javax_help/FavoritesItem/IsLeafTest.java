/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... FavoritesItem().isLeaf() --> FavoritesItem().isLeaf()
 * testCase2 ... FavoritesItem(name).isLeaf() --> FavoritesItem(name).isLeaf()
 * testCase3 ... FavoritesItem(name, target, url, title, locale).isLeaf() --> FavoritesItem(name, target, url, title, locale).isLeaf()
 */

package javasoft.sqe.tests.api.javax.help.FavoritesItem;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.FavoritesItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FavoritesItem ... isLeaf()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class IsLeafTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public IsLeafTest() {
    }

    public static void main(String argv[]) {
        IsLeafTest test = new IsLeafTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>boolean isLeaf()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "boolean isLeaf(): "
            + "TestCase: '(new FavoritesItem()).idLeaf()' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //creating a FavoritesItem oblect ... start
            FavoritesItem fItem = new FavoritesItem();
            //creating a FavoritesItem oblect ... end

            System.out.println("isLeaf ... " + fItem.isLeaf() );
            System.out.println("isFolder ... " + fItem.isFolder() );


            if(fItem.isLeaf() ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + fItem.isLeaf() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}


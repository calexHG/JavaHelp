/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... FavoritesItem().setVisible(visible) --> FavoritesItem().setVisible(true)
 * testCase2 ... FavoritesItem().setVisible(visible) --> FavoritesItem().setVisible(false)
 *
 * testCase3 ... FavoritesItem(name).setVisible(visible) --> FavoritesItem(name).setVisible(true)
 * testCase4 ... FavoritesItem(name).setVisible(visible) --> FavoritesItem(name).setVisible(false)
 *
 * testCase5 ... FavoritesItem(name, target, url, title, locale).setVisible(visible) --> FavoritesItem(name, target, url, title, locale).setVisible(true)
 * testCase6 ... FavoritesItem(name, target, url, title, locale).setVisible(visible) --> FavoritesItem(name, target, url, title, locale).setVisible(false)
 */

package javasoft.sqe.tests.api.javax.help.FavoritesItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.HelpSet;
import javax.help.FavoritesItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FavoritesItem ... setVisible(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetVisibleTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetVisibleTest() {
    }

    public static void main(String argv[]) {
        SetVisibleTest test = new SetVisibleTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>true</code>
     */
    public Status testCase1() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoritesItem()).setVisible(true)' "
            + "ExpectedResult: Set 'true' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem();
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(true);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.passed(apiTested + "Set 'true'");
            } else {
                return Status.failed(apiTested + "Did not set 'true': " + fItem.isVisible() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>false</code>
     */
    public Status testCase2() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoritesItem()).setVisible(false)' "
            + "ExpectedResult: Set 'false' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem();
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(false);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.failed(apiTested + "Did not set 'flase': " + fItem.isVisible() );
            } else {
                return Status.passed(apiTested + "Set 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>true</code>
     */
    public Status testCase3() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoriteItem(name)).setVisible(true)' "
            + "ExpectedResult: Set 'true' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            String name = "favorites item";
            FavoritesItem fItem = new FavoritesItem(name);
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(true);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.passed(apiTested + "Set 'true'");
            } else {
                return Status.failed(apiTested + "Did not set 'true': " + fItem.isVisible() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>false</code>
     */
    public Status testCase4() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoriteItem(name)).setVisible(false)' "
            + "ExpectedResult: Set 'false' "
            + "ObtainedResult: ";

        try {
            //construc a object ... start
            String name = "favorites item";
            FavoritesItem fItem = new FavoritesItem(name);
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(false);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.failed(apiTested + "Did not set 'false': " + fItem.isVisible() );
            } else {
                return Status.passed(apiTested + "Set 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>true</code>
     */
    public Status testCase5() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoritesItem(name, target, url, title, locale)).setVisible(true)' "
            + "ExpectedResult: Set 'true' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(true);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.passed(apiTested + "Set 'true'");
            } else {
                return Status.failed(apiTested + "Did not set 'true': " + fItem.isVisible() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setVisible(boolean visible)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>visible</code> <code>false</code>
     */
    public Status testCase6() {
        String apiTested = "setVisible(boolean visible): "
            + "TestCase: '(new FavoritesItem(name, target, url, title, locale)).setVisible(false)' "
            + "ExpectedResult: Set 'false' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //setting necessary String objects ... start
            String name = "favorites item";
            String target = "view";
            String url = hs.getHelpSetURL().toExternalForm();
            String title = hs.getTitle();
            Locale locale = Locale.getDefault();
            //setting necessary String objects ... end

            //construc a object ... start
            FavoritesItem fItem = new FavoritesItem(name, target, url, title, locale);
            //construc a object ... end

            //set visible value ... start
            fItem.setVisible(false);
            //set visible value ... end


            if(fItem.isVisible() ) {
                return Status.failed(apiTested + "Did not set 'false': " + fItem.isVisible() );
            } else {
                return Status.passed(apiTested + "Set 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

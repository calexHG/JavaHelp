
/*
* 
* 
* @(#)FlatMapTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.FlatMap;

import java.io.PrintWriter;
import javax.help.FlatMap;
import javax.help.HelpSet;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FlatMap
 *
 
 * @author Ben John.
 */

public class FlatMapTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public FlatMapTest() {
        
    }
    
    public static void main(String argv[]) {
        FlatMapTest test = new FlatMapTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" FlatMap(java.net.URL base,HelpSet hs)\" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            try {
                URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs = new HelpSet(loader, url);
                FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
                if(tfm.getHelpSet() == hs) {
                    return Status.passed(apiTested + "Okay");
                }
                else {
                    return Status.failed(apiTested 
                    + "Did not Construct valid FlatMap object");
                }
            }
            catch(java.io.IOException ex) {
                return Status.failed(apiTested 
                + " Exception raised for FlatMap object :" + ex);
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "raised" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" FlatMap(java.net.URL base,HelpSet hs)\" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            try {
                URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs = new HelpSet(loader, url);
                FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/abc.jhm"), hs);
                return Status.failed(apiTested 
                + "Did not raise Exception for Invalid URL");
            }
            catch(java.io.IOException ex) {
                return Status.passed(apiTested 
                + "Okay ! Exception raised :" + ex);
            }
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Got NullPointerException for Invaild URL object " + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception for Invalid URL object " + ee);
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \" FlatMap(java.net.URL base,HelpSet hs)\" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            try {
                URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs = new HelpSet(loader, url);
                FlatMap tfm = new FlatMap(null, hs);
                if(tfm instanceof FlatMap) {
                    return Status.passed(apiTested 
                    + "Okay ;passing null for url object");
                }
                else {
                    return Status.failed(apiTested 
                    + "Did not Construct valid FlatMap object for null URL");
                }
            }
            catch(java.io.IOException ex) {
                return Status.failed(apiTested 
                + "Exception raised for FlatMap object");
            }
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Got NullPointerException :Passing null for URL " + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception :Passing null for URL " + ee);
            }
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \" FlatMap(java.net.URL base,HelpSet hs)\" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            try {
                URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs = new HelpSet(loader, url);
                FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), null);
                if(tfm instanceof FlatMap) {
                    return Status.passed(apiTested 
                    + "Okay ;passing null for HelpSet and valid url object");
                }
                else {
                    return Status.failed(apiTested + "Did not Construct valid "
                    + " FlatMap object for null HelpSet with Valid URL");
                }
            }
            catch(java.io.IOException ex) {
                return Status.failed(apiTested 
                + "Exception raised for FlatMap object");
            }
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + ee
                + " raised for  null HelpSet" );
            }
            else {
                return Status.failed(apiTested + ee
                + " raised for  null HelpSet");
            }
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method \" FlatMap(java.net.URL base,HelpSet hs)\" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            try {
                URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
                HelpSet hs = new HelpSet(loader, url);
                hs.add(hs);
                FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
                return Status.failed(apiTested 
                + "Construct valid FlatMap object for nested HelpSets");
            }
            catch(java.io.IOException ex) {
                return Status.failed(apiTested +ex+" raised for FlatMap object");
            }
        }
        catch(Exception ee) {
            if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + ee+" raised for Nested HelpSet");
            }
            else {
                return Status.failed(apiTested +ee +" raised for Nested HelpSet");
            }
        }
    } //testCase5 finished
}

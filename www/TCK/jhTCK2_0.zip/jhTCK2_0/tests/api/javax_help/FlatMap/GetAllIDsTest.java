
/*
* 
* 
* @(#)GetAllIDsTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.FlatMap;

import java.io.PrintWriter;
import javax.help.FlatMap;
import javax.help.HelpSet;
import javax.help.Map;
import java.net.URL;
import java.util.Enumeration;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FlatMap
 *
 
 * @author Ben John.
 */

public class GetAllIDsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetAllIDsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetAllIDsTest test = new GetAllIDsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getAllIDs() \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL uu = new URL("file", null, HSLOC + "/holidays/Map.jhm");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            boolean check = false;
            for(Enumeration ee = tfm.getAllIDs();ee.hasMoreElements();) {
                if(ee.nextElement() instanceof Map.ID) {
                    check = true;
                }
                else {
                    check = false;
                    break;
                }
            }
            if(check) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } //testCase1 finished
}

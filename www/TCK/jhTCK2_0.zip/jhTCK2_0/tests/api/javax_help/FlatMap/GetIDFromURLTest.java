
/*
* 
* 
* @(#)GetIDFromURLTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.FlatMap;

import java.io.PrintWriter;
import javax.help.FlatMap;
import javax.help.HelpSet;
import javax.help.Map;
import java.util.Enumeration;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FlatMap
 *
 
 * @author Ben John.
 */

public class GetIDFromURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetIDFromURLTest() {
        
    }
    
    public static void main(String argv[]) {
        GetIDFromURLTest test = new GetIDFromURLTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getIDFromURL(java.net.URL url) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            boolean check = false;
            for(Enumeration ee = tfm.getAllIDs();ee.hasMoreElements();) {
                Map.ID mapid = (Map.ID)ee.nextElement();
                URL urll = tfm.getURLFromID(mapid);
                if(tfm.getIDFromURL(urll) instanceof Map.ID) {
                    check = true;
                }
                else {
                    check = false;
                    break;
                }
            }
            if(check) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" getIDFromURL(java.net.URL url) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            if(tfm.getIDFromURL(url) == null) {
                return Status.passed(apiTested + "Returns null for Invalid URL");
            }
            else {
                return Status.passed(apiTested 
                + "Did not return Valid Map.ID object ,passing Invalid URL");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \" getIDFromURL(java.net.URL url) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL uu = new URL("file", null, HSLOC + "/holidays/welcome.html");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            tfm.getIDFromURL(null);
            if(tfm.getIDFromURL(null) == null) {
                return Status.passed(apiTested + "Returns null for null URL");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return Valid Map.ID object for Null URL");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } //testCase3 finished
}

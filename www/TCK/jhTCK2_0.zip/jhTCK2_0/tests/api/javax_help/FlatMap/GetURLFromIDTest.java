
/*
* 
* 
* @(#)GetURLFromIDTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.FlatMap;

import java.io.PrintWriter;
import javax.help.*;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FlatMap
 *
 
 * @author Ben John.
 */

public class GetURLFromIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetURLFromIDTest() {
        
    }
    
    public static void main(String argv[]) {
        GetURLFromIDTest test = new GetURLFromIDTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getURLFromID(Map.ID iden) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL uu = new URL("file", null, HSLOC + "/holidays/welcome.html");
            HelpSet hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            if(tfm.getURLFromID(mid) instanceof java.net.URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid URL object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" getURLFromID(Map.ID iden) \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm = new FlatMap(new URL("file", null, HSLOC + "/holidays/Map.jhm"), hs);
            URL uu = tfm.getURLFromID(null);
            if(uu == null) {
                return Status.passed(apiTested + "Returns null for null id.");
            }
            else {
                return Status.failed(apiTested + "Did not return Null for Null id.");
            }
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Exception Raised for null parameter" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Exception Raised for null parameter" + ee);
            }
        }
    } //testCase2 finished
}

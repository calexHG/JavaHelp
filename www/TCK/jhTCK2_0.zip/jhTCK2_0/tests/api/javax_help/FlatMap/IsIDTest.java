
/*
* 
* 
* @(#)IsIDTest.java	1.4 03/07/08 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.FlatMap;

import java.io.PrintWriter;
import javax.help.HelpSet;
import javax.help.FlatMap;
import javax.help.Map;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.FlatMap
 *
 
 * @author Ben John.
 */

public class IsIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public IsIDTest() {
        
    }
    
    public static void main(String argv[]) {
        IsIDTest test = new IsIDTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" isID() \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	    URL mapURL = new URL("file", null, HSLOC + "/holidays/Map.jhm");
            HelpSet hs = new HelpSet(loader, url);

            FlatMap tfm = new FlatMap(mapURL, hs);
            URL uu = new URL(mapURL, "hol/hol.html");
            if(tfm.isID(uu) == true) {
                return Status.passed(apiTested + "Okay for Valid URL");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return Valid value for Valid URl");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised for valid URl" 
            + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" isID() \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	    URL mapURL = new URL("file", null, HSLOC + "/holidays/Map.jhm");
            URL uu = new URL(mapURL, "hol/hol.html");
            HelpSet hs = new HelpSet(loader, url);

            FlatMap tfm = new FlatMap(mapURL, hs);
            if(tfm.isID(url) == false) {
                return Status.passed(apiTested 
                + "Okay ; returns false for Invalid url");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return Valid value for Invalid URL");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised for Invalid URL" 
            + ee);
        }
    } //testCase2 finished
}

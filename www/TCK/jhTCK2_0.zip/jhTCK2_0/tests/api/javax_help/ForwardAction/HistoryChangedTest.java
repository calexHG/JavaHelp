/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... ForwardAction(control).historyChanged(e) --> ForwardAction(control).historyChanged(e)
 */

package javasoft.sqe.tests.api.javax.help.ForwardAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.JHelp;
import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.BackAction;
import javax.help.ForwardAction;
import javax.help.DefaultHelpModel;

import javax.help.event.HelpHistoryModelEvent;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.ForwardAction ... historyChanged(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class HistoryChangedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public HistoryChangedTest() {
    }

    public static void main(String argv[]) {
        HistoryChangedTest test = new HistoryChangedTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void historyChanged(javax.help.event.HelpHistoryModelEvent e)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>e</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void historyChanged(javax.help.event.HelpHistoryModelEvent e): "
            + "TestCase: '(new ForwardAction(control)).historyChanged(e)' "
            + "ExpectedResult: ForwardAction enabled' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
            //create a HelpSet object ... end

            //create a JHelp object ... start
            JHelp jhelp = new JHelp(hs);
            //create a JHelp object ... end

            //create ForwardAction object ... start
            ForwardAction forwardAction = new ForwardAction(jhelp);
            //create ForwardAction object ... end

	    forwardAction.setEnabled(false);

            //go back for changing current ID ... start
            forwardAction.historyChanged(new HelpHistoryModelEvent(new Object(), true, true) );
            //go back for changing current ID ... end

            if(forwardAction.isEnabled()) {
                return Status.passed(apiTested + "ForwardAction enabled");
            } else {
                return Status.failed(apiTested + "Did not enable ForwardAction ");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

    /**
     * Method test: <code>void historyChanged(javax.help.event.HelpHistoryModelEvent e)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>e</code> valid value
     */
    public Status testCase2() {
        String apiTested = "void historyChanged(javax.help.event.HelpHistoryModelEvent e): "
            + "TestCase: '(new ForwardAction(control)).historyChanged(e)' "
            + "ExpectedResult: ForwardAction disabled' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
            //create a HelpSet object ... end

            //create a JHelp object ... start
            JHelp jhelp = new JHelp(hs);
            //create a JHelp object ... end

            //create ForwardAction object ... start
            ForwardAction forwardAction = new ForwardAction(jhelp);
            //create ForwardAction object ... end

	    forwardAction.setEnabled(true);

            //go back for changing current ID ... start
            forwardAction.historyChanged(new HelpHistoryModelEvent(new Object(), true, false) );
            //go back for changing current ID ... end

            if(!forwardAction.isEnabled()) {
                return Status.passed(apiTested + "ForwardAction disabled");
            } else {
                return Status.failed(apiTested + "Did not disable ForwardAction ");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}






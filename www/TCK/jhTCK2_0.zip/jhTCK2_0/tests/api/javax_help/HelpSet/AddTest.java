
/*
* @(#)AddTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * for  method:add()Test
 * Add a helpset to another helpset
 * @author Sudhakar.Adini
 */

public class AddTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public AddTest() {
        
    }
    
    public static void main(String argv[]) {
        AddTest test = new AddTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method : add(HelpSet hs) " 
        + "\nTestCase : Call add() " 
        + "\nExpected Result :It should add the HelpSet  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url2 = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            HelpSet hs2 = new HelpSet(l, url2);
            hs1.add(hs2);
            if(hs1.contains(hs2)) {
                return Status.passed(apiTested+"The helpset is added properly");
            }
            else {
                return Status.failed(apiTested + "The helpset is not added ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished	
    
    public Status testCase2() {
        String apiTested = " Method : add(HelpSet hs) " 
        + "\nTestCase : Call add() by passing null for hs" 
        + "\nExpected Result :No Exception should be thrown " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            HelpSet hs2 = null; 
            hs1.add(hs2);
			return Status.passed(apiTested +"Okay");			
        }
        catch(Exception e) {            
			return Status.failed(apiTested +"Got: "+e.toString());
        }		
    } //testcase2 finished
}

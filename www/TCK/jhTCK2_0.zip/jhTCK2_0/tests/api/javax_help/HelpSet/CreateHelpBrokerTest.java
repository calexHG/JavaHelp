
/*
* @(#)CreateHelpBrokerTest.java	1.2 01/08/07
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javax.help.DefaultHelpBroker;
import javax.help.HelpBroker;

//import javax.help.HelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet  
 * Method : createHelpBroker() Test
 * @author Sudhakar.Adini
 */

public class CreateHelpBrokerTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateHelpBrokerTest() {
        
    }
    
    public static void main(String argv[]) {
        CreateHelpBrokerTest test = new CreateHelpBrokerTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method : createHelpBroker()" 
        + "\nTestCase : Call createHelpBroker() " 
        + "\nExpected Result :It should return the HelpBroker object " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            HelpBroker hb = hs1.createHelpBroker();
            HelpSet hs2 = hb.getHelpSet();
            if((hb instanceof HelpBroker) && (hs2.equals(hs1))) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"It did not return HelpBroker");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished
}

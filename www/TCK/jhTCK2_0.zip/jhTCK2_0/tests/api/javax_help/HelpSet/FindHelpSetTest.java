
/*
* @(#)FindHelpSetTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 *
 * Method : findHelpSet(ClassLoader cl,String name) &
 * Method : findHelpSet(ClassLoader cl,String name, Locale locale) &
 * Method : findHelpSet(ClassLoader cl,String shortName,
 *			String extension, Locale locale)
 *
 * @author Sudhakar.Adini
 */

public class FindHelpSetTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public FindHelpSetTest() {
        
    }
    
    public static void main(String argv[]) {
        FindHelpSetTest test = new FindHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name)" 
        + "\nTestCase : Call findHelpSet(ClassLoader cl,String name) " 
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory.hs";
            URL url2 = HelpSet.findHelpSet(l, s1);
            if(url2 instanceof URL) {
                return Status.passed(apiTested +  "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the url ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished			
    
    public Status testCase2() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name)" 
        + "\nTestCase : Call findHelpSet() without .hs extension " 
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory";
            URL url2 = HelpSet.findHelpSet(l, s1);
            if(url2 instanceof URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the url");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase2 finished				
    
    public Status testCase3() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name)" 
        + "\nTestCase : Call findHelpSet() with incorrect resource " 
        + "\nExpected Result :It should return null  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "Holiday.hs";
            URL url2 = HelpSet.findHelpSet(l, s1);
            if(url2 == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the null");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase3 finished
    
    public Status testCase4() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name)" 
        + "\nTestCase : Call findHelpSet() by passin null for name " 
        + "\nExpected Result :It throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = null;
            URL url2 = HelpSet.findHelpSet(l, s1);
            return Status.failed(apiTested + "Exception not raised");
        }
		catch(NullPointerException e) {
			return Status.passed(apiTested + "Got:  " + e.toString());
		}
        catch(Exception e) {
            return Status.failed(apiTested + "Got:  " + e.toString());
        }
    } //testcase4 finished			
    
    public Status testCase5() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name)" 
        + "\nTestCase : Call findHelpSet() by passin null for cl " 
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";
        try {           
            ClassLoader l = null;
            String s1 = "HolidayHistory.hs";            
            URL url2 = HelpSet.findHelpSet(l, s1);
            if(url2 instanceof URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {            
                return Status.failed(apiTested + "Got:  " + e.toString());          
        }
    } //testcase5 finished			

    public Status testCase6() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet()  " 
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory.hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, lc);
            if(url2 instanceof URL) {
                return Status.passed(apiTested +  "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase6 finished    
    
    public Status testCase7() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet() without .hs extension "  
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";			
            try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, lc);
            if(url2 instanceof URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase7 finished      
    
    public Status testCase8() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet() with incorrect resource " 
        + "\nExpected Result :It should return null  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "Holiday.hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, lc);            
            if(url2 == null) {
                return Status.passed(apiTested +  "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {            
                return Status.failed(apiTested + "Got:  "  + e.toString());           
        }
    } //testcase8 finished      
    
    public Status testCase9() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet() by passin null for name "  
        + "\nExpected Result :It throw NullPointerException  "  
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = null;
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, lc);
           	return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got: " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got:  " + e.toString());
            }
        }
    } //testcase9 finished    
  
    public Status testCase10() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet() by passing null for locale " 
        + "\nExpected Result :It throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory.hs";
            Locale lc = null;             
            URL url2 = HelpSet.findHelpSet(l, s1, lc);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got:  " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got:  " + e.toString());
            }
        }
    } //testcase10 finished     
    
    public Status testCase11() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,String name,"
        + " Locale locale)"
        + "\nTestCase : Call findHelpSet() by passin null for cl "
        + "\nExpected Result :It should return the url "
        + "\nObtained Result : ";
        try {            
            ClassLoader l = null;
            String s1 = "HolidayHistory.hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, lc);
            if(url2 instanceof URL) {
                return Status.passed(apiTested +  "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {           
                return Status.failed(apiTested + "Got:  "  + e.toString());           
        }
    } //testcase11 finished
	
    public Status testCase12() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)" 
        + "\nTestCase : Call findHelpSet()  " 
        + "\nExpected Result :It should return the url  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory";
            String s2 = ".hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);
            if(url2 instanceof URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase12 finished    
    
    public Status testCase13() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)" 
        + "\nTestCase : Call findHelpSet() by passing null for extension " 
        + "\nExpected Result :It should return null  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory";
            String s2 = null;
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);            
            if(url2 == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase13 finished   
    
    public Status testCase14() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)" 
        + "\nTestCase : Call findHelpSet() by passing null for shortName " 
        + "\nExpected Result :It should throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = null;
            String s2 = ".hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);           
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got: " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got: " + e.toString());
            }        
        }
    } //testcase14 finished    
    
    public Status testCase15() {
       String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)"
        + "\nTestCase :Call findHelpSet() with incorrect resource for shortName" 
        + "\nExpected Result :It should return null  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "Holiday";
            String s2 = ".hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);            
            if(url2 == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {           
                return Status.failed(apiTested + "Got:  " + e.toString());          
        }
    } //testcase15 finished    
    
    public Status testCase16() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extn, Locale locale)"
        + "\nTestCase : Call findHelpSet() by passing null for shortName & extn" 
        + "\nExpected Result :It should throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = null;
            String s2 = null;
            Locale lc = Locale.getDefault();           
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got:  " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got:  " + e.toString());
            }
        }
    } //testcase16 finished    
    
    public Status testCase17() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)"
        + "\nTestCase : Call findHelpSet() by passing null for locale " 
        + "\nExpected Result :It should throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            String s1 = "HolidayHistory";
            String s2 = ".hs";
            Locale lc = null; 
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got:  " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got:  " + e.toString());
            }
        }
    } //testcase17 finished    
    
    public Status testCase18() {
        String apiTested = " Method : findHelpSet(ClassLoader cl,"
        + "String shortName,String extension, Locale locale)"
        + "\nTestCase : Call findHelpSet() by passin null for cl " 
        + "\nExpected Result :It should return the url " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = null;
            String s1 = "HolidayHistory";
            String s2 = ".hs";
            Locale lc = Locale.getDefault();            
            URL url2 = HelpSet.findHelpSet(l, s1, s2, lc);
            if(url2 instanceof URL) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not returns the url ");
            }
        }
        catch(Exception e) {            
                return Status.failed(apiTested + "Got:  " + e.toString());           
        }
    } //testcase18 finished
}

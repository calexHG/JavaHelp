
/*
* %W% %E%
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.awt.Button;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import com.sun.help.jck.harness.FooHelpSetListener;
import com.sun.help.jck.harness.StaticInfo;
import com.sun.help.jck.harness.FireHelperTest;
/**
 * Tests for javax.help.HelpSet
 * fireHelpSetAdded(Object source, HelpSet helpset) Test
 * 
 * @author Sudhakar.Adini
 */

public class FireHelpSetAddedTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public FireHelpSetAddedTest() {
        
    }
    
    public static void main(String argv[]) {
        FireHelpSetAddedTest test = new FireHelpSetAddedTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }  
 
    public Status testCase1() {
        String apiTested = " Method : fireHelpSetAdded(Object source,"
        + "HelpSet helpset)" 
        + "\nTestCase : addHelpSetListener , Call fireHelpSetAdded() and "
        + " check if listener for HelpSetEvent is notified" 
        + "\nExpected Result :helpSetAdded() of HelpSetListener shd be called."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            Button source=new Button("Source");            
            FooHelpSetListener l = new FooHelpSetListener();
            FireHelperTest fire=new FireHelperTest();
            fire.addHelpSetListener(l);
            fire.fireAdd(source,hs);            
            /*
             StaticInfo.bool is set to true within helpSetAdded() of 
             FooHelpSetListener
            */
            if(StaticInfo.bool == true) {
                return Status.passed(apiTested + "helpSetAdded() of "
                	+ "HelpSetListener is called.\n");
            }
            else {
                return Status.failed(apiTested + "helpSetAdded() of "
                	+ "HelpSetListener is not called.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Did not add HelpSet ,"
            	+ " Got Exception : " + e.toString()+ "\n");
        }
    }
 
    public Status testCase2() {
        String apiTested = " Method : fireHelpSetAdded(Object source,"
        + "HelpSet helpset)" 
        + "\nTestCase : addHelpSetListener ,Call fireHelpSetAdded() by passing"
        + " null for source and check if listener for HelpSetEvent is notified" 
        + "\nExpected Result :helpSetAdded() of HelpSetListener shd be called."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            Button source=null;//new Button("Source");            
            FooHelpSetListener l = new FooHelpSetListener();
            FireHelperTest fire=new FireHelperTest();
            fire.addHelpSetListener(l);
            fire.fireAdd(source,hs);            
            /*
             StaticInfo.bool is set to true within helpSetAdded() of 
             FooHelpSetListener
            */
            if(StaticInfo.bool == true) {
                return Status.passed(apiTested + "helpSetAdded() of "
                	+ "HelpSetListener is called.\n");
            }
            else {
                return Status.failed(apiTested + "helpSetAdded() of "
                	+ "HelpSetListener is not called.\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Did not add HelpSet ,"
            	+ " Got Exception : " + e.toString()+ "\n");
        }
    }

    public Status testCase3() {
        String apiTested = " Method : fireHelpSetAdded(Object source,"
        + "HelpSet helpset)" 
        + "\nTestCase : addHelpSetListener ,Call fireHelpSetAdded() by passing"
        + " null for helpset and check if listener for HelpSetEvent is notified" 
        + "\nExpected Result :helpSetAdded() of HelpSetListener shd be called."
        + " No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = null;//new HelpSet(cl, url);
            Button source=new Button("Source");            
            FooHelpSetListener l = new FooHelpSetListener();
            FireHelperTest fire=new FireHelperTest();
            fire.addHelpSetListener(l);
            fire.fireAdd(source,hs);            
	    return Status.failed(apiTested + "No Exception raised");
        }
        catch(Exception e) {
	    if(e instanceof NullPointerException) {
		return Status.passed(apiTested + "Got : "+ e.toString());
	    } else {	
                return Status.failed(apiTested + "Did not add HelpSet , " +
				     "Got Exception : "+ e.toString());
	    }
        }
    }    
   }  

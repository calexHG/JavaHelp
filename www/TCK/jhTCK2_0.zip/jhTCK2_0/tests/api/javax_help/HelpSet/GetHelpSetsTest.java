
/*
* @(#)GetHelpSetsTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.util.Locale;
import java.util.*;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * Method : getHelpSets()
 
 * @author Sudhakar.Adini
 */

public class GetHelpSetsTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpSetsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHelpSetsTest test = new GetHelpSetsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method : getHelpSets() " 
        + "\nTestCase : Call getHelpSets() after adding helpsets  " 
        + "\nExpected Result :It should return the Enumeration of helpsets  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url2 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url3 = new URL("file", null, HSLOC + "/object/Object.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            HelpSet hs2 = new HelpSet(l, url2);
            HelpSet hs3 = new HelpSet(l, url3);
			HelpSet hsall[]={hs2,hs3};
            hs1.add(hs2);
            hs1.add(hs3);
			int count=0;
            Enumeration en = hs1.getHelpSets();
            if(en.hasMoreElements()) {
                int i = 0;
                for(;en.hasMoreElements();i++) {
                    HelpSet got = (HelpSet)en.nextElement();
                    if(got.equals(hsall[i])) {
					count++;                       
                    }
                    else {
                        return Status.failed(apiTested + "failed");
                    }
                }
				if(count==2)				
                return Status.passed(apiTested + "Okay");
				else
				return Status.failed(apiTested + "Failed");
            }
            else {
                return Status.failed(apiTested + 
                	"This helpset did not returns the added helpsets ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished    
    
    public Status testCase2() {
        String apiTested = " Method : getHelpSets() " 
        + "\nTestCase : Call getHelpSets() without adding any helpsets " 
        + "\nExpected Result :It should not return the Enumeration of helpsets " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            Enumeration en = hs1.getHelpSets();           
            if(!en.hasMoreElements()) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase2 finished
}

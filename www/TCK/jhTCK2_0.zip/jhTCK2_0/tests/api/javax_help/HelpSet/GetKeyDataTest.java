
/*
*  @(#)GetKeyDataTest.java	1.2 01/08/07
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * Method : getKeyData(Object context,String key)Test 
 
 * @author Sudhakar.Adini
 */

public class GetKeyDataTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetKeyDataTest() {
        
    }
    
    public static void main(String argv[]) {
        GetKeyDataTest test = new GetKeyDataTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method : getKeyData(Object context,String key) " 
        + "\nTestCase : Call getKeyData(Object context,String key)  " 
        + "\nExpected Result :It should return the data  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "Thank You";
            String key = "ok";
            String context = "get";
            hs1.setKeyData(context, key, data);
            String data1 = (String)hs1.getKeyData(context, key);            
            if(data1.equals(data)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the data");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"Got  : " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got  : " + e.toString());
            }
        }
    } //testcase1 finished    
    
    public Status testCase2() {
        String apiTested = " Method : getKeyData(Object context,String key) " 
        + "\nTestCase : Call getKeyData(null,String key)  " 
        + "\nExpected Result :It should throw NullPointerException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "Thank You";
            String key = "ok";
            String context = "get";
            String context1 = null;            
            String data1 = (String)hs1.getKeyData(context1, key);
            if(data1 == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the data");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"Got  : " + e.toString());
            }
            else {
                return Status.failed(apiTested +"Got  : " + e.toString());
            }
        }
    } //testcase2 finished  
    
    public Status testCase3() {
        String apiTested = " Method : getKeyData(Object context,String key) " 
        + "\nTestCase : Call getKeyData(Object context,null)  " 
        + "\nExpected Result :It should return null  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "Thank You";
            String key = "ok";
            String context = "get";
            String key1 = null;
            String data1 = (String)hs1.getKeyData(context, key1);            
            if(data1 == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the data");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"Got :  " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got :  " + e.toString());
            }
        }
    } //testcase3 finished					
}

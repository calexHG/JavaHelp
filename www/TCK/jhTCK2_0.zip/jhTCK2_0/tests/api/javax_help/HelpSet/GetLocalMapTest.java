
/*
* @(#)GetLocalMapTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import java.util.Locale;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 *	Method :getLocalMap()
 
 * @author Sudhakar.Adini
 */

public class GetLocalMapTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetLocalMapTest() {
        
    }
    
    public static void main(String argv[]) {
        GetLocalMapTest test = new GetLocalMapTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }    
    
    
    public Status testCase1() {
        String apiTested = " Method :getLocalMap()"
        + "\nTestCase : Call getLocale() after setting the Map "  
        + "\nExpected Result :It should return the same Map  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url3 = new URL("file", null, HSLOC + "/merge/Master.jhm");
            HelpSet hs1 = new HelpSet(l, url1);
            HelpSet hs2 = new HelpSet(l, url2);
            FlatMap fp = new FlatMap(url3, hs2);
            hs1.setLocalMap(fp);
            Map mp = hs1.getLocalMap();            
            if(fp == mp) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It did not return the same");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished  
   
    
    public Status testCase2() {
        String apiTested = " Method :getLocalMap()"
       	+ "\nTestCase : Call getLocale()  "  
        + "\nExpected Result :It should return the Map for the helpset " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            Map mp = hs1.getLocalMap();             
            if(mp instanceof Map) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "It  did not return the Map");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase2 finished
	
 	/*
	* Testing of getLocalMap() after calling setLocalMap(null) is tested in 
	* SetLocalMapTest.java
	*/	  
}

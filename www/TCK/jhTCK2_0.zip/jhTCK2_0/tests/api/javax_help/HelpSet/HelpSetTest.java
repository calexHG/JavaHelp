
/*
* @(#)HelpSetTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * constructorTest
 * 
 * @author Sudhakar.Adini
 */

public class HelpSetTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public HelpSetTest() {
        
    }
    
    public static void main(String argv[]) {
        HelpSetTest test = new HelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Constructor: HelpSet(ClassLoader loader,URL url)" 
        + "\nTestCase : Call HelpSet " 
        + "\nExpected Result :It should construct the HelpSet object  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(l, url);            
            URL url1 = hs.getHelpSetURL();
            ClassLoader l1 = hs.getLoader();
            if(hs instanceof HelpSet) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = " Constructor: HelpSet(ClassLoader loader,URL url)" 
        + "\nTestCase : Call HelpSet with bad url" 
        + "\nExpected Result :It should throw  HelpSetException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Mas.hs");
            HelpSet hs = new HelpSet(l, url);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception ex) {
            if(ex instanceof HelpSetException) {
                return Status.passed(apiTested + "Got: " + ex.toString());
            }
            else {
                return Status.failed(apiTested + "Got: " + ex.toString());
            }
        }
       
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = " Constructor: HelpSet(ClassLoader loader,URL url)" 
        + "\nTestCase : Call HelpSet by passing null for loader" 
        + "\nExpected Result :It should construct the HelpSet object   " 
        + "\nObtained Result : ";
        try {            
            ClassLoader l = null;
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(l, url);            
            if(hs instanceof HelpSet) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = " Constructor: HelpSet(ClassLoader loader,URL url)" 
        + "\nTestCase : Call HelpSet by passing null for url" 
        + "\nExpected Result :It should throw  HelpSetException  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();           
            URL url = null;
            HelpSet hs = new HelpSet(l, url);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception ex) {
            if(ex instanceof HelpSetException) {
                return Status.passed(apiTested + "Got: "  + ex.toString());
            }
            else {
                return Status.failed(apiTested + "Got: "  + ex.toString());
            }
        }
        
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = " Constructor: HelpSet()" 
        + "\nTestCase : Call HelpSet " 
        + "\nExpected Result :It should construct the HelpSet object  " 
        + "\nObtained Result : ";
        try {            	
            HelpSet hs = new HelpSet();            
            if(hs instanceof HelpSet) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = " Constructor: HelpSet(java.lang.ClassLoader loader)" 
        + "\nTestCase : Call HelpSet " 
        + "\nExpected Result :It should construct the HelpSet object  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();            
            HelpSet hs = new HelpSet(l);            
            if(hs instanceof HelpSet) {
                return Status.passed(apiTested + "Okay1");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = " Constructor: HelpSet(java.lang.ClassLoader loader)" 
        + "\nTestCase : Call HelpSet by passing null for loader"
         + "\nExpected Result :It should construct the HelpSet object  " 
         + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();          
            HelpSet hs = new HelpSet(l);            
            if(hs instanceof HelpSet) {
                return Status.passed(apiTested + "Okay1");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase7 finished
}


/*
* @(#)ParseIntoTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import java.net.URL;
import java.util.*;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 *
 * Method parseInto(URL url,HelpSetFactory factory) Test
 * @author Sudhakar.Adini
 */

public class ParseIntoTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ParseIntoTest() {
        
    }
    
    public static void main(String argv[]) {
        ParseIntoTest test = new ParseIntoTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "parseInto(URL url,HelpSetFactory factory) " 
        + "\nTestCase : Call parseInto with valid values for url ,factory " 
        + "\nExpected Result :Shd parse into this HelpSet.No exception raised" 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url1 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");           
            HelpSet hs=new HelpSet(cl,url);
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            hs.parseInto(url1, defaultFactory);
            return Status.passed(apiTested + "Okay ");
        }
        catch(Exception e) {
            return Status.failed(apiTested + " Got Exception :" + e.toString());
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "parseInto(URL url,HelpSetFactory factory) " 
        + "\nTestCase : Call parseInto by passing bad url " 
        + "\nExpected Result :Shd parse into this HelpSet.No exception raised" 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url1 = new URL("file", null, HSLOC + "/holidays/Holiday.hs");            
            HelpSet hs=new HelpSet(cl,url);
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            hs.parseInto(url1, defaultFactory);
            return Status.passed(apiTested + "Okay ");
        }
        catch(Exception e) {            
                return Status.failed(apiTested + "Got :  " + e.toString());           
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "parseInto(URL url,HelpSetFactory factory) " 
        + "\nTestCase : Call parseInto by passing null url " 
        + "\nExpected Result :Shd parse into this HelpSet.No exception raised" 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader(); 
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");           
            URL url1 = null;
            HelpSet hs=new HelpSet(cl,url);            
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            hs.parseInto(url1, defaultFactory);
            return Status.passed(apiTested + "Okay : ");
        }
        catch(Exception e) {           
                return Status.failed(apiTested + "Got:   " + e.toString());          
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "parseInto(URL url,HelpSetFactory factory) " 
        + "\nTestCase : Call parseInto by passing null for factory " 
        + "\nExpected Result :Shd throw NullPointerException" 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            URL url1 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs=new HelpSet(cl,url);
            DefaultHelpSetFactory defaultFactory = null; 
            hs.parseInto(url1, defaultFactory);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + " Got:   " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got:  " + e.toString());
            }
        }
    } //testCase4 finished
}

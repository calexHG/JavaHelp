
/*
* @(#)ParseTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.HelpSet.DefaultHelpSetFactory;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * Method parse(URL url,ClassLoader loader,HelpSetFactory factory) Test
 
 * @author Sudhakar.Adini
 */

public class ParseTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ParseTest() {
        
    }
    
    public static void main(String argv[]) {
        ParseTest test = new ParseTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "parse(URL url,ClassLoader cl,HelpSetFactory fac) :" 
        + "\nTestCase : Call parse with valid values for url , cl  ,fac " 
        + "\nExpected Result :Shd return the Helpset.No Exception shd be thrown" 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            HelpSet gotHS = HelpSet.parse(url, cl, defaultFactory);
            if(gotHS instanceof HelpSet) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return the HelpSet.");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + " Got Exception " + e.toString());
        }
    }
    
    public Status testCase2() {
        String apiTested = "parse(URL url,ClassLoader cl,HelpSetFactory fac)"  
        + "\nTestCase : Call parse with bad url and valid values for cl,fac " 
        + "\nExpected Result :Shd return null.No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/invalid/invalid.hs");
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            HelpSet gotHS = HelpSet.parse(url, cl, defaultFactory);
            if(gotHS == null) {
                return Status.passed(apiTested +"Okay");               
            }
            else {
                return Status.failed(apiTested + "Failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + " Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        String apiTested = "parse(URL url,ClassLoader cl,HelpSetFactory fac) : " 
        + "\nTestCase :Call parse with  url as null and valid values for cl,fac" 
        + "\nExpected Result :Shd return null.No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = null;
            DefaultHelpSetFactory defaultFactory = new DefaultHelpSetFactory();
            HelpSet gotHS = HelpSet.parse(url, cl, defaultFactory);
            if(gotHS == null) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested +" Got Exception : " + e.toString());
        }
    }
    
    public Status testCase4() {
        String apiTested = "parse(URL url,ClassLoader cl,HelpSetFactory fac ) " 
        + "\nTestCase :Call parse with  fac as null and valid values for url,cl" 
        + "\nExpected Result :Should return NullPointerException " 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            DefaultHelpSetFactory defaultFactory = null;
            HelpSet gotHS = HelpSet.parse(url, cl, defaultFactory);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "Got: " + e.toString());
            }
            else {
                return Status.failed(apiTested + "Got: " + e.toString());
            }       
        }
    }
}


/*
*  @(#)RemoveHelpSetListenerTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooHelpSetListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import javax.help.event.HelpSetListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * Method:removeHelpSetListener(HelpSetListener l)
 
 * @author Sudhakar.Adini
 */

public class RemoveHelpSetListenerTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public RemoveHelpSetListenerTest() {
        
    }
    
    public static void main(String argv[]) {
        RemoveHelpSetListenerTest test = new RemoveHelpSetListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method:removeHelpSetListener(HelpSetListener l) : " 
        + "\nTestCase : Create HelpSetListener object and pass it  "
        + "to removeHelpSetListener" 
        + "\nExpected Result :Shd remove HelpSetListener."
        + "No Exception shd be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            FooHelpSetListener l = new FooHelpSetListener();
            hs.removeHelpSetListener(l);
            return Status.passed(apiTested + "Removed HelpSetListener."
            		+ "No Exception thrown\n");
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Did not remove HelpSetListener ,"
            		+" Got Exception : " + e.toString());
        }
    }
    
    public Status testCase2() {
        String apiTested = "addHelpSetListener(HelpSetListener l) : " 
        + "\nTestCase : addHelpSetListener , Call add(HelpSet h) and" 
        + "check if listener for HelpSetEvent is notified" 
        + "\nExpected Result :helpSetRemoved() of HelpSetListener shd be called."
        + "No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        /* Initialize the bool value to false */
        StaticInfo.check = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);            
            FooHelpSetListener l = new FooHelpSetListener();
            hs.addHelpSetListener(l);
            URL url2 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs2 = new HelpSet(cl, url2);
            hs.add(hs2);
            hs.remove(hs2);
            
            /*
             StaticInfo.check is set to true within helpSetRemoveded() of 
             FooHelpSetListener 
            */
            if(StaticInfo.check == true) {
                return Status.passed(apiTested            
                	+ "helpSetRemoved() of HelpSetListener is called.\n");
            }
            else {
                return Status.failed(apiTested 
                	+"helpSetRemoved() of HelpSetListener is not called ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested  
            	+ "Did not add HelpSetListener , Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        String apiTested = "removeHelpSetListener(HelpSetListener l) : " 
        + "\nTestCase : Pass null to removeHelpSetListener" 
        + "\nExpected Result :IllegalArgumentException shd be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            FooHelpSetListener l = null;
            hs.removeHelpSetListener(l);
            return Status.failed(apiTested + 
            	"Did not Get IllegalArgumentException thrown\n");
        }
        catch(IllegalArgumentException iae) {
            return Status.passed(apiTested 
            	+ "Got IllegalArgumentException : " + iae + "\n");
        }
        catch(Exception e) {
            return Status.failed(apiTested 
            + "Did not get IllegalArgumentException , Got Exception : " + e );
        }
    }
}

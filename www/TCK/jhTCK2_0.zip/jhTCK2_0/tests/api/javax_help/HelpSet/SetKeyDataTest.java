
/*
* @(#)SetKeyDataTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.HelpSet;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet
 * Method setKeyData(Object context,String key,Object data)
 
 * @author Sudhakar.Adini
 */

public class SetKeyDataTest extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetKeyDataTest() {
        
    }
    
    public static void main(String argv[]) {
        SetKeyDataTest test = new SetKeyDataTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested =" Method :setKeyData(Object con,String key,Object dt)" 
        + "\nTestCase : Call setKeyData(Object con,String key,Object dt) " 
        + "\nExpected Result :It should sets the KeyData  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "Thank you";
            String key = "ok";
            String context = "get";
            hs1.setKeyData(context, key, data);
            String data1 = (String)hs1.getKeyData(context, key);            
            if(data1.equals(data)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested +"It did not sets the KeyData");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testcase1 finished    
    
    public Status testCase2() {
        String apiTested =" Method :setKeyData(Object con,String key,Object dt)" 
        + "\nTestCase : Call setKeyData(Object con,String key,null) " 
        + "\nExpected Result :It should throw NullPointerException " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = null;
            String key = "ok";
            String context = "get";
            hs1.setKeyData(context, key, data);
			return Status.failed(apiTested + "Exception not raised");           
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + "GotException"+ e.toString());
            }
            else {
                return Status.failed(apiTested +"Got Exception "+ e.toString());
            }
        }
    } //testcase2 finished    
    
    public Status testCase3() {
        String apiTested =" Method :setKeyData(Object con,String key,Object dt)" 
        + "\nTestCase : Call setKeyData(Object con,null,Object dt) " 
        + "\nExpected Result :It should throw NullPointerException " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "ThankYou";
            String key = null; //"ok";
            String context = "get";
            hs1.setKeyData(context, key, data);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"Got Exception" + e.toString());
            }
            else {
                return Status.failed(apiTested +"Got Exception" + e.toString());
            }
        }
    } //testcase3 finished   
    
    public Status testCase4() {
        String apiTested =" Method :setKeyData(Object con,String key,Object dt)" 
        + "\nTestCase : Call setKeyData(null,String key,Object dt) " 
        + "\nExpected Result :It should throw NullPointerException " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs1 = new HelpSet(l, url1);
            String data = "Thank You";
            String key = "ok";
            String context = null; //"get";
            hs1.setKeyData(context, key, data);
            return Status.failed(apiTested + "Exception not raised");
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"Got Exception "+ e.toString());
            }
            else {
                return Status.failed(apiTested +"Got Exception "+ e.toString());
            }
        }
    } //testcase4 finished
}

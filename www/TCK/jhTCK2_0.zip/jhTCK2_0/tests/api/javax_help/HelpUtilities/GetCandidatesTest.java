/*
 * @(#)GetCandidatesTest.java	1.7 00/09/14
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Enumeration;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
 
public class GetCandidatesTest extends MultiTest {
       
    public GetCandidatesTest() {
        
    }
    
    public static void main(String argv[]) {
        GetCandidatesTest test = new GetCandidatesTest();
        Status s = test.run(argv, new PrintWriter(System.out),
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getCandidates(Locale locale) : " 
        + "\nTestCase : Call getCandidates with default locale " 
        + "default" 
        + "\nExpected Result : Shd return an Enumeration containing spec.d " 
        + "Strings." 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            Locale locale = Locale.getDefault();
            String str[] =  {"",  "" ,""};
            String x = locale.getVariant();
            String y = locale.getCountry();
            String z = locale.getLanguage();

            if (y.length() == 0) {
               str[0] = "_" + z;
               str[1] = x;
            } else {
               str[0] = "_" + z + "_" + y ;
               str[1] = "_" + z;
               str[2] = x;
            }
            Enumeration e = HelpUtilities.getCandidates(locale);
            int i = 0;
            for(;i < 3 && e.hasMoreElements();i++) {
                String loc = (String)e.nextElement();
                if(!loc.equals(str[i])) {
                    check = false;
                    break;
                }
            }
            if(e.hasMoreElements()) {
                check = false;
            }
            if(check) {
                return Status.passed(apiTested + "Got Correct Enumeration\n");
            } else {
                return Status.failed(apiTested + "Did not get Correct " 
                    + "Enumeration.\n");
            }
        } catch(Exception e) {
            e.printStackTrace();	
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getCandidates(Locale locale) : " 
        + "\nTestCase : Call getCandidates with locale fr_FR_WIN and default " 
        + "\nExpected Result : Shd return an Enumeration containing spec.d " 
        + "Strings." 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            Locale locale = new Locale("fr", "FR", "WIN");
            Locale locale2 = Locale.getDefault();
            String x = locale2.getVariant();
            String y = locale2.getCountry();
            String z = locale2.getLanguage();

            String str[] =  {
                "_fr_FR_WIN", "_fr_FR", "_fr", "", "" , ""
            };

            // fill array with default locale
            if (y.length() == 0) {
               str[3] = x;
               str[4] = "_" + z;
               str[5] = "_" + z;
            } else {
               str[3] = x;
               str[4] = "_" + z + "_" + y ;
               str[5] = "_" + z;
            }

            Enumeration e = HelpUtilities.getCandidates(locale);
            int i = 0;
            for(;i < 6 && e.hasMoreElements();i++) {
                String loc = (String)e.nextElement();
                if(!loc.equals(str[i])) {
                    check = false;
                    break;
                }
            }
            if(e.hasMoreElements()) {
                check = false;
            }
            if(check) {
                return Status.passed(apiTested + "Got Correct Enumeration\n");
            } else {
                return Status.failed(apiTested + "Did not get Correct " 
                    + "Enumeration.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "getCandidates(Locale locale) : " 
        + "\nTestCase : Call getCandidates with null locale" 
        + "\nExpected Result : NullPointerException shd be thrown ." 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            Locale locale = null;
            Enumeration e = HelpUtilities.getCandidates(locale);
            return Status.failed(apiTested + "Did not get NullPointer" 
                + "Exception.\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

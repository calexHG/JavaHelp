/*
 * @(#)GetIDStringFromBeanTest.java	1.4 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import com.sun.help.jck.harness.HolHisBean;
import com.sun.help.jck.harness.EmptyBean;
//import NoPackBean;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetIDStringFromBeanTest extends MultiTest {
    
    public GetIDStringFromBeanTest() {
        
    }
    
    public static void main(String argv[]) {
        GetIDStringFromBeanTest test =
                new GetIDStringFromBeanTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getIDStringFromBeanTest(Class beanClass) : " 
        + "\nTestCase : Call getHelpIDStringFromBean with valid beanClass " 
        + "\nExpected Result : Shd return associated IDString" 
        + "\nObtained Result : ";
        
        try {
            HolHisBean bean = new HolHisBean();
            Class beanClass = bean.getClass();
            String gotStr = HelpUtilities.getIDStringFromBean(beanClass);
            String ExpectedStr = "hol_intro";
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested+"Got the associated ID String" 
                    + " \nGot str = " + gotStr + "\n");
            } else {
                return Status.failed(apiTested + "Did not get associated ID " 
                    + "String .\nGot str = " + gotStr + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getIDStringFromBeanTest(Class beanClass) : " 
        + "\nTestCase : Call getHelpIDStringFromBean with invalid " 
        + "( doesn't have ID String def.d ) beanClass " 
        + "\nExpected Result : Shd return default ID String" 
        + "\nObtained Result : ";
        
        try {
            EmptyBean bean = new EmptyBean();
            Class beanClass = bean.getClass();
            String gotStr = HelpUtilities.getIDStringFromBean(beanClass);
            String ExpectedStr = "com.sun.help.jck.harness.EmptyBean.topID";
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the default ID String." 
                    + "\nGot str = " + gotStr + "\n");
            } else {
                return Status.failed(apiTested + "Did not get default ID " 
                    + "String.\nGot str = " + gotStr + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

    /*
    public Status testCase3() {
    	
        String apiTested = "getIDStringFromBeanTest(Class beanClass) : " 
        + "\nTestCase : Call getHelpIDStringFromBean with invalid ( doesn't " 
        + "have helpSetName def.d or package def.d) beanClass " 
        + "\nExpected Result : Shd return default ID String" 
        + "\nObtained Result : ";
        
        try {
            NoPackBean bean = new NoPackBean();
            Class beanClass = bean.getClass();
            String gotStr = HelpUtilities.getIDStringFromBean(beanClass);
            String ExpectedStr = "NoPackBean.topID";
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the default ID String." 
                    + "\nGot str = " + gotStr + "\n");
            } else {
                return Status.failed(apiTested + "Did not get default ID " 
                    + "String.\nGot str = " + gotStr + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }*/

    //public Status testCase4() {
    public Status testCase3() {
    	
        String apiTested = "getIDStringFromBeanTest(Class beanClass) : " 
        + "\nTestCase : Call getHelpIDStringFromBean with null beanClass " 
        + "\nExpected Result : Shd get NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Class beanClass = null;
            String gotStr = HelpUtilities.getIDStringFromBean(beanClass);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

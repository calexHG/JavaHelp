/*
 * @(#)GetLocaleTest.java	1.4 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Enumeration;
import java.awt.Button;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetLocaleTest extends MultiTest {
    
    public GetLocaleTest() {
        
    }
    
    public static void main(String argv[]) {
        GetLocaleTest test = new GetLocaleTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getLocale(Component comp) : " 
        + "\nTestCase : Call getLocale after setting a locale fro comp" 
        + "\nExpected Result : Shd return the same locale as set for the comp" 
        + "\nObtained Result : ";
        
        try {
            Button comp = new Button();
            Locale locale = new Locale("fr", "FR");
            comp.setLocale(locale);
            Locale gotLocale = HelpUtilities.getLocale(comp);
            if(locale.equals(gotLocale)) {
                return Status.passed(apiTested + "Got the same Locale as comp" 
                    + "\nGiven Locale = " + locale + " , Got Locale = " 
                    + gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale " 
                    + "as comp.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getLocale(Component comp) : " 
        + "\nTestCase : Call getLocale after setting a null locale for comp" 
        + "\nExpected Result : Shd return the default locale " 
        + "\nObtained Result : ";
        
        try {
            Button comp = new Button();
            Locale defLocale = Locale.getDefault();
            Locale locale = null;
            comp.setLocale(locale);
            Locale gotLocale = HelpUtilities.getLocale(comp);
            if(defLocale.equals(gotLocale)) {
                return Status.passed(apiTested + "Got the default Locale. " 
                    + "\nGiven Locale = " + locale + " , Got Locale = " 
                    + gotLocale + "\n");
            } else {
                return Status.failed(apiTested+"Did not get default Locale\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "getLocale(Component comp) : " 
        + "\nTestCase : Call getLocale with null comp" 
        + "\nExpected Result : Shd return the default locale " 
        + "\nObtained Result : ";
        
        try {
            Button comp = null;
            Locale defLocale = Locale.getDefault();
            Locale gotLocale = HelpUtilities.getLocale(comp);
            if(defLocale.equals(gotLocale)) {
                return Status.passed(apiTested + "Got default Locale , " 
                    + "Got Locale = " + gotLocale + "\n");
            } else {
                return Status.failed(apiTested+"Did not get default Locale\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

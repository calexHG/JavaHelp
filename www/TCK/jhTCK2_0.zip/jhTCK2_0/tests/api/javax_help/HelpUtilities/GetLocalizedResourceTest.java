/*
 * @(#)GetLocalizedResourceTest.java	1.8 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Enumeration;
import java.net.URL;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetLocalizedResourceTest extends MultiTest {
       
    public GetLocalizedResourceTest() {
        
    }
    
    public static void main(String argv[]) {
        GetLocalizedResourceTest test =
                new GetLocalizedResourceTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with valid values with " 
        + "default Locale" 
        + "\nExpected Result : Shd return expected url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "IdeHelp";
            String back = ".hs";
            Locale locale = Locale.getDefault();
            URL expURL;
            if(cl == null) {
                expURL = ClassLoader.getSystemResource("IdeHelp_en.hs");
            } else {
                expURL = cl.getResource("IdeHelp_en.hs");
            }
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(expURL.sameFile(url)) {
                return Status.passed(apiTested + "Got correct url." 
                    + "\nGot URL = " + url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get correct url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with valid values with " 
        + "Japanese Locale" 
        + "\nExpected Result : Shd return expected url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "IdeHelp";
            String back = ".hs";
            Locale locale = Locale.JAPANESE;
            URL expURL;
            if(cl == null) {
                expURL = ClassLoader.getSystemResource("IdeHelp_ja.hs");
            } else {
                expURL = cl.getResource("IdeHelp_ja.hs");
            }
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(expURL.sameFile(url)) {
                return Status.passed(apiTested + "Got correct url." 
                    + "\nGot URL = " + url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get correct url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with valid values with " 
        + "invalid Locale ( resource with default locale exists)" 
        + "\nExpected Result :Shd return url for resource with default locale" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "IdeHelp";
            String back = ".hs";
            Locale locale = new Locale("lang", "coun");
            URL expURL = null;
            if(cl == null) {
                expURL = ClassLoader.getSystemResource("IdeHelp_en.hs");
            } else {
                expURL = cl.getResource("IdeHelp_en.hs");
            }
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(expURL.sameFile(url)) {
                return Status.passed(apiTested + "Got correct url." 
                    + "\nGot URL = " + url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get correct url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with valid values with " 
        + "invalid Locale ( resource with no i18n exists)" 
        + "\nExpected Result : Shd return url for resource with no i18n" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "HolidayHistory";
            String back = ".hs";
            Locale locale = new Locale("lang", "coun");
            URL expURL = null;
            if(cl == null) {
                expURL = ClassLoader.getSystemResource("HolidayHistory.hs");
            } else {
                expURL = cl.getResource("HolidayHistory.hs");
            }
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(expURL.sameFile(url)) {
                return Status.passed(apiTested + "Got correct url." 
                    + "\nGot URL = " + url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get correct url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with invalid front and back" 
        + " ( resource does not exist)" 
        + "\nExpected Result : Shd return null url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "invalid";
            String back = ".inv";
            Locale locale = Locale.getDefault();
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(url == null) {
                return Status.passed(apiTested + "Got null url. \nGot URL = " 
                	+ url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get null url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with null front and " 
        + "valid values" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = null;
            String back = ".hs";
            Locale locale = Locale.getDefault();
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase7() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with null back and valid " 
        + "values" 
        + "\nExpected Result : Shd return null url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "IdeHelp";
            String back = null;
            Locale locale = Locale.getDefault();
            
            
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            if(url == null) {
                return Status.passed(apiTested + "Got null url. \nGot URL = " 
                	+ url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get null url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase8() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale) : " 
        + "\nTestCase : Call getLocalizedResource with null locale and valid " 
        + "values" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "IdeHelp";
            String back = ".hs";
            Locale locale = null;
            URL url =HelpUtilities.getLocalizedResource(cl,front,back,locale);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase9() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale , boolean tryRead) : " 
        + "\nTestCase : Call getLocalizedResource with  empty resource and " 
        + "tryRead as true" 
        + "\nExpected Result : Shd return null url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "Empty";
            String back = ".hs";
            Locale locale = Locale.getDefault();
            boolean tryRead = true;
            

            URL url = HelpUtilities.getLocalizedResource(cl,front,back,
                                            locale,tryRead);
            if(url == null) {
                return Status.passed(apiTested + "Got null url. \nGot URL = " 
                	+ url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get null url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase10() {
    	
        String apiTested = "getLocalizedResource(ClassLoader cl,String front," 
        + "String back,Locale locale,boolean tryRead) : " 
        + "\nTestCase : Call getLocalizedResource with  empty resource and " 
        + "tryRead as false" 
        + "\nExpected Result : Shd return  url" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            String front = "Empty";
            String back = ".hs";
            Locale locale = Locale.getDefault();
            boolean tryRead = false;
            URL expURL;
            if(cl == null) {
                expURL = ClassLoader.getSystemResource("Empty.hs");
            } else {
                expURL = cl.getResource("Empty.hs");
            }
            URL url = HelpUtilities.getLocalizedResource(cl, front, back,
                                         locale, tryRead);
            if(url.equals(expURL)) {
                return Status.passed(apiTested + "Got correct url\nGot URL = " 
                	+ url + "\n");
            } else {
                return Status.failed(apiTested + "Did not get correct url." 
                    + "\nGot URL = " + url + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

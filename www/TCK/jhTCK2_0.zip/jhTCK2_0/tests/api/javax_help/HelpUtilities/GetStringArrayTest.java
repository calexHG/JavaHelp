/*
 * @(#)GetStringArrayTest.java	1.7 99/03/18
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetStringArrayTest extends MultiTest {
    
    public GetStringArrayTest() {
        
    }
    
    public static void main(String argv[]) {
        GetStringArrayTest test = new GetStringArrayTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with valid key and default locale" 
        + "\nExpected Result : Shd return array of associated text for key" 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            String key = "YesNoHelpOptions";
            Locale locale = Locale.getDefault();
            String str[] =  {
                "Yes", "No", "Help"
            };
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
            int i = 0;
            for(;i < gotStr.length && i < str.length;i++) {
                if(!gotStr[i].equals(str[i])) {
                    check = false;
                }
            }
            if(i != str.length) {
                check = false;
            }
            if(check) {
                return Status.passed(apiTested + "Got array of  associated " 
                    + "text\n");
            } else {
                return Status.failed(apiTested + "Did not get array of " 
                    + "associated text.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with valid key and Japanese locale" 
        + "\nExpected Result : Shd return array of associated text for key" 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            String key = "YesNoHelpOptions";
            Locale locale = Locale.JAPANESE;
            String str[] =  {
                "\u306f\u3044", "\u3044\u3044\u3048", "\u30d8\u30eb\u30d7"
            };
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
            int i = 0;
            for(;i < gotStr.length && i < str.length;i++) {
                if(!gotStr[i].equals(str[i])) {
                    check = false;
                }
            }
            if(i != str.length) {
                check = false;
            }
            if(check) {
                return Status.passed(apiTested + "Got array of  associated " 
                    + "text\n");
            } else {
                return Status.failed(apiTested + "Did not get array of " 
                    + "associated text.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with invalid key and default locale" 
        + "\nExpected Result : Shd get Error" 
        + "\nObtained Result : ";
        
        try {
            String key = "Invalid";
            Locale locale = Locale.getDefault();
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
	    return Status.failed(apiTested + "Did not get Error\n");
        } catch(Error e) {
            return Status.passed(apiTested + "Got Error : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with valid key and invalid locale" 
        + "\nExpected Result :Shd return array of associated text for default" 
        + "  locale" 
        + "\nObtained Result : ";
        
        try {
            boolean check = true;
            String key = "YesNoHelpOptions";
            Locale locale = new Locale("lang", "coun");
            String str[] =  {
                "Yes", "No", "Help"
            };
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
            int i = 0;
            for(;i < gotStr.length && i < str.length;i++) {
                if(!gotStr[i].equals(str[i])) {
                    check = false;
                }
            }
            if(i != str.length) {
                check = false;
            }
            if(check) {
                return Status.passed(apiTested + "Got array of  associated " 
                    + " text for DefaultLocale. \n");
            } else {
                return Status.failed(apiTested + "Did not get array of "
                    + "associated text for Default Locale.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with null key and default locale" 
        + "\nExpected Result : Shd get NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            Locale locale = Locale.getDefault();
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
    	
        String apiTested = "getStringArray(Locale locale,String key) : " 
        + "\nTestCase : Call getString with valid key and null locale" 
        + "\nExpected Result : Shd get NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = "YesNoHelpOptions";
            Locale locale = null;
            String gotStr[] = HelpUtilities.getStringArray(locale, key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

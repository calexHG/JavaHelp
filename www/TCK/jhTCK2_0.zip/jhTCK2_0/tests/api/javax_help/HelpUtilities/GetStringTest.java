/*
 * @(#)GetStringTest.java	1.7 00/09/14
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetStringTest extends MultiTest {
    
    public GetStringTest() {
        
    }
    
    public static void main(String argv[]) {
        GetStringTest test = new GetStringTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getString(String key) : " 
        + "\nTestCase : Call getString with valid key " 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "index.unknownVersion";
            String ExpectedStr = "Unknown Version {0}.";
            String gotStr = HelpUtilities.getString(key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text." 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+ "\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getString(String key) : " 
        + "\nTestCase : Call getString with invalid key " 
        + "\nExpected Result : Shd get a Error" 
        + "\nObtained Result : ";
        
        try {
            String key = "invalid.key";
            String gotStr = HelpUtilities.getString(key);
            return Status.failed(apiTested + "Did not get Error." 
                + "\nGiven key = " + key + " , Got str = " + gotStr + "\n");
        } catch(Error e) {
            return Status.passed(apiTested + "Got Error : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "getString(String key) : " 
        + "\nTestCase : Call getString with null key " 
        + "\nExpected Result : Shd return NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            String gotStr = HelpUtilities.getString(key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "getString(Locale locale , String key) : " 
        + "\nTestCase : Call getString with valid key and default locale" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "index.unknownVersion";
            Locale locale = Locale.getDefault();
            String ExpectedStr = "Unknown Version {0}.";
            String gotStr = HelpUtilities.getString(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                + " \nGiven key = " + key + " , Got str = " + gotStr + "\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                + "\nGiven key = " + key + " , Got str = " + gotStr + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = "getString(Locale locale , String key) : " 
        + "\nTestCase : Call getString with valid key and japanese locale" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            Locale locale = Locale.JAPANESE;
            String ExpectedStr = "NYI: JH 1.0 \u306f\u30011 \u3064" 
                + "\u306e\u30de\u30c3\u30d7\u30c7\u30fc\u30bf\u3060\u3051" 
                + "\u3092\u53d7\u3051\u4ed8\u3051\u307e\u3059\u3002";
            String gotStr = HelpUtilities.getString(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + " \nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
    	
        String apiTested = "getString(Locale locale , String key) : " 
        + "\nTestCase : Call getString with valid key and invalid locale" 
        + "\nExpected Result : Shd return associated text for key in default" 
        + " locale" 
        + "\nObtained Result : ";
        
        try {
            String key = "index.unknownVersion";
            Locale locale = new Locale("lang", "coun");
            String ExpectedStr = "Unknown Version {0}.";
            String gotStr = HelpUtilities.getString(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " 	+ key + " , Got str = " +gotStr+"\n");
            }
            else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase7() {
    	
        String apiTested = "getString(Locale locale , String key) : " 
        + "\nTestCase : Call getString with valid key and null locale" 
        + "\nExpected Result : Shd get NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = "index.unknownVersion";
            Locale locale = null;
            String ExpectedStr = "Unknown Version {0}.";
            String gotStr = HelpUtilities.getString(locale, key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

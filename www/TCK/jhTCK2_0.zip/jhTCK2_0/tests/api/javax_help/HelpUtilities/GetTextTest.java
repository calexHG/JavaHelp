/*
 * @(#)GetTextTest.java 1.9 99/03/08
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class GetTextTest extends MultiTest {
    
    public GetTextTest() {
        
    }
    
    public static void main(String argv[]) {
        GetTextTest test = new GetTextTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getText(String key) : " 
        + "\nTestCase : Call getText with valid key " 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            String ExpectedStr = "NYI: JH 1.0 only accepts one map data";
            String gotStr = HelpUtilities.getText(key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = "  + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "getText(String key) : " 
        + "\nTestCase : Call getText with invalid key " 
        + "\nExpected Result : Shd get a Error" 
        + "\nObtained Result : ";
        
        try {
            String key = "invalid.key";
            String gotStr = HelpUtilities.getText(key);
            return Status.failed(apiTested + "Did not get Exception." 
                + "\nGiven key = " + key + " , Got str = " + gotStr + "\n");
        } catch(Error err) {
            return Status.passed(apiTested + "Got Error\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "getText(String key) : " 
        + "\nTestCase : Call getText with null key " 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            String gotStr = HelpUtilities.getText(key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested = "getText(Locale locale , String key) : " + 
        "\nTestCase : Call getText with valid key and default locale" + 
        "\nExpected Result : Shd return associated text for key" + 
        "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            Locale locale = Locale.getDefault();
            String ExpectedStr = "NYI: JH 1.0 only accepts one map data";
            String gotStr = HelpUtilities.getText(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        
        String apiTested = "getText(Locale locale , String key) : " 
        + "\nTestCase : Call getText with valid key and japanese locale" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            Locale locale = Locale.JAPANESE;
            String ExpectedStr = "NYI: JH 1.0 \u306f\u30011 \u3064" 
                + "\u306e\u30de\u30c3\u30d7\u30c7\u30fc\u30bf\u3060\u3051" 
                + "\u3092\u53d7\u3051\u4ed8\u3051\u307e\u3059\u3002";
            String gotStr = HelpUtilities.getText(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = "  + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
        
        String apiTested = "getText(Locale locale , String key) : " 
        + "\nTestCase : Call getText with valid key and invalid locale" 
        + "\nExpected Result : Shd return associated text for key in default " 
        + "locale" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            Locale locale = new Locale("invalid_lang", "invalid_coun");
            String ExpectedStr = "NYI: JH 1.0 only accepts one map data";
            String gotStr = HelpUtilities.getText(locale, key);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text "
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase7() {
        
        String apiTested = "getText(Locale locale , String key) : " 
        + "\nTestCase : Call getText with valid key and null locale" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.oneMapOnly";
            Locale locale = null;
            String gotStr = HelpUtilities.getText(locale, key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase8() {
        
        String apiTested = "getText(Locale locale , String key) : " 
        + "\nTestCase : Call getText with null key and valid locale" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            Locale locale = Locale.getDefault();;
            String gotStr = HelpUtilities.getText(locale, key);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
        
    public Status testCase9() {
        
        String apiTested = "getText(String key,String s1) : " 
        + "\nTestCase : Call getText with valid key and s1" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongPublicID";
            String s1 = "TestPublicID";
            String ExpectedStr = "Unknown PublicID TestPublicID";
            String gotStr = HelpUtilities.getText(key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase10() {
        
        String apiTested = "getText(String key,String s1) : " 
        + "\nTestCase : Call getText with valid key and null s1" 
        + "\nExpected Result : Shd return associated text for string" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongPublicID";
            String s1 = null;
            String ExpectedStr = "Unknown PublicID null";
            String gotStr = HelpUtilities.getText(key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase11() {
        
        String apiTested = "getText(String key,String s1) : " 
        + "\nTestCase : Call getText with null key and valid s1" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            String s1 = "TestPublicID"; 
            String gotStr = HelpUtilities.getText(key, s1);  
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             
    
    public Status testCase12() {
        
        String apiTested = "getText(Locale l,String key,String s1) : " 
        + "\nTestCase : Call getText with default locale l and valid key and s1" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.subHelpSetTrouble";
            String s1 = "TestSubHelpSet";
            String ExpectedStr = "Trouble creating subhelpset: TestSubHelpSet.";
            String gotStr = HelpUtilities.getText(locale,key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase13() {
        
        String apiTested = "getText(Locale l,String key,String s1) : " 
        + "\nTestCase : Call getText with japanese locale l and valid key and s1" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.JAPANESE;
            String key = "helpset.subHelpSetTrouble";
            String s1 = "TestSubHelpSet";
            String ExpectedStr = "\u30b5\u30d6\u30d8\u30eb\u30d7\u30bb\u30c3" 
                + "\u30c8: TestSubHelpSet \u306e\u4f5c\u6210\u306b\u554f\u984c" 
                + "\u304c\u3042\u308a\u307e\u3059\u3002";
            String gotStr = HelpUtilities.getText(locale,key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
    
    public Status testCase14() {
        
        String apiTested = "getText(Locale l,String key,String s1) : " 
        + "\nTestCase : Call getText with invalid locale l and valid key and s1" 
        + "\nExpected Result : Shd return associated text for key in default " 
        + "locale" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = new Locale("invalid_lang", "invalid_coun");
            String key = "helpset.subHelpSetTrouble";
            String s1 = "TestSubHelpSet";
            String ExpectedStr = "Trouble creating subhelpset: TestSubHelpSet.";
            String gotStr = HelpUtilities.getText(locale,key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }      
    
    public Status testCase15() {
        
        String apiTested = "getText(Locale l,String key,String s1)  : " 
        + "\nTestCase : Call getText with null locale and valid key and s1" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = null;
            String key = "helpset.subHelpSetTrouble";
            String s1 = "TestSubHelpSet"; 
            String gotStr = HelpUtilities.getText(locale,key, s1);  
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             
    
    public Status testCase16() {
        
        String apiTested = "getText(Locale l,String key,String s1)  : " 
        + "\nTestCase : Call getText with null key and valid locale and s1" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = null;
            String s1 = "TestSubHelpSet"; 
            String gotStr = HelpUtilities.getText(locale,key, s1);  
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             

    public Status testCase17() {
        
        String apiTested = "getText(Locale l,String key,String s1) : " 
        + "\nTestCase : Call getText with null s1 and valid locale l and key " 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.subHelpSetTrouble";
            String s1 = null;
            String ExpectedStr = "Trouble creating subhelpset: null.";
            String gotStr = HelpUtilities.getText(locale,key, s1);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase18() {
        
        String apiTested = "getText(String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with valid key and s1 , s2" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongTitle";
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String ExpectedStr = "Attempting to set title to TestTitle1 but " 
                + "already has value TestTitle2.";
            String gotStr = HelpUtilities.getText(key, s1, s2);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
        
    public Status testCase19() {
        
        String apiTested = "getText(String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with valid key and null s1 , s2" 
        + "\nExpected Result : Shd return associated text for string" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongTitle";
            String s1 = null;
            String s2 = null;
            String gotStr = HelpUtilities.getText(key, s1, s2);
            String ExpectedStr = "Attempting to set title to null but " 
                + "already has value null.";
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase20() {
        
        String apiTested = "getText(String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with null key and valid s1 , s2" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String gotStr = HelpUtilities.getText(key, s1, s2);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }                         
                
    public Status testCase21() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with default locale l and valid key,s1,s2" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.wrongTitle";
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String ExpectedStr = "Attempting to set title to TestTitle1 but " 
                + "already has value TestTitle2.";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
    
    public Status testCase22() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with japanese locale l and valid key,s1,s2" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.JAPANESE;
            String key = "helpset.wrongTitle";
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String ExpectedStr = "\u30bf\u30a4\u30c8\u30eb\u3092 TestTitle1 " 
                + "\u306b\u8a2d\u5b9a\u3057\u3088\u3046\u3068\u3057\u307e" 
                + "\u3057\u305f\u304c\u3001\u3059\u3067\u306b\u5024 TestTitle2 " 
                + "\u304c\u5b58\u5728\u3057\u3066\u3044\u307e\u3059\u3002";
            String gotStr = HelpUtilities.getText(locale,key, s1,s2);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
    
    public Status testCase23() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with invalid locale l and valid key,s1,s2" 
        + "\nExpected Result : Shd return associated text for key in default " 
        + "locale" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = new Locale("invalid_lang", "invalid_coun");
            String key = "helpset.wrongTitle";          
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String ExpectedStr = "Attempting to set title to TestTitle1 but " 
                + "already has value TestTitle2.";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }      
    
    public Status testCase24() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2)  :" 
        + "\nTestCase : Call getText with null locale and valid key and s1,s2" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = null;
            String key = "helpset.wrongTitle";
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             
    
    public Status testCase25() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2)  : " 
        + "\nTestCase : Call getText with null key and valid locale and s1,s2" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = null;
            String s1 = "TestTitle1";
            String s2 = "TestTitle2";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             

    public Status testCase26() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2) : " 
        + "\nTestCase : Call getText with null s1,s2 and valid locale l and key" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.wrongTitle";
            String s1 = null;
            String s2 = null;
            String ExpectedStr = "Attempting to set title to null but " 
                + "already has value null.";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }       
    
    public Status testCase27() {
        
        String apiTested ="getText(String key,String s1,String s2,String s3):" 
        + "\nTestCase : Call getText with valid key and s1 , s2 and s3" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongLocale";
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String ExpectedStr = "Warning: xml:lang attribute TestLocale1" 
                + " conflicts with default TestLocale2 and with default" 
                + " TestLocale3";
            String gotStr = HelpUtilities.getText(key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase28() {
        
        String apiTested ="getText(String key,String s1,String s2,String s3):" 
        + "\nTestCase : Call getText with valid key and null s1 , s2 and s3" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            String key = "helpset.wrongLocale";
            String s1 = null;
            String s2 = null;
            String s3 = null;
            String ExpectedStr = "Warning: xml:lang attribute null" 
                + " conflicts with default null and with default" 
                + " null";
            String gotStr = HelpUtilities.getText(key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase29() {
        
        String apiTested ="getText(String key,String s1,String s2,String s3):" 
        + "\nTestCase : Call getText with null key and valid s1 , s2 and s3" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            String key = null;
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String gotStr = HelpUtilities.getText(key, s1, s2, s3);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
                               
    public Status testCase30() {
        
        String apiTested ="getText(Locale l,String key,String s1,String s2," 
        + "String s3):" 
        + "\nTestCase : Call getText with default locale l,valid  key,s1,s2,s3" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.wrongLocale";
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String ExpectedStr = "Warning: xml:lang attribute TestLocale1" 
                + " conflicts with default TestLocale2 and with default" 
                + " TestLocale3";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase31() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2," 
        + "String s3) : " 
        + "\nTestCase : Call getText with japanese locale l, valid key,s1,s2,s3" 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.JAPANESE;
            String key = "helpset.wrongLocale";
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String ExpectedStr = "\u8b66\u544a: xml: \u8a00\u8a9e\u5c5e\u6027 " 
                + "TestLocale1 \u306f\u3001\u30c7\u30d5\u30a9\u30eb\u30c8\u306e" 
                + " TestLocale2 \u304a\u3088\u3073 TestLocale3 \u3068\u91cd" 
                + "\u8907\u3057\u307e\u3059\u3002";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
    
    public Status testCase32() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2," 
        + "String s3) : " 
        + "\nTestCase : Call getText with invalid locale l, valid key,s1,s2,s3" 
        + "\nExpected Result : Shd return associated text for key in default " 
        + "locale" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = new Locale("invalid_lang", "invalid_coun");
            String key = "helpset.wrongLocale";
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String ExpectedStr = "Warning: xml:lang attribute TestLocale1" 
                + " conflicts with default TestLocale2 and with default" 
                + " TestLocale3";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }      
    
    public Status testCase33() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2," 
        + "String s3)  : " 
        + "\nTestCase : Call getText with null locale and valid key ,s1,s2,s3" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = null;
            String key = "helpset.wrongLocale";
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             
    
    public Status testCase34() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2," 
        + "String s3)  : " 
        + "\nTestCase : Call getText with null key and valid locale,s1,s2,s3" 
        + "\nExpected Result : Shd throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = null;
            String s1 = "TestLocale1";
            String s2 = "TestLocale2";
            String s3 = "TestLocale3";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            return Status.failed(apiTested+"Did not get NullPointerException\n");
        } catch(NullPointerException npe) {
            return Status.passed(apiTested + "Got NullPointerException\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }             

    public Status testCase35() {
        
        String apiTested = "getText(Locale l,String key,String s1,String s2," 
        + "String s3) : " 
        + "\nTestCase : Call getText with null s1,s2,s3 and valid locale l,key " 
        + "\nExpected Result : Shd return associated text for key" 
        + "\nObtained Result : ";
        
        try {
            Locale locale = Locale.getDefault();
            String key = "helpset.wrongLocale";
            String s1 = null;
            String s2 = null;
            String s3 = null;
            String ExpectedStr = "Warning: xml:lang attribute null" 
                + " conflicts with default null and with default" 
                + " null";
            String gotStr = HelpUtilities.getText(locale,key, s1, s2, s3);
            if(gotStr.equals(ExpectedStr)) {
                return Status.passed(apiTested + "Got the associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            } else {
                return Status.failed(apiTested + "Did not get associated text" 
                    + "\nGiven key = " + key + " , Got str = " +gotStr+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }           
}

/*
 * @(#)IsStringInStringTest.java	1.2 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Enumeration;
import java.text.Collator;
import java.text.RuleBasedCollator;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
 
public class IsStringInStringTest extends MultiTest {
       
    public IsStringInStringTest() {
        
    }
    
    public static void main(String argv[]) {
        IsStringInStringTest test = new IsStringInStringTest();
        Status s = test.run(argv, new PrintWriter(System.out),
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "isStringInString(RuleBasedCollator rbc, " 
        + "String source,String target) : " 
        + "\nTestCase : Call isStringInString with default locale rbc and " 
        + "source that is present in target " 
        + "\nExpected Result : Shd return true " 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            RuleBasedCollator rbc =(RuleBasedCollator) Collator.getInstance();
            String target = "Testing isStringInString";
            String source = "Testing";
            check = HelpUtilities.isStringInString(rbc,source,target);
           
            if(check) {
                return Status.passed(apiTested + "Got True\n");
            } else {
                return Status.failed(apiTested + "Got False \n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "isStringInString(RuleBasedCollator rbc, " 
        + "String source,String target) : " 
        + "\nTestCase :Call isStringInString with default locale rbc and " 
        + "source that is not present in target " 
        + "\nExpected Result : Shd return false " 
        + "\nObtained Result : ";
        
        boolean check = true;
        try {
            RuleBasedCollator rbc = (RuleBasedCollator) Collator.getInstance();
            String target = "Testing isStringInString";
            String source = "is it here";
            check = HelpUtilities.isStringInString(rbc,source,target);
                         
            if(!check) {
                return Status.passed(apiTested + "Got False\n");
            } else {
                return Status.failed(apiTested + "Got True \n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase3() {
        
    	/* TestCase throws ArrayIndexOutOfBoundsException when tested
    	 * on NT - JDK1.1.6
    	 * If run as java -nojit <testCase> the exception does not occur
    	 */
    	 
        String apiTested = "isStringInString(RuleBasedCollator rbc, " 
        + "String source,String target) : " 
        + "\nTestCase : Call isStringInString with Japanese locale rbc and " 
        + "source that is  present in target " 
        + "\nExpected Result : Shd return true. Note: Will fail under NT - JDK1.1.6" 
        + "\nObtained Result : ";
        
        boolean check = false;
        try {
            Locale locale = Locale.JAPANESE;
            RuleBasedCollator rbc =
                 (RuleBasedCollator) Collator.getInstance(locale);
            String target = "\u306f\u3044\u3044\u3044\u3048\u30d8\u30eb\u30d7";
            String source = "\u30d8\u30eb\u30d7";
            check = HelpUtilities.isStringInString(rbc,source,target);
                         
            if(check) {
                return Status.passed(apiTested + "Got True\n");
            } else {
                return Status.failed(apiTested + "Got False \n");
            }
        } catch(Exception e) {
            e.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase4() {
    	
    	/* TestCase throws ArrayIndexOutOfBoundsException when tested
    	 * on NT - JDK1.1.6
    	 * If run as java -nojit <testCase> the exception does not occur
    	 */
    	 
        String apiTested = "isStringInString(RuleBasedCollator rbc, " 
        + "String source,String target) : " 
        + "\nTestCase:Call isStringInString with Japanese locale rbc and " 
        + "source that is not present in target " 
        + "\nExpected Result : Shd return false. Note: Will fail under NT - JDK1.1.6 " 
        + "\nObtained Result : ";
        
        boolean check = true;
        try {
            Locale locale = Locale.JAPANESE;
            RuleBasedCollator rbc = 
                (RuleBasedCollator) Collator.getInstance(locale);
            String target = "\u306f\u3044\u3044\u3044\u3048\u30d8\u30eb\u30d7";
            String source = "\u53d6\u6d88\u3057";
            check = HelpUtilities.isStringInString(rbc,source,target);
                         
            if(!check) {
                return Status.passed(apiTested + "Got False\n");
            } else {
                return Status.failed(apiTested + "Got True \n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
}

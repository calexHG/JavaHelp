/*
 * @(#)LocaleFromLangTest.java	1.4 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Enumeration;
import java.awt.Button;
import javax.help.HelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
public class LocaleFromLangTest extends MultiTest {
    
    public LocaleFromLangTest() {
        
    }
    
    public static void main(String argv[]) {
        LocaleFromLangTest test = new LocaleFromLangTest();
        Status s = test.run(argv, new PrintWriter(System.out),
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "localeFromLang(String lang) : " 
        + "\nTestCase : Call localeFromLang with only language spec.d" 
        + "\nExpected Result : Shd return a locale object with given lang" 
        + "\nObtained Result : ";
        
        try {
            String lang = "fr";
            Locale locale = HelpUtilities.localeFromLang(lang);
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("") && 
                                        gotVar.equals("")) {
                return Status.passed(apiTested + "Got the  Locale  " 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale " 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "localeFromLang(String lang) : " 
        + "\nTestCase : Call localeFromLang with only language and country " 
        + "spec.d" 
        + "\nExpected Result : Shd return a locale object with given lang and" 
        + " country" 
        + "\nObtained Result : ";
        
        try {
            String lang = "fr_FR";
            Locale locale = HelpUtilities.localeFromLang(lang);
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("FR") && 
                                        gotVar.equals("")) {
                return Status.passed(apiTested + "Got the  Locale " 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale" 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "localeFromLang(String lang) : " 
        + "\nTestCase : Call localeFromLang with language , country and " 
        + "variant spec.d" 
        + "\nExpected Result : Shd return a locale object with given lang" 
        + "\nObtained Result : ";
        
        try {
            String lang = "fr_FR_WIN";
            Locale locale = HelpUtilities.localeFromLang(lang);
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("FR") &&
                                     gotVar.equals("WIN")) {
                return Status.passed(apiTested + "Got the  Locale" 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale." 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "localeFromLang(String lang) : " 
        + "\nTestCase : Call localeFromLang with null lang" 
        + "\nExpected Result : Shd return a null locale" 
        + "\nObtained Result : ";
        
        try {
            String lang = null;
            Locale locale = HelpUtilities.localeFromLang(lang);
            if(locale == null) {
                return Status.passed(apiTested + "Got null  Locale" 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get null Locale" 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
        public Status testCase5() {
    	
        String apiTested = "localeFromLang(String lang) : " 
        + "\nTestCase : Call localeFromLang with only country spec.d" 
        + "\nExpected Result : Shd return a locale object with given country" 
        + "\nObtained Result : ";
        
        try {
            String lang = "_FR";
            Locale locale = HelpUtilities.localeFromLang(lang);
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("") && gotCtry.equals("FR") && 
                                        gotVar.equals("")) {
                return Status.passed(apiTested + "Got the  Locale  " 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale " 
                    + "\nGiven lang = " + lang + " , Got Locale = " 
                    + locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

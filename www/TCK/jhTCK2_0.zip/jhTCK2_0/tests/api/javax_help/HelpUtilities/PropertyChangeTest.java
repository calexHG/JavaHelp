/*
 * @(#)GetCandidatesTest.java	1.4 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.HelpUtilities;
import java.io.PrintWriter;
import javax.swing.UIManager;
import javax.swing.UIDefaults;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.LookAndFeel;
import javax.swing.ImageIcon;
import java.util.Locale;
import javax.help.SwingHelpUtilities;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpUtilities
 *
 * @author Meena C
 */
 
public class PropertyChangeTest extends MultiTest {
       
    public PropertyChangeTest() {
        
    }
    
    public static void main(String argv[]) {
        PropertyChangeTest test = new PropertyChangeTest();
        Status s = test.run(argv, new PrintWriter(System.out),
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "PropertyChange(PropertyChangeEvent event) : " 
        + "\nTestCase : Call UIManager.setLookAndFeel() and then check if " 
        + "JavaHelp defaults have been added to UIDefaults table" 
        + "\nExpected Result : UIDefaults table should contain " 
        + "JavaHelp Defaults." 
        + "\nObtained Result : ";
        
        try {
            String basicPackageName = "javax.help.plaf.basic.";
            String keys[] = { "HelpUI", "HelpTOCNavigatorUI",
                "HelpIndexNavigatorUI","HelpSearchNavigatorUI",
                "HelpContentViewerUI"};
            String value[] = { "BasicHelpUI","BasicTOCNavigatorUI",
                "BasicIndexNavigatorUI","BasicSearchNavigatorUI",
                "BasicContentViewerUI"};
            
            String className =null;
            boolean check =false;
            UIManager.LookAndFeelInfo[] lafInfo = UIManager.getInstalledLookAndFeels();
            LookAndFeel curLaf = UIManager.getLookAndFeel(); 
            
            // To find a new LAF other than the current one 
            for (int i =0;i<lafInfo.length;i++) {
                if(!(lafInfo[i].getName()).equals(curLaf.getName())) {
                    className = lafInfo[i].getClassName();
                    break;
                }
            }       
            
            // To initialize HelpUtilities class so that 
            // PropertyChangeListener is added
               Class baseClass = this.getClass();
               String image = "/duke.gif";
               ImageIcon icon = SwingHelpUtilities.getImageIcon(baseClass, image); 
 

            //change to a new LAF
            if( className != null ) 
                UIManager.setLookAndFeel(className);  
                            
            // check if JavaHelp defaults are added
            for (int i =0 ;i<keys.length;i++) {
                String gotValue = (String) UIManager.get(keys[i]);
                check=true;
                String expValue = basicPackageName + value[i];
                if(!expValue.equals(gotValue)) {
                    check = false;
                    break;
                }
            }
            if(check) {
                return Status.passed(apiTested + "UIDefaults table contains " 
                    + " Javahelp Defaults\n");
            } else {
                return Status.failed(apiTested + "UIDefaults table does not " 
                    + "contain Javahelp Defaults.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }

}

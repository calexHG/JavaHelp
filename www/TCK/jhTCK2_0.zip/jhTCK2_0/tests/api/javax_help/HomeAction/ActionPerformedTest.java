/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... HomeAction(control).actionPerformed(event) --> HomeAction(control).actionPerformed(event)
 */

package javasoft.sqe.tests.api.javax.help.HomeAction;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.event.ActionEvent;

import javax.help.JHelp;
import javax.help.Map.ID;
import javax.help.HelpModel;
import javax.help.HelpSet;
import javax.help.HomeAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HomeAction ... actionPerformed(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class ActionPerformedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public ActionPerformedTest() {
    }

    public static void main(String argv[]) {
        ActionPerformedTest test = new ActionPerformedTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void actionPerformed(java.awt.event.ActionEvent event)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>event</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void actionPerformed(java.awt.event.ActionEvent event): "
            + "TestCase: '(new HomeAction(control)).actionPerformed(event)' "
            + "ExpectedResult: Change 'homeID' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
            //create a HelpSet object ... end

            System.out.println("original homeID ... " + hs.getHomeID() );

            //create a JHelp object ... start
            JHelp jhelp = new JHelp(hs);
            //create a JHelp object ... end

            //create a homeID ... start
            ID homeID = ID.create("aprilfools", hs);
            //create a homeID ... end

            //set the homeID as a current ID ... start
            jhelp.setCurrentID(homeID);
            //set the homeID as a current ID ... end

            //create HomeAction object ... start
            HomeAction homeAction = new HomeAction(jhelp);
            //create HomeAction object ... end

            //perform action for changing homeID ... start
            homeAction.actionPerformed(new ActionEvent(new Object(), 0, "homeID") );
            //perform action for changing homeID ... end

	    HelpModel model = jhelp.getModel();

            if(hs.getHomeID().equals(model.getCurrentID()) ) {
                return Status.passed(apiTested + "Changed 'homeID'");
            } else {
                return Status.failed(apiTested + "Did not change 'homeID': " + hs.getHomeID() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

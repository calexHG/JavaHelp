
/*
* 
* 
* @(#)GetHelpSetTest.java	1.4 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.IndexItem;

import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.IndexItem;
import javax.help.HelpSet;
import javax.help.*;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.IndexItem
 *
 
 * @author Ben John.
 */

public class GetHelpSetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpSetTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHelpSetTest test = new GetHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"getHelpSet()";
        IndexItem index = new IndexItem();
        if(index.getHelpSet() == null) {
            return Status.passed(apiTested 
            + "Okay returns null for default IndexItem");
        }
        else {
            return Status.failed(apiTested 
            + "Did not return null for default IndexItem");
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" getHelpSet()\"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs = null;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, hs, Locale.getDefault());
            if((index.getHelpSet() instanceof HelpSet) && (index.getHelpSet() == hs)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "didn't return valid HelpSet Object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + " Exception raised :" + ee);
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \" getHelpSet() \"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs = null;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, Locale.getDefault());
            if((index.getHelpSet() instanceof HelpSet) && (index.getHelpSet() == hs)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "didn't return a valid HelpSet Object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised  :" + ee);
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \" getHelpSet()\"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, null, Locale.getDefault());
            if(index.getHelpSet() == null) {
                return Status.passed(apiTested 
                + "Okay ; returns null for Map.ID,null HelpSet");
            }
            else {
                return Status.failed(apiTested 
                + "didn't return null; Passing HelpSet null");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised  :" + ee);
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method \" getHelpSet() \"";
        IndexItem index = new IndexItem(null, Locale.getDefault());
        if(index.getHelpSet() == null) {
            return Status.passed(apiTested 
            + "Okay ; id can be null; returns null Passing Map.ID null");
        }
        else {
            return Status.failed(apiTested 
            + "didn't return null Passing Map.ID null");
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = "Method \" getHelpSet()\"";
        IndexItem index = new IndexItem(null, null, Locale.getDefault());
        if(index.getHelpSet() == null) {
            return Status.passed(apiTested 
            + "Okay ; returns null for passing null Map.ID & HelpSet ");
        }
        else {
            return Status.failed(apiTested 
            + "didn't return null for  passing null Map.ID & HelpSet ");
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = "Method \" getHelpSet()\"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(null, hs, Locale.getDefault());
            if(index.getHelpSet() == hs) {
                return Status.passed(apiTested 
                + "Okay ; ");
            }
            else {
                return Status.failed(apiTested 
                + " for null id HelpSet cannot be returned");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised  :" + ee);
        }
    } //testCase7 finished
}

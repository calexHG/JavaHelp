
/*
* 
* 
* @(#)IndexItemTest.java	1.4 99/03/02 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.IndexItem;

import java.io.PrintWriter;
import java.util.Locale;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.IndexItem;
import javax.help.*;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.IndexItem
 *
 
 * @author Ben John.
 */

public class IndexItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public IndexItemTest() {
        
    }
    
    public static void main(String argv[]) {
        IndexItemTest test = new IndexItemTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"IndexItem()";
        IndexItem index = new IndexItem();
        if((index instanceof IndexItem) && (index.getHelpSet() == null)){
            return Status.passed(apiTested + "Okay");
        }
        else {
            return Status.failed(apiTested 
            + "IndexItem class didn't construct a default valid object");
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method \" IndexItem(Map.ID id,HelpSet hs,java.util.Locale locale) \"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, hs, Locale.getDefault());
            if((index instanceof IndexItem) && (index.getHelpSet() == hs)
			    && (index.getID() == mid) && 
				(index.getLocale()==Locale.getDefault())){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "IndexItem class didn't "
                + " construct a valid object with Map.ID,HelpSet and "
                + " Default Locale objects");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + " Exception raised :" + ee);
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method \" IndexItem(Map.ID id,java.util.Locale locale)\"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, Locale.getDefault());
            if((index instanceof IndexItem) && (index.getHelpSet() == hs)
			    && (index.getID() == mid) && 
				(index.getLocale()==Locale.getDefault())){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "IndexItem class didn't "
                + " construct a valid object withMap.ID and Locale objects.");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + " Exception raised :" + ee);
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method \" IndexItem(Map.ID id,HelpSet hs,"
                           + " java.util.Locale locale) \"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, hs, null);
            if((index instanceof IndexItem) && (index.getHelpSet() == hs)
						    && (index.getID() == mid) && 
							(index.getLocale()==null)){
			
                return Status.passed(apiTested + "Okay ; Locale as null");
            }
            else {
                return Status.failed(apiTested + "IndexItem class didn't "
                + " construct a valid object with Map.ID,HelpSet and "
                + " null for Locale objects");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised :" + ee);
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method \" IndexItem(Map.ID id,HelpSet hs,"
                           + " java.util.Locale locale) \"";
        IndexItem index = new IndexItem(null, null, null);
        if((index instanceof IndexItem) && (index.getHelpSet() == null)
			    && (index.getID() == null) && 
				(index.getLocale()==null)){
 			return Status.passed(apiTested + "Okay; all arguments null");
        }
        else {
            return Status.failed(apiTested + "IndexItem class didn't construct"
            + " a valid object with null arguments");
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = "Method \" IndexItem(Map.ID id,java.util.Locale locale)\"";
        IndexItem index = new IndexItem(null, Locale.getDefault());
        if((index instanceof IndexItem) && (index.getHelpSet() == null)
					    && (index.getID() == null) && 
						(index.getLocale()==Locale.getDefault())){
		
            return Status.passed(apiTested + "Okay ; for Map.ID object null");
        }
        else {
            return Status.failed(apiTested + "IndexItem class didn't construct "
            + " a valid object with null Map.ID and Locale objects.");
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = "Method \" IndexItem(Map.ID id,java.util.Locale locale)\"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(mid, null);
            if((index instanceof IndexItem) && (index.getHelpSet() == hs)
			    && (index.getID() == mid) && 
				(index.getLocale()==null)){
                return Status.passed(apiTested + "Okay for Null Locale object");
            }
            else {
                return Status.failed(apiTested + "IndexItem class didn't "
                + " construct a valid object withMap.ID and null Locale objects.");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + " Exception raised :" + ee);
        }
    } //testCase7 finished
    
    public Status testCase8() {
        String apiTested = "Method \" IndexItem(Map.ID id,java.util.Locale locale)\"";
        IndexItem index = new IndexItem(null, null);
        if((index instanceof IndexItem) && (index.getHelpSet() == null)
					    && (index.getID() == null) && 
						(index.getLocale()==null)){
		
            return Status.passed(apiTested + "Okay for null arguments");
        }
        else {
            return Status.failed(apiTested + "IndexItem class didn't construct"
            +"  a valid object with null Map.ID and null Locale objects.");
        }
    } //testCase8 finished
    
    public Status testCase9() {
        String apiTested = "Method \" IndexItem(Map.ID id,HelpSet hs,"
                           + " java.util.Locale locale) \"";
        ClassLoader loader = this.getClass().getClassLoader();
        HelpSet hs;
        URL url;
        try {
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            IndexItem index = new IndexItem(null, hs, Locale.getDefault());
            if((index instanceof IndexItem) && (index.getHelpSet() == hs)
						    && (index.getID() == null) && 
							(index.getLocale()==Locale.getDefault())){
			
                return Status.passed(apiTested + "Okay ; id can be null ");
            }
            else {
                return Status.failed(apiTested + "IndexItem class didn't "
                + " construct a valid object with null id,HelpSet and "
                + " Default Locale objects");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + " Exception raised :" + ee);
        }
    } //testCase9 finished
}

/*
* @(#)CreateNavigatorTest.java	1.2 01/08/07
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.IndexView;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.util.Hashtable;
import java.net.URL;
import java.util.Locale;
import java.awt.Component;
import javax.help.IndexView;
import javax.help.DefaultHelpModel;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.help.JHelpIndexNavigator;
/**
* Tests for javax.help.IndexView
* Method: createNavigator(HelpModel model) Test
* 
* @author Sudhakar.Adini
*/
public class CreateNavigatorTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateNavigatorTest() {
        
    }
    
    public static void main(String argv[]) {
        CreateNavigatorTest test = new CreateNavigatorTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: createNavigator(HelpModel model)" 
        + "\nTestCase : Call  createNavigator(HelpModel model)" 
        + "\nExpected Result :It should return the Component object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();            
            URL url2 = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs2 = new HelpSet(l, url2);
            String name = "Index";
            String label = "Index";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs2, name, label, params);
            DefaultHelpModel model = new DefaultHelpModel(iv.getHelpSet());
            Component cc = iv.createNavigator(model);
            if(cc instanceof Component) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished			
    
    public Status testCase2() {
        String apiTested = "Method: createNavigator(HelpModel model)" 
        + "\nTestCase : Call createNavigator with  model as null  " 
        + "\nExpected Result :It should return the Component object " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpModel model = null;
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, params);
            Component cc = iv.createNavigator(model);            
            if(cc instanceof Component) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"GotException: "+e.toString());
            }
            else {
                return Status.failed(apiTested +"GotException: "+e.toString());
            }
        }
    } //testCase2 finished
}

/*
* @(#)IndexViewTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.IndexView;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import java.awt.Component;
import javax.help.IndexView;
import javax.help.IndexView.DefaultIndexFactory;
import javax.help.DefaultHelpModel;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.help.JHelpIndexNavigator;
import javax.help.TreeItemFactory;
/**
* Tests for javax.help.IndexView
* constructorTest
* 
* @author Sudhakar.Adini
*/
public class IndexViewTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public IndexViewTest() {
        
    }
    
    public static void main(String argv[]) {
        IndexViewTest test = new IndexViewTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Hashtable params)" 
        + "\nTestCase : Call IndexView() " 
        + "\nExpected Result :It should construct the IndexView object  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1.equals(params))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested + "Did not Construct object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished			
    
    public Status testCase2() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Hashtable params) " 
        + "\nTestCase :CallIndexView with hs as null and valid values for name,"
        + "label,params " 
        + "\nExpected Result :NullPoiterException should be thrown." 
        + "\nObtained Result : ";
        try {
            HelpSet hs = null; 
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1 == hs)&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1.equals(params))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested + "Did not Construct object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"GotException : "+e.toString());
            }
            else {
                return Status.failed(apiTested +"GotException : "+e.toString());
            }
        }
    } //testCase2 finished			
    
    public Status testCase3() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Hashtable params) " 
        + "\nTestCase :CallIndexView with name as null and valid values for hs,"
        + "label,params " 
        + "\nExpected Result :It should throw NullPoiterException " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = null; //"IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1 == null)
            	 &&(label1.equals(label))&&(params1.equals(params))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested + "Did not Construct object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"GotException : "+e.toString());
            }
            else {
                return Status.failed(apiTested +"GotException : "+e.toString());
            }
        }
    } //testCase3 finished			
    
    public Status testCase4() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Hashtable params) " 
        + "\nTestCase :Call IndexView with label as null and valid values for "
        + "name,hs,params " 
        + "\nExpected Result :NullPoiterException should be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = null; //"IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	 &&(label1 == null)&&(params1.equals(params))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"GotException : "+e.toString());
            }
            else {
                return Status.failed(apiTested +"GotException : "+e.toString());
            }
        }
    } //testCase4 finished			
    
    public Status testCase5() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Hashtable params) " 
        + "\nTestCase : Call IndexView with params as null and valid values for"
        + " name,hs,label " 
        + "\nExpected Result :It should construct the IndexView object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = null; //new Hashtable();
            IndexView iv = new IndexView(hs, name, label, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1 == params)) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested+"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase5 finished		
    
    public Status testCase6() {
        String apiTested = " Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params)" 
        + "\nTestCase : Call IndexView()" 
        + "\nExpected Result :It should construct the IndexView object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            Locale locale = Locale.getDefault();
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Locale locale1 = iv.getLocale();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1.equals(params))
            	 &&(locale1.equals(locale))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase6 finished			
    
    public Status testCase7() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params) " 
        + "\nTestCase :CallIndexView with hs as null and valid values for name,"
        + "label,params,locale" 
        + "\nExpected Result :It should construct the IndexView object" 
        + "\nObtained Result : ";
        try {
            HelpSet hs = null; //new HelpSet( l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Locale locale = Locale.getDefault();
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Hashtable params1 = iv.getParameters();
            Locale locale1 = iv.getLocale();
            if((iv instanceof IndexView)&&(hs1 == hs)&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1.equals(params))
            	 &&(locale1.equals(locale))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase7 finished			
    
    public Status testCase8() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params) " 
        + "\nTestCase :CallIndexView with name as null and valid values for hs,"
        + "label,params,locale " 
        + "\nExpected Result :NullPoiterException should be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = null; //"IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            Locale locale = Locale.getDefault();
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Locale locale1 = iv.getLocale();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1 == null)
            	 &&(label1.equals(label))&&(params1.equals(params))
            	 &&(locale1.equals(locale))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested+"Got Exception: "+ e.toString());
            }
            else {
                return Status.failed(apiTested+"Got Exception: "+ e.toString());
            }
        }
    } //testCase8 finished			
    
    public Status testCase9() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params) " 
        + "\nTestCase : Call IndexView with  label as null and valid values for"
        + " name,hs,params,locale " 
        + "\nExpected Result :NullPoiterException should be thrown." 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = null; 
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            Locale locale = Locale.getDefault();
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Locale locale1 = iv.getLocale();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	&&(label1 == null)&&(params1.equals(params))
            	&&(locale1.equals(locale))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested+"Got Exception: "+ e.toString());
            }
            else {
                return Status.failed(apiTested+"Got Exception: "+ e.toString());
            }
        }
    } //testCase9 finished			
    
    public Status testCase10() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params) " 
        + "\nTestCase : Call IndexView with params as null and valid values for"
        + " name,hs,label ,locale" 
        + "\nExpected Result :It should construct the IndexView object." 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = null; //new Hashtable();
            Locale locale = Locale.getDefault();
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Locale locale1 = iv.getLocale();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	&&(label1.equals(label))&&(params1 == params)
            	&&(locale1.equals(locale))) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested+"Got Exception: "+ e.toString());
            }
            else {
                return Status.failed(apiTested+"Got Exception: "+ e.toString());
            }
        }
    } //testCase10 finished
    
    public Status testCase11() {
        String apiTested = "Constructor: IndexView(HelpSet hs,String name,"
        + "String label,Locale locale,Hashtable params) " 
        + "\nTestCase : Call IndexView with locale as null and valid values for"
        + " name,hs,label,params " 
        + "\nExpected Result :It should construct the IndexView object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            String name = "IndexView";
            String label = "IndexViewTest";
            Hashtable params = new Hashtable();
            params.put("data", "HolidayIndex.xml");
            Locale locale = null; //Locale.getDefault();
            IndexView iv = new IndexView(hs, name, label, locale, params);
            HelpSet hs1 = iv.getHelpSet();
            String name1 = iv.getName();
            String label1 = iv.getLabel();
            Locale locale1 = iv.getLocale();
            Hashtable params1 = iv.getParameters();
            if((iv instanceof IndexView)&&(hs1.equals(hs))&&(name1.equals(name))
            	 &&(label1.equals(label))&&(params1.equals(params))
            	 &&(locale1 == locale)) {
                return Status.passed(apiTested + "Construct IndexView  object");
            }
            else {
                return Status.failed(apiTested +"Did not Construct the object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase11 finished		
}

/*
* @(#)ParseTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.IndexView;
import java.io.PrintWriter;
import javax.help.HelpSet;
import java.lang.ClassLoader;
import java.lang.Class;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import java.awt.Component;
import javax.help.IndexView;
import javax.help.IndexView.DefaultIndexFactory;
import javax.help.DefaultHelpModel;
import javax.help.HelpSetException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.help.JHelpIndexNavigator;
import javax.help.TreeItemFactory;
/**
* Tests for javax.help.IndexView
* Method: parse() Test
* 
* @author Sudhakar.Adini
*/
public class ParseTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ParseTest() {
        
    }
    
    public static void main(String argv[]) {
        ParseTest test = new ParseTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: parse(URL url,HelpSet hs,Locale locale,"
        + "TreeItemFactory factory)" 
        + "\nTestCase : Call IndexView () " 
        + "\nExpected Result :It should return DefaultMutableTreeNode object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC +"/holidays/HolidayIndex.xml");
            URL url2 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url2);
            Locale locale = Locale.getDefault();
            DefaultIndexFactory factory = new DefaultIndexFactory();
            DefaultMutableTreeNode tn = IndexView.parse(url1, hs1, locale, 
            					(TreeItemFactory)factory);            
            if(tn instanceof DefaultMutableTreeNode) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished	
    
    public Status testCase2() {
        String apiTested = " Method: parse(URL url,HelpSet hs,Locale locale,"
        + "TreeItemFactory factory)" 
        + "\nTestCase : Call IndexView with  url as null and valid values for"
        + " hs,locale,factory " 
        + "\nExpected Result :It should return null" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = null; 
            URL url2 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url2);
            Locale locale = Locale.getDefault();
            DefaultIndexFactory factory = new DefaultIndexFactory();
            DefaultMutableTreeNode tn = IndexView.parse(url1, hs1, locale,
            					 (TreeItemFactory)factory);           
            if(tn == null) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase2 finished	
    
    public Status testCase3() {
        String apiTested = " Method: parse(URL url,HelpSet hs,Locale locale,"
        + "TreeItemFactory factory)" 
        + "\nTestCase : Call IndexView with  hs as null and valid values for"
        + " url,locale,factory " 
        + "\nExpected Result :It should return DefaultMutableTreeNode object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC +"/holidays/HolidayIndex.xml");            	
            HelpSet hs1 = null;
            Locale locale = Locale.getDefault();
            DefaultIndexFactory factory = new DefaultIndexFactory();
            DefaultMutableTreeNode tn = IndexView.parse(url1, hs1, locale, 
            					(TreeItemFactory)factory);
           
            if(tn instanceof DefaultMutableTreeNode) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase3 finished	
    
    public Status testCase4() {
        String apiTested = " Method: parse(URL url,HelpSet hs,Locale locale,"
        + "TreeItemFactory factory)" 
        + "\nTestCase : Call IndexView with locale as null and valid values for"
        + " url,hs,factory " 
        + "\nExpected Result :It should return DefaultMutableTreeNode object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC+ "/holidays/HolidayIndex.xml");
            URL url2 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url2);
            Locale locale = null; //Locale.getDefault();            
            DefaultIndexFactory factory = new DefaultIndexFactory();
            DefaultMutableTreeNode tn = IndexView.parse(url1, hs1, locale,
            					(TreeItemFactory)factory);            
            if(tn instanceof DefaultMutableTreeNode) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = " Method: parse(URL url,HelpSet hs,Locale locale,"
        + "TreeItemFactory factory)" 
        + "\nTestCase :Call IndexView with factory as null and valid values for"
        + " url,hs,locale " 
        + "\nExpected Result :It should return null" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC +"/holidays/HolidayIndex.xml");
            URL url2 = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs1 = new HelpSet(l, url2);
            Locale locale = Locale.getDefault();
            DefaultIndexFactory factory = null;            
            DefaultMutableTreeNode tn =IndexView.parse(url1,hs1,locale,factory);
            
            if(tn == null) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested +"Did not return the Component");
            }
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested +"GotException :"+ e.toString());
            }
            else {
                return Status.failed(apiTested +"GotException :"+ e.toString());
            }
        }
    } //testCase5 finished	
}

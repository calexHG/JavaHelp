/*
 * @(#)GetParamsTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.InvalidNavigatorViewException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Hashtable;
import java.net.URL;
import javax.help.InvalidNavigatorViewException;
import javax.help.HelpSet;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.InvalidNavigatorViewException
 *
 * @author Meena C
 */

public class GetParamsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetParamsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetParamsTest test = new GetParamsTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                 new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "InvalidNavigatorViewException.getParams()  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with valid " 
        + "value for Params and throw the exception.Call getParams()" 
        + "\nExpected Result : Should get the given value for Params." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Messsage";
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            params.put("data", "HoliDayIndex.xml");
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                  className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            Hashtable gotParams = inve.getParams();
            if(params.equals(gotParams)) {
                return Status.passed(apiTested + "Got given value for Params" 
                    + "\nGiven Params = " + params + " , Got Params = " 
                    + gotParams + "\n");
            } else {
                return Status.failed(apiTested + "Did not get given value for " 
                    + "Params \nGiven params = " + params + " , Got Params = " 
                    + gotParams + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "InvalidNavigatorViewException.getParams()  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null " 
        + "value for Name and throw the exception.Call getParams()" 
        + "\nExpected Result : Should get null value for Params." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = "LaBEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = null;
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                 className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            Hashtable gotParams = inve.getParams();
            if(params == gotParams) {
                return Status.passed(apiTested + "Got null value for Params" 
                    + "\nGiven Params = " + params + " , Got Params = " 
                    + gotParams + "\n");
            } else {
                return Status.failed(apiTested + "Did not get null value for " 
                    + "Params \nGiven Params = " + params + " , Got Params = " 
                    + gotParams + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

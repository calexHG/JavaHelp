/*
 * @(#)InvalidNavigatorViewExceptionTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.InvalidNavigatorViewException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Hashtable;
import java.net.URL;
import javax.help.InvalidNavigatorViewException;
import javax.help.HelpSet;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.InvalidNavigatorViewException
 *
 * @author Meena C
 */

public class InvalidNavigatorViewExceptionTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public InvalidNavigatorViewExceptionTest() {
        
    }
    
    public static void main(String argv[]) {
        InvalidNavigatorViewExceptionTest test =
                new InvalidNavigatorViewExceptionTest();
        Status s = test.run(argv, new PrintWriter(System.out),
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "InvalidNavigatorViewException(String msg, " 
        + "HelpSet hs, String name, String label, Locale locale, " 
        + "String className, Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with valid " 
        + "values and throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                     className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed " 
                                            + "InvalidNavigatorViewException " 
                                            + "with given values and got the " 
                                            + "Exception : " + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested 
                                            + "Did not Construct " 
                                            + "InvalidNavigatorViewException " 
                                            + "with given message\nGiven msg= " 
                                            + msg +"Got msg = " +gotMsg+ "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested 
                                        + "Did not Construct " 
                                        +"InvalidNavigatorViewException with " 
                                        + "given params \nGiven params = " 
                                        + params + "Got params = " 
                                        + gotParams + "\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + "\nGiven Name = " + name + "Got Name = " 
                        + gotName + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " + hs + "Got HelpSet = " 
                    + gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "InvalidNavigatorViewException(String msg, " 
        + "HelpSet hs, String name, String label, Locale locale, " 
        + "String className, Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null " 
        + "for msg and valid values for hs,name,label,locale,className,params " 
        + "and throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = null;
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name,label,locale, 
                        className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct" 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg == gotMsg) {
                                        return Status.passed(apiTested 
                                            + "Constructed " 
                                            + "InvalidNavigatorViewException " 
                                            + "with null value for msg and got " 
                                            + "the Exception : " + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested 
                                            + "Did not Construct " 
                                            + "InvalidNavigatorViewException " 
                                            + "with null for message" 
                                            + "\nGiven msg = " + msg 
                                            + "Got msg = " + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + " with given params \nGiven params = " 
                                      +params+"Got params= " +gotParams+ "\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + " nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + "\nGiven Name = " + name + "Got Name = " 
                        + gotName + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " +hs+"Got HelpSet = " +gotHS+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "InvalidNavigatorViewException(String msg, " 
        + "HelpSet hs, String name, String label, Locale locale, " 
        + "String className, Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null " 
        + "for params and valid values for msg,hs,name,label,locale,className " 
        + "and throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = null;
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                  className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params == gotParams) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed " 
                                            + "InvalidNavigatorViewException " 
                                            + "with null value for params and " 
                                            + "got the Exception : "+inve+"\n");
                                    } else {
                                        return Status.failed(apiTested+"Did not" 
                                            + " Construct InvalidNavigatorView" 
                                            + "Exception with given message" 
                                            + "\nGiven msg = " + msg 
                                            + "Got msg = " + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + " with null params \nGiven params = " 
                                      + params+"Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + "\nGiven Name = "+name+"Got Name = "+gotName+ "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = "+hs+ "Got HelpSet = " +gotHS+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested ="InvalidNavigatorViewException(String msg,HelpSet hs," 
        + " String name, String label, Locale locale, String className, " 
        + " Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null for " 
        + "className and valid values for msg,hs,name,label,locale,params and " 
        + "throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = null;
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                  className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className == gotClassName) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed InvalidNavigatorView" 
                                            + "Exception with null value for " 
                                            + "className and got the Exception:" 
                                            + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested+"Did not" 
                                            + "Construct InvalidNavigatorView" 
                                            + "Exception with given message" 
                                            + "\nGiven msg = " +msg+"Got msg = " 
                                            + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + " with given params \nGiven params = " 
                                      + params +"Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with null ClassName \nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested +"Did not Construct " 
                              +"InvalidNavigatorViewException with given Locale" 
                              + "\nGiven Locale = " + locale + "Got Locale = " 
                              + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Label" 
                        + "\nGiven Label = " + label + "Got Label = " 
                        + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + "\nGiven Name = "+name+"Got Name = "+gotName+"\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " + hs + "Got HelpSet = "+gotHS+"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        
        String apiTested ="InvalidNavigatorViewException(String msg,HelpSet hs," 
        + "String name, String label, Locale locale, String className, " 
        + "Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null for " 
        + "locale and valid values for msg,hs,name,label,className,params and " 
        + "throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = "LABEL";
            locale = null;
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label,locale, 
                         className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale == gotLocale) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed InvalidNavigatorView" 
                                            + "Exception with null value for " 
                                            + "locale and got the Exception : " 
                                            + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested+"Did not" 
                                            + " Construct InvalidNavigatorView" 
                                            + "Exception with given message" 
                                            + " \nGiven msg = " + msg 
                                            + "Got msg = " + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + " with given params \nGiven params = " 
                                      + params+"Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName +"\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + "InvalidNavigatorViewException with null " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        +"\nGiven Name = "+name+"Got Name = "+gotName + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " +hs+ "Got HelpSet = " +gotHS+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
        
        String apiTested ="InvalidNavigatorViewException(String msg,HelpSet hs," 
            + "String name, String label, Locale locale, String className, " 
            + "Hashtable params)  : " 
            + "\nTestCase : Construct InvalidNavigatorViewException with null " 
            + "for label and valid values for msg,hs,name,locale,className, " 
            + "params and throw the exception" 
            + "\nExpected Result : Should create InvalidNavigatorViewException " 
            + "object and the Exception must be got." 
            + "\nObtained Result : ";
            
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = "NAME";
            label = null;
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                  className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name.equals(gotName)) {
                    if(label == gotLabel) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed InvalidNavigatorView" 
                                            + "Exception with null value for " 
                                            + "label and got the Exception : " 
                                            + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested+"Did not" 
                                            + " Construct InvalidNavigatorView" 
                                            + "Exception with given message" 
                                            + "\nGiven msg = " + msg 
                                            + "Got msg = " + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + " with given params \nGiven params = " 
                                      +params+"Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with null Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + " \nGiven Name = " + name + "Got Name = " 
                        + gotName + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " +hs+"Got HelpSet = " +gotHS+ "\n");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase7() {
        
        String apiTested ="InvalidNavigatorViewException(String msg,HelpSet hs," 
        + " String name, String label, Locale locale, String className, " 
        + "Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null for " 
        + "name and valid values for msg,hs,label,locale,className,params and " 
        + "throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            hs = new HelpSet(cl, url);
            msg = "Test Message";
            name = null;
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,  
                                                  className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs.equals(gotHS)) {
                if(name == gotName) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed InvalidNavigatorView" 
                                            + "Exception with null value for " 
                                            + "name and got the Exception : " 
                                            + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested+"Did not" 
                                            + " Construct InvalidNavigatorView" 
                                            + "Exception with given message" 
                                            + "\nGiven msg = "+msg+"Got msg = " 
                                            + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + "with given params \nGiven params = " 
                                      + params+ "Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    +"with given ClassName \nGiven ClassName =" 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with null Name" 
                        + "\nGiven Name = "+ name+"Got Name = " +gotName+"\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with given HelpSet" 
                    + "\nGiven HelpSet = " +hs+ "Got HelpSet = " +gotHS+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase8() {
        
        String apiTested ="InvalidNavigatorViewException(String msg,HelpSet hs," 
        + " String name, String label, Locale locale, String className," 
        + " Hashtable params)  : " 
        + "\nTestCase : Construct InvalidNavigatorViewException with null for " 
        + "hs and valid values for msg,name,label,locale,className,params and " 
        + "throw the exception" 
        + "\nExpected Result : Should create InvalidNavigatorViewException " 
        + "object and the Exception must be got." 
        + "\nObtained Result : ";
        
        String msg = "";
        HelpSet hs = null;
        String name = "";
        String label = "";
        Locale locale = null;
        String className = "";
        Hashtable params = null;
        try {
            hs = null;
            msg = "Test Message";
            name = "NAME";
            label = "LABEL";
            locale = Locale.getDefault();
            className = "IndexView";
            params = new Hashtable();
            InvalidNavigatorViewException INVException =
                new InvalidNavigatorViewException(msg, hs, name, label, locale,
                                                 className, params);
            if(INVException instanceof InvalidNavigatorViewException) {
                throw INVException;
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException object\n");
            }
        } catch(InvalidNavigatorViewException inve) {
            HelpSet gotHS = inve.getHelpSet();
            String gotName = inve.getName();
            String gotLabel = inve.getLabel();
            Locale gotLocale = inve.getLocale();
            String gotClassName = inve.getClassName();
            Hashtable gotParams = inve.getParams();
            String gotMsg = inve.getMessage();
            if(hs == gotHS) {
                if(name.equals(gotName)) {
                    if(label.equals(gotLabel)) {
                        if(locale.equals(gotLocale)) {
                            if(className.equals(gotClassName)) {
                                if(params.equals(gotParams)) {
                                    if(msg.equals(gotMsg)) {
                                        return Status.passed(apiTested 
                                            + "Constructed InvalidNavigatorView" 
                                            + "Exception with null value for " 
                                            + "Helpset and got the Exception : " 
                                            + inve + "\n");
                                    } else {
                                        return Status.failed(apiTested 
                                          +"Did not Construct InvalidNavigator" 
                                          + "ViewException with given message " 
                                          +"\nGiven msg = " +msg+ "Got msg = " 
                                          + gotMsg + "\n");
                                    }
                                } else {
                                    return Status.failed(apiTested + "Did not " 
                                      +"Construct InvalidNavigatorViewException" 
                                      + "with given params \nGiven params = " 
                                      + params+"Got params = "+gotParams+"\n");
                                }
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct InvalidNavigatorViewException " 
                                    + "with given ClassName\nGiven ClassName = " 
                                    + className + "Got ClassName = " 
                                    + gotClassName + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + "InvalidNavigatorViewException with given " 
                                + "Locale \nGiven Locale = " + locale 
                                + "Got Locale = " + gotLocale + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "InvalidNavigatorViewException with given Label" 
                            + "\nGiven Label = " + label + "Got Label = " 
                            + gotLabel + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "InvalidNavigatorViewException with given Name" 
                        + "\nGiven Name = "+name+"Got Name = "+gotName+"\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "InvalidNavigatorViewException with null HelpSet" 
                    + "\nGiven HelpSet = " +hs+"Got HelpSet = "+gotHS+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

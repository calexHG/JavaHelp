/*
* @(#)AddHelpNavigatorTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.JHelpNavigator;
import javax.help.IndexView;
import javax.help.NavigatorView;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Enumeration;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.help.JHelpTOCNavigator;
/**
* Tests for javax.help.JHelp
* Method: addHelpNavigator(JHelpNavigator navigator)
*
* @author Sudhakar.Adini
*/
public class AddHelpNavigatorTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public AddHelpNavigatorTest() {
        
    }
    
    public static void main(String argv[]) {
        AddHelpNavigatorTest test = new AddHelpNavigatorTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " addHelpNavigator(JHelpNavigator navigator)" 
        + "\nTestCase : Call addHelpNavigator(JHelpNavigator navigator) and "
        + "check it with getHelpNavigators()" 
        + "\nExpected Result :It should add the JHelpNavigator   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC +"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            		Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, 
            		new DefaultHelpModel(nav.getHelpSet()));            
            jhelp.addHelpNavigator(jhn);
			boolean check=false;
            Enumeration en = jhelp.getHelpNavigators();
            if(en.hasMoreElements()) {
                int i = 1;
                for(;en.hasMoreElements();i++) {
                    JHelpNavigator jhn1 = (JHelpNavigator)en.nextElement();
                    if(jhn1 != jhn) {					
                        continue;
                    }
                    else {                        		
                        check=true;
                    }
                }
				if(check)
                	return Status.passed(apiTested + "Okay");
				else
					return Status.failed(apiTested + "Failed");
            }
            else {
                return Status.failed(apiTested 
                	+"It did not returns the JHelpNavigators properly");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested =" Method:addHelpNavigator(JHelpNavigator navigator)" 
        + "\nTestCase : Call the addHelpNavigator(JHelpNavigator navigator)"
        + " by passing null for navigator" 
        + "\nExpected Result :It should throw NullPointerException   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            JHelpNavigator jhn = null;            
            jhelp.addHelpNavigator(jhn);
			return Status.failed(apiTested +"No Exception raised");			
        }
        catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested+"GotException :" + e.toString());
            }
            else {
                return Status.failed(apiTested+"GotException :" + e.toString());
            }
        }
    } //testCase2 finished
}

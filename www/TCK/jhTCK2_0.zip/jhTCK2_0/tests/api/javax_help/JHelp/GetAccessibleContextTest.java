/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... JHelp().getAccessibleContext() --> JHelp().getAccessibleContext()
 *
 * testCase2 ... JHelp(hs).getAccessibleContext() --> JHelp(hs).getAccessibleContext()
 *
 * testCase3 ... JHelp(model).getAccessibleContext() --> JHelp(model).getAccessibleContext()
 *
 * testCase4 ... JHelp(model, history).getAccessibleContext() --> JHelp(model, history).getAccessibleContext()
 */

package javasoft.sqe.tests.api.javax.help.JHelp;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.TextHelpModel;
import javax.help.DefaultHelpModel;

import javax.accessibility.AccessibleContext;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp ... getAccessibleContext()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetAccessibleContextTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetAccessibleContextTest() {
    }

    public static void main(String argv[]) {
        GetAccessibleContextTest test = new GetAccessibleContextTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.accessibility.AccessibleContext getAccessibleContext()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "javax.accessibility.AccessibleContext getAccessibleContext(): "
            + "TestCase: '(new JHelp()).getAccessibleContext()' "
            + "ExpectedResult: 'javax.accessibility.AccessibleContext' "
            + "ObtainedResult: ";

        try {
            //create JHelp object ... start
            JHelp jhelp = new JHelp();
            //create JHelp object ... end

            Object accessibleContext = jhelp.getAccessibleContext();


            if (accessibleContext != null) { //returned value is not 'null'
                if (accessibleContext instanceof AccessibleContext) { //returned object is instance of AccessibleContext
                    return Status.passed(apiTested + "Got 'javax.accessibility.AccessibleContext'");
                } else { //returned object is instance of AccessibleContext
                    return Status.failed(apiTested + "Did not construct AccessibleContext object");
                }
            } else { //returned value is 'null'
                return Status.failed(apiTested + "Did not get 'javax.accessibility.AccessibleContext': " + jhelp.getAccessibleContext() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

    /**
     * Method test: <code>javax.accessibility.AccessibleContext getAccessibleContext()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "javax.accessibility.AccessibleContext getAccessibleContext(): "
            + "TestCase: '(new JHelp(hs)).getAccessibleContext()' "
            + "ExpectedResult: 'javax.accessibility.AccessibleContext' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //create JHelp object ... start
            JHelp jhelp = new JHelp(hs);
            //create JHelp object ... end

            Object accessibleContext = jhelp.getAccessibleContext();


            if (accessibleContext != null) { //returned value is not 'null'
                if (accessibleContext instanceof AccessibleContext) { //returned object is instance of AccessibleContext
                    return Status.passed(apiTested + "Got 'javax.accessibility.AccessibleContext'");
                } else { //returned object is instance of AccessibleContext
                    return Status.failed(apiTested + "Did not construct AccessibleContext object");
                }
            } else { //returned value is 'null'
                return Status.failed(apiTested + "Did not get 'javax.accessibility.AccessibleContext': " + jhelp.getAccessibleContext() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.accessibility.AccessibleContext getAccessibleContext()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "javax.accessibility.AccessibleContext getAccessibleContext(): "
            + "TestCase: '(new JHelp(model)).getAccessibleContext()' "
            + "ExpectedResult: 'javax.accessibility.AccessibleContext' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //creating TextHelpModel instance ... start
            TextHelpModel model = new DefaultHelpModel(hs);
            //creating TextHelpModel instance ... end

            //create JHelpContentViewer object ... start
            JHelp jhelp = new JHelp(model);
            //create JHelpContentViewer object ... end

            Object accessibleContext = jhelp.getAccessibleContext();


            if (accessibleContext != null) { //returned value is not 'null'
                if (accessibleContext instanceof AccessibleContext) { //returned object is instance of AccessibleContext
                    return Status.passed(apiTested + "Got 'javax.accessibility.AccessibleContext'");
                } else { //returned object is instance of AccessibleContext
                    return Status.failed(apiTested + "Did not construct AccessibleContext object");
                }
            } else { //returned value is 'null'
                return Status.failed(apiTested + "Did not get 'javax.accessibility.AccessibleContext': " + jhelp.getAccessibleContext() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.accessibility.AccessibleContext getAccessibleContext()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase4() {
        String apiTested = "javax.accessibility.AccessibleContext getAccessibleContext(): "
            + "TestCase: '(new JHelp(model, history)).getAccessibleContext()' "
            + "ExpectedResult: 'javax.accessibility.AccessibleContext' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //creating TextHelpModel instance ... start
            TextHelpModel model = new DefaultHelpModel(hs);
            //creating TextHelpModel instance ... end

            //create JHelpContentViewer object ... start
            JHelp jhelp = new JHelp(model);
            //create JHelpContentViewer object ... end

            Object accessibleContext = jhelp.getAccessibleContext();


            if (accessibleContext != null) { //returned value is not 'null'
                if (accessibleContext instanceof AccessibleContext) { //returned object is instance of AccessibleContext
                    return Status.passed(apiTested + "Got 'javax.accessibility.AccessibleContext'");
                } else { //returned object is instance of AccessibleContext
                    return Status.failed(apiTested + "Did not construct AccessibleContext object");
                }
            } else { //returned value is 'null'
                return Status.failed(apiTested + "Did not get 'javax.accessibility.AccessibleContext': " + jhelp.getAccessibleContext() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
* @(#)GetHelpNavigatorsTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.JHelpNavigator;
import javax.help.IndexView;
import javax.help.NavigatorView;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Enumeration;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import javax.help.JHelpTOCNavigator;
/**
* Tests for javax.help.JHelp
* Method: getHelpNavigators()
*
* @author Sudhakar.Adini
*/
public class GetHelpNavigatorsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpNavigatorsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHelpNavigatorsTest test = new GetHelpNavigatorsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: getHelpNavigators()" 
        + "\nTestCase : Call the ggetHelpNavigators() " 
        + "\nExpected Result :It should return the Enumeration of"
        + " HelpNavigators in the HelpUI   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/merge/MasterTOC.xml");
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
			boolean check=false;
			NavigatorView nv[] = hs.getNavigatorViews();				
            Enumeration en = jhelp.getHelpNavigators();
            if(en.hasMoreElements()) {                
                for(int i=0;en.hasMoreElements();i++) {
                    JHelpNavigator nav = (JHelpNavigator)en.nextElement();
					NavigatorView nv1=nav.getNavigatorView();
                    if(nv1.equals(nv[i])) { 
					check=true;
                    }
                    else {
                        return Status.failed(apiTested + "failed");
                    }
                }
                if(check)
					return Status.passed(apiTested + "Okay");
				else
					return Status.failed(apiTested + "failed");
            }
            else {
                return Status.failed(apiTested+"It did not return Navigators");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } //testCase1 finished
}


/*
* @(#)JHelpTest.java	1.4 99/03/10
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp
 * Constructor: JHelpTest()
 * Create a JHelp
 *
 * @author Sudhakar.Adini
 */

public class JHelpTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public JHelpTest() {
        
    }
    
    public static void main(String argv[]) {
        JHelpTest test = new JHelpTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Constructor: JHelpTest()" 
        + "\nTestCase : Call JHelp() " 
        + "\nExpected Result :It should construct the JHelp object  " 
        + "\nObtained Result : ";
        try {
            JHelp jhelp = new JHelp();
            if(jhelp instanceof JHelp) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested+"Not Constructed JHelp object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
    
    public Status testCase2() {
        String apiTested = " Constructor: JHelpTest(HelpSet hs)"
        + "\nTestCase : Call JHelp by passing proper value for hs "
        + "\nExpected Result :It should Construct JHelp object   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            URL url1 = jhelp.getHelpSetURL();
            if(jhelp instanceof JHelp && (url1.equals(url))) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested+"Not Constructed JHelp object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
    
    public Status testCase3() {
        String apiTested = " Constructor: JHElp(HelpSet hs)" 
        + "\nTestCase : Call JHelp with  hs as null" 
        + "\nExpected Result :It should construct JHelp object " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = null; 								
            JHelp jhelp = new JHelp(hs);
			HelpSet hs1 = ((DefaultHelpModel)jhelp.getModel()).getHelpSet();            
            if(jhelp instanceof JHelp && (hs1==null)) {
                return Status.passed(apiTested+"Constructing JHelp object Ok");
            }
            else {
                return Status.failed(apiTested + "Not Construct JHelp object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
    
    public Status testCase4() {
        String apiTested = " Constructor:JHelp(TextModel model)" 
        + "\nTestCase : Call JHelp by passing proper value for model" 
        + "\nExpected Result :It should Construct JHelp object   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpModel model = new DefaultHelpModel(hs);
            JHelp jhelp = new JHelp(model);
            URL url1 = jhelp.getHelpSetURL();
            DefaultHelpModel model1 = (DefaultHelpModel)jhelp.getModel();
            if(jhelp instanceof JHelp 
                && (url1.equals(url)) && (model1.equals(model))) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Not Construct JHelp object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 	
    
    public Status testCase5() {
        String apiTested = " Constructor: JHelp(TextModel model)" 
        + "\nTestCase : Call JHElp by passing null for model" 
        + "\nExpected Result :It should Construct JHelp object" 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpModel model = null; 								
            JHelp jhelp = new JHelp(hs);
            DefaultHelpModel model1 = (DefaultHelpModel)jhelp.getModel();
            URL url1 = jhelp.getHelpSetURL();
            
            if(jhelp instanceof JHelp && (url1.equals(url))) {
                return Status.passed(apiTested+"Constructing JHelp object Ok");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct JHelp object");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 	
}

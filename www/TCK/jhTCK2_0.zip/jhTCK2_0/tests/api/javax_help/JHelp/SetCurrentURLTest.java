
/*
* @(#)SetCurrentURLTest.java	1.2 99/03/10
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.DefaultHelpModel;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp
 * Constructor Test
 * Create a JHelp
 *
 * @author Sudhakar.Adini
 */

public class SetCurrentURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetCurrentURLTest() {
        
    }
    
    public static void main(String argv[]) {
        SetCurrentURLTest test = new SetCurrentURLTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: setCurrentURL(URL url)" 
        + "\nTestCase : Set the url  with this method and retrieve with "
        + "getCurrentURL()  " 
        + "\nExpected Result :It should return the same url   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            jhelp.setCurrentURL(url1);
            DefaultHelpModel model = (DefaultHelpModel)jhelp.getModel();
            URL url2 = model.getCurrentURL();
            if(url2.equals(url1)) {
                return Status.passed(apiTested + "It sets url Okay");
            }
            else {
                return Status.failed(apiTested + "Did not sets the url");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
    
    public Status testCase2() {
        String apiTested = " Method: getModel()" 
        + "\nTestCase: Call the setCurrentURL(URL url) by passing null for url"
        + "\nExpected Result :It should throw an IllegalArgumentException " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = null; 
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpModel model = new DefaultHelpModel(hs);
            JHelp jhelp = new JHelp(model);            
            jhelp.setCurrentURL(url1);            
            DefaultHelpModel model1 = (DefaultHelpModel)jhelp.getModel();
            URL url2 = model1.getCurrentURL();            
	    return Status.failed(apiTested + "Did not return the url");
        }
        catch(IllegalArgumentException npe) {
            return Status.passed(apiTested + "Got IllegalArgumentException: " + npe.toString());
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 		
}

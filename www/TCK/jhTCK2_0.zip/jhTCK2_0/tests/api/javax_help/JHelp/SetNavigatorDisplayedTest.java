
/*
* @(#)SetNavigatorDisplayedTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.JHelpNavigator;
import javax.help.IndexView;
import javax.help.NavigatorView;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp
 * Method: SetNavigatorDisplayed(boolean displayed)
 *
 * @author Sudhakar.Adini
 */

public class SetNavigatorDisplayedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetNavigatorDisplayedTest() {
        
    }
    
    public static void main(String argv[]) {
        SetNavigatorDisplayedTest test = new SetNavigatorDisplayedTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
     
    public Status testCase1() {
        String apiTested = " Method: SetNavigatorDisplayed(boolean displayed)" 
        + "\nTestCase : Call SetNavigatorDisplayed() with true as argument "
        + "and retrieve it with isNavigatorDisplayed() " 
        + "\nExpected Result :It should return the true  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            jhelp.setNavigatorDisplayed(true);
          
            boolean dis = jhelp.isNavigatorDisplayed();
            
            if(dis) {
                return Status.passed(apiTested + "The navigator is displayed Okay");
            }
            else {
                return Status.failed(apiTested + "The navigator is not displayed ");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 		
    
    public Status testCase2() {
        String apiTested = " Method: SetNavigatorDisplayed(boolean displayed)" 
        + "\nTestCase : Call SetNavigatorDisplayed() with false as argument "
        + "and retrieve it with isNavigatorDisplayed() " 
        + "\nExpected Result :It should return the false  " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url1 = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            boolean b = false;
            jhelp.setNavigatorDisplayed(b);            
            boolean dis = jhelp.isNavigatorDisplayed();            
            if(!dis) {
                return Status.passed(apiTested 
                + "The navigator is not displayed Okay");
            }
            else {
                return Status.failed(apiTested + "Navigator is  displayed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 	
}

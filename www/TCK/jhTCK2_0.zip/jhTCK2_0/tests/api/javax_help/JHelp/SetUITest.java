
/*
* @(#)SetUITest.java	1.2 99/03/10
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.plaf.basic.BasicHelpUI;
import javax.help.plaf.HelpUI;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp
 * Method: setUI(HelpUI ui)
 *
 * @author Sudhakar.Adini
 */

public class SetUITest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetUITest() {
        
    }
    
    public static void main(String argv[]) {
        SetUITest test = new SetUITest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: setUI(HelpUI ui)" 
        + "\nTestCase : set the HelpUI with this method and retrive the "
        + "same with getUI() " 
        + "\nExpected Result :It should return the same UI   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            BasicHelpUI ui = new BasicHelpUI(jhelp);
            jhelp.setUI(ui);
            HelpUI ui1 = jhelp.getUI();
            if(ui1.equals(ui)) {
                return Status.passed(apiTested + "It set the UI Okay ");
            }
            else {
                return Status.failed(apiTested + "Did not set the UI");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = " Method: setUI(HelpUI ui)" 
        + "\nTestCase : Call the setUI() by passing the null for ui " 
		+ " and retrieve the same with getUI() "
        + "\nExpected Result :It should return the same UI " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            DefaultHelpModel model = new DefaultHelpModel(hs);
            JHelp jhelp = new JHelp(model);            
            jhelp.setUI(null);            
            HelpUI ui1 = jhelp.getUI();            
            if(ui1 == null) {
                return Status.passed(apiTested + "It set the UI Okay");
            }
            else {
                return Status.failed(apiTested + "Did not set the UI");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } 		
}


/*
* 03/02/99 @(#)UpdateUITest.java	1.1
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.JHelp;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.plaf.basic.BasicHelpUI;
import javax.help.plaf.HelpUI;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelp
 * Method: updateUI()
 *
 * @author Sudhakar.Adini
 */

public class UpdateUITest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public UpdateUITest() {
        
    }
    
    public static void main(String argv[]) {
        UpdateUITest test = new UpdateUITest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: updateUI()" 
        + "\nTestCase : call the updateUI() for updating UI  "
        + " and retrive it with getUI() " 
        + "\nExpected Result :It should return the HelpUI object   " 
        + "\nObtained Result : ";
        try {
            ClassLoader l = this.getClass().getClassLoader();
         
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(l, url);
            JHelp jhelp = new JHelp(hs);
            BasicHelpUI ui = new BasicHelpUI(jhelp);
			jhelp.setUI(ui);
            jhelp.updateUI();
            HelpUI ui1 = jhelp.getUI();
            if(ui1 instanceof HelpUI &&(ui1!=null)) {
                return Status.passed(apiTested + "It update the UI Okay ");
            }
            else {
                return Status.failed(apiTested + "Did not update the UI");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    }

}

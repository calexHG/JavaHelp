/*
 * @(#)AddHighlightTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.TextHelpModel.Highlight;
import javax.help.DefaultHelpModel;
import javax.help.JHelpContentViewer;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class AddHighlightTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public AddHighlightTest() {
        
    }
    
    public static void main(String argv[]) {
        AddHighlightTest test = new AddHighlightTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                 new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "addHighlight(int pos0 , int pos1) : " 
        + "\nTestCase : Call addHighlight with Integer.MAX_VALUE for pos0 " 
        + "and pos1" 
        + "\nExpected Result : Highlight shd be added with given pos0 and pos1." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            int pos0 = Integer.MAX_VALUE;
            int pos1 = Integer.MAX_VALUE;
            jhelpContentViewer.addHighlight(pos0, pos1);
            DefaultHelpModel defaultHelpModel =
                            (DefaultHelpModel)jhelpContentViewer.getModel();
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            if(highlights.length == 1) {
                if(gotPos0 == pos0) {
                    if(gotPos1 == pos1) {
                        return Status.passed(apiTested+"Added proper Highlight" 
                            + "\nGiven Pos0 = "+pos0+" Got Pos0 "+gotPos0 
                            + "\nGiven Pos1 = "+pos1+" Got Pos1 "+gotPos1+"\n");
                    } else {
                        return Status.failed(apiTested + "Did not add Highlight" 
                            + " with proper Pos1.\nGiven Pos1 = " + pos1 
                            + " Got Pos1 " + gotPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not add  Highlight " 
                        + "with proper Pos0.\nGiven Pos0 = " + pos0 
                        + " Got Pos0 " + gotPos0 + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not add Highlight.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "addHighlight(int pos0 , int pos1) :  " 
        + "\nTestCase : Call addHighlight with Integer.MIN_VALUE for pos0 " 
        + "and value > 0 for pos1" 
        + "\nExpected Result : Should throw IllegalArgumentException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            int pos0 = Integer.MIN_VALUE;
            int pos1 = 30;
            jhelpContentViewer.addHighlight(pos0, pos1);
            return Status.failed(apiTested + "Did not get IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException : " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "addHighlight(int pos0 , int pos1) :  " 
        + "\nTestCase : Call addHighlight with value > 0 for pos0 " 
        + "and Integer.MIN_VALUE for pos1" 
        + "\nExpected Result : Should throw IllegalArgumentException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            int pos0 = 30;
            int pos1 = Integer.MIN_VALUE;
            jhelpContentViewer.addHighlight(pos0, pos1);
            return Status.failed(apiTested + "Did not get IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException : " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase4() {
        
        String apiTested = "addHighlight(int pos0 , int pos1) : " 
        + "\nTestCase : add two highlights " 
        + "\nExpected Result : Both highlights shd be added in the specified " 
        + "order with the specified values." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            int pos0 = 10;
            int pos1 = 20;
            int mpos0 = 30;
            int mpos1 = 40;
            jhelpContentViewer.addHighlight(pos0, pos1);
            jhelpContentViewer.addHighlight(mpos0, mpos1);
            DefaultHelpModel defaultHelpModel =
                             (DefaultHelpModel)jhelpContentViewer.getModel();
            Highlight highlights[] = defaultHelpModel.getHighlights();
            int gotPos0 = highlights[0].getStartOffset();
            int gotPos1 = highlights[0].getEndOffset();
            int gotmPos0 = highlights[1].getStartOffset();
            int gotmPos1 = highlights[1].getEndOffset();
            if(highlights.length == 2) {
                if(gotPos0 == pos0 && gotmPos0 == mpos0) {
                    if(gotPos1 == pos1 && gotmPos1 == mpos1) {
                        return Status.passed(apiTested + "Added proper " 
                            + "Highlights.\nGiven Pos0's = " + pos0 + "," 
                            + mpos0 + " Got Pos0's = " + gotPos0 + "," 
                            + gotmPos0 + "\nGiven Pos1's = " + pos1 + "," 
                            + mpos1+" Got Pos1's "+gotPos1+","+gotmPos1+"\n");
                    } else {
                        return Status.failed(apiTested +"Did not add  Highlight" 
                            + " with proper Pos1.\nGiven Pos1's = " + pos1 
                            + " , " + mpos1 + " Got Pos1's " + gotPos1 + "," 
                            + gotmPos1 + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not add  Highlight " 
                        + "with proper Pos0.\nGiven Pos0's = " + pos0 + "," 
                        + mpos0+" Got Pos0's = "+gotPos0+"," +gotmPos0+"\n");
                }
            } else {
                return Status.failed(apiTested + "Did not add Highlights .\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

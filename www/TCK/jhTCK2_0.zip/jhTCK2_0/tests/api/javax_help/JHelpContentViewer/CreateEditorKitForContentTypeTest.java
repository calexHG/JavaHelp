/*
 * @(#)CreateEditorKitForContentTypeTest.java	1.3 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.JHelpContentViewer;
import javax.help.HelpSet;
import javax.swing.text.EditorKit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class CreateEditorKitForContentTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateEditorKitForContentTypeTest() {
        
    }
    
    public static void main(String argv[]) {
        CreateEditorKitForContentTypeTest test =
                new CreateEditorKitForContentTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "createEditorKitForContentType(String type) : " 
        + "\nTestCase : Construct JHelpContentViewer and call " 
        + "createEditorKitForContentType with type text/html" 
        + "\nExpected Result : Shd return an EditorKit" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String type = "text/html";
            EditorKit editKit = 
                    jhelpContentViewer.createEditorKitForContentType(type);
            if(editKit instanceof EditorKit) {
                return Status.passed(apiTested + "\nGot editorKit = " 
                    + editKit + "\n");
            } else {
                return Status.failed(apiTested + "\nGot editorKit = " 
                    + editKit + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "createEditorKitForContentType(String type) : " 
        + "\nTestCase : Construct JHelpContentViewer and call " 
        + "createEditorKitForContentType with type invalid" 
        + "\nExpected Result : Shd Return null" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String type = "invalid";
            EditorKit editKit =
                    jhelpContentViewer.createEditorKitForContentType(type);
            if(editKit == null) {
                return Status.passed(apiTested + "Got Null editorKit\n");
            } else {
                return Status.failed(apiTested + "Did not get null editor kit" 
                    + "\nGot editorKit = " + editKit + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "createEditorKitForContentType(String type) : " 
        + "\nTestCase : Construct JHelpContentViewer and call " 
        + "createEditorKitForContentType with type null" 
        + "\nExpected Result : Should Throw NullPointerException" 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String type = null;
            EditorKit editKit =
                    jhelpContentViewer.createEditorKitForContentType(type);
	    return Status.failed(apiTested + "Exception not thrown " +
				 "for null parameter");
	} catch(Exception e) {
            if(e instanceof NullPointerException) {
                return Status.passed(apiTested + e
				     + " raised for  null parameter" );
            }
            else {
		return Status.failed(apiTested + "Exception raised for " +
				     "null parameter " + e);           
	    }
        }
    }
}

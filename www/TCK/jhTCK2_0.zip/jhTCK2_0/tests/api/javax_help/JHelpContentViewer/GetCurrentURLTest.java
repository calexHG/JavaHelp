/*
 * @(#)GetCurrentURLTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.JHelpContentViewer;
import javax.help.DefaultHelpModel;
import javax.help.HelpSet;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class GetCurrentURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetCurrentURLTest() {
        
    }
    
    public static void main(String argv[]) {
        GetCurrentURLTest test = new GetCurrentURLTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getCurrentURL() : " 
        + "\nTestCase :Construct JHelpContentViewer object and call " 
        + "getCurrentURL() without setting  URL " 
        + "\nExpected Result : Shd return null." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            URL gotURL = jhelpContentViewer.getCurrentURL();
            if(gotURL == null) {
                return Status.passed(apiTested + "Returned null.\n");
            } else {
                return Status.failed(apiTested + "Did not return null.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "getCurrentURL() : " 
        + "\nTestCase :Construct JHelpContentViewer object and call " 
        + "getCurrentURL() after setting  URL " 
        + "\nExpected Result : Shd return given URL ." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            URL url = new URL("file", null, HSLOC+"/holidays/hol/thanks.html");
            jhelpContentViewer.setCurrentURL(url);
            URL gotURL = jhelpContentViewer.getCurrentURL();
            if(gotURL.equals(url)) {
                return Status.passed(apiTested + "Returned given URL." 
                    + "\nGiven URL = " + url + " \nGot URL = " + gotURL + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given URL." 
                    + "\nGiven URL = " + url + " \nGot URL = " + gotURL + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

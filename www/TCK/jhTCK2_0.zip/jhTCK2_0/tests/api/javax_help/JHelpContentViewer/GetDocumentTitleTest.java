/*
 * @(#)GetDocumentTitleTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.JHelpContentViewer;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class GetDocumentTitleTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetDocumentTitleTest() {
        
    }
    
    public static void main(String argv[]) {
        
        GetDocumentTitleTest test = new GetDocumentTitleTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getDocumentTitle() : " 
        + "\nTestCase : Construct JHelpContentViewer and call " 
        + "getDocumentTitle() without setting it." 
        + "\nExpected Result : Shd return null." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String gotTitle = jhelpContentViewer.getDocumentTitle();
            if(gotTitle == null) {
                return Status.passed(apiTested + "Returned null.\n");
            } else {
                return Status.failed(apiTested + "Did not return null.\n ");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "getDocumentTitle() : " 
        + "\nTestCase : Construct JHelpContentViewer and call " 
        + "getDocumentTitle() after setting it." 
        + "\nExpected Result : Shd return given title." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String title = "Testing  the Title";
            DefaultHelpModel model =
                    (DefaultHelpModel)jhelpContentViewer.getModel();
            model.setDocumentTitle(title);
            String gotTitle = jhelpContentViewer.getDocumentTitle();
            if(gotTitle.equals(title)) {
                return Status.passed(apiTested + "Returned given title." 
                    + "\nGiven Title = "+title+" \nGot Title = "+gotTitle+"\n");
            } else {
                return Status.failed(apiTested + "Did not return given title." 
                    +"\nGiven Title = "+title+" \nGot Title = "+gotTitle +"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

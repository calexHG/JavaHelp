/*
 * @(#)JHelpContentViewerTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import javax.help.HelpModel;
import javax.help.JHelpContentViewer;
import javax.help.DefaultHelpModel;
import javax.help.TextHelpModel;
import javax.help.HelpSet;
import javax.help.plaf.HelpContentViewerUI;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class JHelpContentViewerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public JHelpContentViewerTest() {
        
    }
    
    public static void main(String argv[]) {
        JHelpContentViewerTest test = new JHelpContentViewerTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                                     new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "JHelpContentViewer() : " 
        + "\nTestCase : Construct JHelpContentViewer " 
        + "\nExpected Result : Should Construct JHelpContentViewer with " 
        + "DefaultHelpModel (with null helpset) and HelpContentViewerUI." 
        + "\nObtained Result : ";
        
        try {
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer();
            HelpModel gotModel = jhelpContentViewer.getModel();
            HelpSet gotHS = gotModel.getHelpSet();
            if(gotModel instanceof DefaultHelpModel) {
                if(gotHS == null) {
                    if(jhelpContentViewer.getUI() instanceof
                                                 HelpContentViewerUI) {
                        return Status.passed(apiTested + "Constructed " 
                            + "JHelpContentViewer object with DefaultHelpModel " 
                            + "(with null helpset) and HelpContentViewerUI." 
                            + "\nGot UI = " + jhelpContentViewer.getUI() 
                            + " , Got Helpset = " + gotHS + "\n");
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                        + "JHelpContentViewer object with HelpContentViewerUI" 
                        + "\nGot UI = " + jhelpContentViewer.getUI() 
                        + " , Got Helpset = " + gotHS + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "JHelpContentViewer object with DefaultHelpModel " 
                        + "( with null helpset).\nGot Helpset = " +gotHS+"\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "JHelpContentViewer object with DefaultHelpModel" 
                    + "\n Got Model = " + gotModel + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "JHelpContentViewer(HelpSet hs) : " 
        + "\nTestCase : Construct JHelpContentViewer with valid hs" 
        + "\nExpected Result : Should Construct JHelpContentViewer with " 
        + "DefaultHelpModel (with given helpset) and HelpContentViewerUI." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            HelpModel gotModel = jhelpContentViewer.getModel();
            HelpSet gotHS = gotModel.getHelpSet();
            if(gotModel instanceof DefaultHelpModel) {
                if(gotHS.equals(hs)) {
                    if(jhelpContentViewer.getUI() instanceof
                                                     HelpContentViewerUI) {
                        return Status.passed(apiTested + "Constructed " 
                            + "JHelpContentViewer object with DefaultHelpModel " 
                            + "(with given helpset) and HelpContentViewerUI." 
                            + "\nGot UI = " + jhelpContentViewer.getUI() + "\n" 
                            + "Given HelpSet = " + hs + " , Got Helpset = " 
                            + gotHS + "\n");
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "JHelpContentViewer object with HelpContentViewer" 
                            + "UI.\nGot UI = " + jhelpContentViewer.getUI() 
                            + "\n" + "Given HelpSet = " +hs+" , Got Helpset = " 
                            + gotHS + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                    + "JHelpContentViewer object with DefaultHelpModel " 
                    + "( with given helpset).\nGiven HelpSet = " + hs 
                    + " , Got Helpset = " + gotModel.getHelpSet() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                + "JHelpContentViewer object with DefaultHelpModel." 
                + "\n Got Model = " + gotModel + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "JHelpContentViewer(HelpSet hs) : " 
        + "\nTestCase : Construct JHelpContentViewer with null hs" 
        + "\nExpected Result : Should Construct JHelpContentViewer with " 
        + "DefaultHelpModel (with null helpset) and HelpContentViewerUI." 
        + "\nObtained Result : ";
        
        try {
            HelpSet hs = null;
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            HelpModel gotModel = jhelpContentViewer.getModel();
            HelpSet gotHS = gotModel.getHelpSet();
            if(gotModel instanceof DefaultHelpModel) {
                if(gotHS == hs) {
                    if(jhelpContentViewer.getUI() instanceof 
                                                    HelpContentViewerUI) {
                        return Status.passed(apiTested + "Constructed " 
                            + "JHelpContentViewer object with DefaultHelpModel " 
                            + "(with null helpset) and HelpContentViewerUI" 
                            + "\nGot UI = " + jhelpContentViewer.getUI() + "\n" 
                            + "Given HelpSet = " + hs + " , Got Helpset = " 
                            + gotHS + "\n");
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "JHelpContentViewer object with HelpContentViewer" 
                            + "UI\nGot UI = " +jhelpContentViewer.getUI()+ "\n" 
                            + "Given HelpSet = " + hs + " , Got Helpset = " 
                            + gotHS + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "JHelpContentViewer object with DefaultHelpModel " 
                        + "( with null helpset).\nGiven HelpSet = " + hs 
                        + " , Got Helpset = " + gotModel.getHelpSet() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "JHelpContentViewer object with DefaultHelpModel" 
                    + "\n Got Model = " + gotModel + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested = "JHelpContentViewer(TextHelpModel model) : " 
        + "\nTestCase : Construct JHelpContentViewer with valid model" 
        + "\nExpected Result : Should Construct JHelpContentViewer with " 
        + "given model and helpset and HelpContentViewerUI." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            DefaultHelpModel model = new DefaultHelpModel(hs);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(model);
            HelpModel gotModel = jhelpContentViewer.getModel();
            HelpSet gotHS = gotModel.getHelpSet();
            if(gotModel.equals(model)) {
                if(gotHS.equals(hs)) {
                    if(jhelpContentViewer.getUI() instanceof 
                                                    HelpContentViewerUI) {
                        return Status.passed(apiTested + "Constructed " 
                            + "JHelpContentViewer object with given model, " 
                            + "helpset and HelpContentViewerUI" 
                            + "\nGiven model = " + model + "\nGot Model = " 
                            + gotModel+"\nGot UI = "+jhelpContentViewer.getUI() 
                            + "\nGiven HelpSet = " + hs + " , Got Helpset = " 
                            + gotHS + "\n");
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "JHelpContentViewer object with HelpContentViewer" 
                            + "UI\nGot UI = " +jhelpContentViewer.getUI()+ "\n" 
                            + "Given HelpSet = " + hs + " , Got Helpset = " 
                            + gotHS + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "JHelpContentViewer object with given hs " 
                        + "\nGiven HelpSet = " + hs + " , Got Helpset = " 
                        + gotHS + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "JHelpContentViewer object with given model"
                    + "\nGiven model = " + model + "\n Got Model = " 
                    + gotModel + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }    
    
    public Status testCase5() {
        
        String apiTested = "JHelpContentViewer(TextHelpModel model) : " 
        + "\nTestCase : Construct JHelpContentViewer with null model" 
        + "\nExpected Result : Should Construct JHelpContentViewer with " 
        + "null model and HelpContentViewerUI." 
        + "\nObtained Result : ";
        
        try {
            TextHelpModel model = null;
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(model);
            HelpModel gotModel = jhelpContentViewer.getModel();
            if(gotModel==model) {
                if(jhelpContentViewer.getUI() instanceof 
                                               HelpContentViewerUI) {
                    return Status.passed(apiTested + "Constructed " 
                        + "JHelpContentViewer object with null model, " 
                        + " and HelpContentViewerUI" 
                        + "\nGiven model = " + model + "\nGot Model = " 
                        + gotModel+"\nGot UI = "+jhelpContentViewer.getUI() 
                        + "\n");
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                            + "JHelpContentViewer object with HelpContentViewer" 
                            + "UI\nGot UI = " +jhelpContentViewer.getUI()+ "\n" 
                            + "Given model = " + model + " , Got model = " 
                            + gotModel + "\n");
                }
                
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "JHelpContentViewer object with null model"
                    + "\nGiven model = " + model + "\n Got Model = " 
                    + gotModel + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }        
}

/*
 * @(#)RemoveHelpModelListenerTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import com.sun.help.jck.harness.FooHelpModelListener;
import com.sun.help.jck.harness.FooTextHelpModelListener;
import com.sun.help.jck.harness.StaticInfo;
import javax.help.HelpSet;
import javax.help.JHelpContentViewer;
import javax.help.event.HelpModelListener;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.DefaultHelpModel
 *
 * @author Meena C
 */

public class RemoveHelpModelListenerTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public RemoveHelpModelListenerTest() {
        
    }
    
    public static void main(String argv[]) {
        RemoveHelpModelListenerTest test =
                     new RemoveHelpModelListenerTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                     new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "removeHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : Call removeHelpModelListener after adding a listener." 
        + "Call setCurrentURL(url) and check if listener is not notified" 
        + "\nExpected Result : Shd removeHelpModelListener.idChanged() of " 
        + "HelpModelListener shd not be called." 
        + "\nObtained Result : ";
        
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooHelpModelListener l = new FooHelpModelListener();
            jhelpContentViewer.addHelpModelListener(l);
            jhelpContentViewer.removeHelpModelListener(l);
            URL url2 = new URL("file", null, HSLOC + "/hol/guy.html");
            jhelpContentViewer.setCurrentURL(url2);
            
            /* StaticInfo.bool is set to true within idChanged() 
             * of FooHelpModelListener 
             */
            if(StaticInfo.bool == false) {
                return Status.passed(apiTested + "idChanged() of " 
                    + "HelpModelListener is not called.\n");
            } else {
                return Status.failed(apiTested + "idChanged() of " 
                    + "HelpModelListener is called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not remove HelpModelListener" 
                + ", Got Exception : " + e);
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "removeHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : Call removeHelpModelListener without adding a listener" 
        + "\nExpected Result : No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooHelpModelListener l = new FooHelpModelListener();
            jhelpContentViewer.removeHelpModelListener(l);
            return Status.passed(apiTested + "Okay.No Exception Thrown\n");
        } catch(Exception e) {
            return Status.failed(apiTested + " Got Exception : " + e);
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "removeHelpModelListener(HelpModelListener l) : " 
        + "\nTestCase : pass null to removeHelpModelListener " 
        + "\nExpected Result :IllegalArgumentException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooHelpModelListener l = null;
            jhelpContentViewer.removeHelpModelListener(l);
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException " 
                    + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException , Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested = "removeHelpModelListener(TextHelpModelListener l) : " 
        + "\nTestCase : Call removeHelpModelListener after adding a listener." 
        + "Call addHighlight(int pos0 , int pos1) and check if listener is not " 
        + "notified" 
        + "\nExpected Result : Shd removeHelpModelListener.highlightsChanged() " 
        + "of HelpModelListener shd not be called." 
        + "\nObtained Result : ";
        
        
        /* Initialize the bool value to false */
        StaticInfo.bool = false;
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooTextHelpModelListener l = new FooTextHelpModelListener();
            jhelpContentViewer.addTextHelpModelListener(l);
            jhelpContentViewer.removeHelpModelListener(l);
            jhelpContentViewer.addHighlight(10, 20);
            
            /* StaticInfo.bool is set to true within highlightsChanged() 
             * of FooTextHelpModelListener 
             */
            if(StaticInfo.bool == false) {
                return Status.passed(apiTested + "highlightsChanged() of " 
                    + "FooTextHelpModelListener is not called.\n");
            } else {
                return Status.failed(apiTested + "highlightsChanged() of " 
                    + "FooTextHelpModelListener is called.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not remove HelpModelListener " 
                + ", Got Exception : " + e);
        }
    }
    
    public Status testCase5() {
        
        String apiTested = "removeHelpModelListener(TextHelpModelListener l) : " 
        + "\nTestCase : Call removeHelpModelListener without adding a listener." 
        + "\nExpected Result : No Exception shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooTextHelpModelListener l = new FooTextHelpModelListener();
            jhelpContentViewer.removeHelpModelListener(l);
            return Status.passed(apiTested + "Okay.No Exception Thrown\n");
        } catch(Exception e) {
            return Status.failed(apiTested + " Got Exception : " + e);
        }
    }
    
    public Status testCase6() {
        
        String apiTested = "removeHelpModelListener(TextHelpModelListener l) : " 
        + "\nTestCase : pass null to removeHelpModelListener " 
        + "\nExpected Result :IllegalArgumentException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            FooTextHelpModelListener l = null;
            jhelpContentViewer.removeHelpModelListener(l);
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException\n");
        } catch(IllegalArgumentException iae) {
            return Status.passed(apiTested + "Got IllegalArgumentException " 
                + iae + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Did not get " 
                + "IllegalArgumentException , Got Exception : " + e + "\n");
        }
    }
}

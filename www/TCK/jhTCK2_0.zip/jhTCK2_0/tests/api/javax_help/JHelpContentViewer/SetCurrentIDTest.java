/*
 * @(#)SetCurrentIDTest.java	1.3 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import javax.help.JHelpContentViewer;
import javax.help.DefaultHelpModel;
import javax.help.HelpModel;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.BadIDException;
import javax.help.InvalidHelpSetContextException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class SetCurrentIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetCurrentIDTest() {
        
    }
    
    public static void main(String argv[]) {
        SetCurrentIDTest test = new SetCurrentIDTest();
        Status s = test.run(argv, new PrintWriter(System.out),
                 new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "setCurrentID(Map.ID id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID with" 
        + " a valid ID" 
        + "\nExpected Result : Shd set the given ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String id = "thanksgiving";
            ID mapID = ID.create(id, hs);
            jhelpContentViewer.setCurrentID(mapID);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            if(gotMapID.equals(mapID)) {
                return Status.passed(apiTested + "Set the given ID\nGiven Id = " 
                    + mapID + " \nGot ID = " + gotMapID + "\n");
            } else {
                return Status.failed(apiTested + "Did not set given ID. " 
                    + "\nGiven Id = " +mapID+ " \nGot ID = " +gotMapID+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "setCurrentID(Map.ID id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID " 
        + "with a null ID" 
        + "\nExpected Result : Shd set the homeID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            ID mapID = null;
            jhelpContentViewer.setCurrentID(mapID);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            ID homeID = hs.getHomeID();
            if(gotMapID.equals(homeID)) {
                return Status.passed(apiTested + "Set home ID.\nGiven Id = " 
                    + mapID + " \nGot ID = " + gotMapID + "\n");
            } else {
                return Status.failed(apiTested + "Did not set home ID." 
                    + "\nGiven Id = " +mapID+ " \nGot ID = " +gotMapID+ "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "setCurrentID(Map.ID id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID " 
        + "with a invalid ID" 
        + "\nExpected Result : InvalidHelpSetContextException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            URL url2 = new URL("file", null, HSLOC+ "/merge/Master.hs");
            HelpSet hs2 = new HelpSet(cl, url2);
            String id = "merge.intro";
            ID mapID = ID.create(id, hs2);
            jhelpContentViewer.setCurrentID(mapID);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            return Status.failed(apiTested + "Did not get " 
                + "InvalidHelpSetContextException : ");
        } catch(InvalidHelpSetContextException ihe) {
            return Status.passed(apiTested+"Got InvalidHelpSetContextException:" 
                + ihe + "\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested = "setCurrentID(String id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID " 
        + "with a valid id" 
        + "\nExpected Result : Shd set the given ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String id = "thanksgiving";
            jhelpContentViewer.setCurrentID(id);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            String gotID = gotMapID.id;
            if(gotID.equals(id)) {
                return Status.passed(apiTested + "Set the given ID\nGiven Id = " 
                    + id + " \nGot ID = " + gotID + "\n");
            } else {
                return Status.failed(apiTested + "Did not set given ID." 
                    + "\nGiven Id = " + id + " \nGot ID = " + gotID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        
        String apiTested = "setCurrentID(String id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID " 
        + "with a null id" 
        + "\nExpected Result : Shd set the homeID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String id = null;
            jhelpContentViewer.setCurrentID(id);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            ID homeID = hs.getHomeID();
            String homeid = homeID.id;
            String gotID = gotMapID.id;
            if(gotID.equals(homeid)) {
                return Status.passed(apiTested + "Set home ID.\nGiven Id = " 
                    + id + " \nGot ID = " + gotID + "\n");
            } else {
                return Status.failed(apiTested + "Did not set home ID. " 
                    + "\nGiven Id = " + id + " \nGot ID = " + gotID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
        
        String apiTested = "setCurrentID(String id) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setCurrentID " 
        + "with a invalid id" 
        + "\nExpected Result : BadIDException shd be thrown." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+ "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            String id = "merge.intro";
            jhelpContentViewer.setCurrentID(id);
            HelpModel model = jhelpContentViewer.getModel();
            ID gotMapID = model.getCurrentID();
            String gotID = gotMapID.id;
            return Status.failed(apiTested + "Did not get BadIDException : ");
        } catch(BadIDException bie) {
            return Status.passed(apiTested +"Got BadIDException : "+bie+"\n");
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

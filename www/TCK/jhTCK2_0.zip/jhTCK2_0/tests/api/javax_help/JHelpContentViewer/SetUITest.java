/*
 * @(#)SetUITest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *  
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.JHelpContentViewer;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.JHelpContentViewer;
import javax.help.plaf.HelpContentViewerUI;
import javax.help.plaf.basic.BasicContentViewerUI;
import javax.help.HelpSet;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpContentViewer
 *
 * @author Meena C
 */

public class SetUITest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetUITest() {
        
    }
    
    public static void main(String argv[]) {
        SetUITest test = new SetUITest();
        Status s = test.run(argv, new PrintWriter(System.out),
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "setUI(HelpContentViewerUI ui) : " 
        + "\nTestCase : Construct JHelpContentViewer and call setUI with " 
        + "valid ui" 
        + "\nExpected Result : Shd set the given ui." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            BasicContentViewerUI basicUI =
                    new BasicContentViewerUI(jhelpContentViewer);
            jhelpContentViewer.setUI(basicUI);
            HelpContentViewerUI gotUI = jhelpContentViewer.getUI();
            if(gotUI.equals(basicUI)) {
                return Status.passed(apiTested + "Got HelpContentViewerUI." 
                    + "\nGiven UI = " + basicUI + " , Got UI = " + gotUI +"\n");
            } else {
                return Status.failed(apiTested+"Did not get HelpContentViewerUI" 
                    + "\nGiven UI = " + basicUI + " , Got UI = " + gotUI +"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "setUI(HelpContentViewerUI ui) : " 
        + "\nTestCase :Construct JHelpContentViewer and call setUI with null ui" 
        + "\nExpected Result : Shd set the null ui ." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, hsurl);
            JHelpContentViewer jhelpContentViewer = new JHelpContentViewer(hs);
            BasicContentViewerUI basicUI = null;
            jhelpContentViewer.setUI(basicUI);
            HelpContentViewerUI gotUI = jhelpContentViewer.getUI();
            if(gotUI == basicUI) {
                return Status.passed(apiTested + "Got HelpContentViewerUI. " 
                    + "\nGiven UI = " + basicUI + " , Got UI = " + gotUI +"\n");
            } else {
                return Status.failed(apiTested+"Did not get HelpContentViewerUI" 
                    + "\nGiven UI = " + basicUI + " , Got UI = " + gotUI +"\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

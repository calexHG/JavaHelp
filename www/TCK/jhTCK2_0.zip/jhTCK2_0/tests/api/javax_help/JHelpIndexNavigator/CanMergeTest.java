
/*
* 
* 
* @(#)CanMergeTest.java	1.3 03/07/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpIndexNavigator;

import java.util.*;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.Hashtable;
import javax.help.JHelpIndexNavigator;
import javax.help.HelpSet;
import javax.help.IndexView;
import javax.help.NavigatorView;
import javax.help.DefaultHelpModel;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for method javax.help.JHelpIndexNavigator.canMerge()
 */

public class CanMergeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CanMergeTest() {
        
    }
    
    public static void main(String argv[]) {
        CanMergeTest test = new CanMergeTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method:  canMerge(NavigatorView nView)\n"
        + "Expected Result: This instance of a JHelpNavigator merge its "
        + "data with some other one. \n";
        
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC 
                    + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            Hashtable htab1 = new Hashtable();
            htab1.put("data", "HolidayIndex.xml");
            NavigatorView nview = NavigatorView.create(new HelpSet(), "myView", 
                                  "MySearchViewLabel", Locale.getDefault(), 
                                  "javax.help.IndexView", htab);
            IndexView view = new IndexView(hs, "myView", "myLabel", htab1);
            JHelpIndexNavigator search = new JHelpIndexNavigator(nview);
            if(search.canMerge(view)) {
                search.merge(view);
                return Status.passed(apiTested 
                + "-Ok: this instance of a JHelpNavigator merges its data "
                + "with some other one.");
            } else {
                return Status.failed(apiTested 
                + "-This instance of a JHelpIndexNavigator cannot " 
                + "merge its data with some other one.");
            }
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "Method:  canMerge(null)\n"
        + "Expected Result: This instance of a JHelpNavigator merge its "
        + "data with some other one. \n";
    
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Hashtable htab1 = new Hashtable();
            NavigatorView nview = NavigatorView.create(new HelpSet(), "myView", 
                                  "MyIndexViewLabel", Locale.getDefault(), 
                                  "javax.help.IndexView", htab1);
            JHelpIndexNavigator search = new JHelpIndexNavigator(nview); 
	    if(search.canMerge(null)) {
                return Status.failed(apiTested + "-Failed by returning " 
                + "true for null parameter");
            } else {
                return Status.passed(apiTested + "-Ok: null parameter cannot " 
                + "merge its data with some other one.");
            }
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}

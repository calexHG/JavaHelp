
/*
* 
*
* @(#)JHelpIndexNavigatorTest1.java	1.2 01/08/07 Copyright 1993-1998 Sun Microsystems, Inc., 901 San Antonio Road,
* Palo	Alto, California, 94303, U.S.A.	 All Rights Reserved.
*
* This	software is the	confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").You shall not disclose
* such	Confidential Information and shall use it only in accordance with
* the terms of	the license agreement you entered into with Sun.
*/
package javasoft.sqe.tests.api.javax.help.JHelpIndexNavigator;

import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import java.io.PrintWriter;
import java.awt.Component;
import javax.help.HelpSet;
import javax.help.JHelpIndexNavigator;
import java.util.Locale;
import java.net.URL;

/**
 * 
 * The constructor is 
 * JHelpIndexNavigator(HelpSet hs,String name,String label,URL data)
 *
 */

public class JHelpIndexNavigatorTest1 extends MultiTest {

    public static String HSLOC = System.getProperty("HS_LOC");
       
    public static void main(String argv[]) {
        JHelpIndexNavigatorTest1 test = new JHelpIndexNavigatorTest1();
         Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    /*
    * Invoking	the	constructor
    * JHelpIndexNavigator(HelpSet hs,String name,String label,URL data)
    * using reflection	and	setting	the	factory	of object for
    * testing the creation	of the constructor for various combinations.
    */
    
    public JHelpIndexNavigatorTest1() {
    }

    public Status testCase1() {
     
        String apiTested = "Constructor: JHelpIndexNavigator(HelpSet hs, "
        + "java.lang.String name, java.lang.String label, "
        + "java.net.URL data)"
        + "\nExpected Result:  To return an instance of "
        + "JHelpIndexNavigator \n";        
        
        try {

            ClassLoader loader = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC + "/merge/MasterIndex.xml");
            URL hs_url = new URL("file", null, HSLOC
                       + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            
            String name = "myName";
            String label = "MyLabel";
           
            JHelpIndexNavigator jnav = 
                new JHelpIndexNavigator(hs, name, label, url);
                
            if(jnav instanceof JHelpIndexNavigator) {
                return Status.passed(apiTested 
                + "-Ok: Returns an instance of JHelpIndexNavigator");
            } else {
                return Status.failed(apiTested 
                + "-Does not returns an instance of JHelpIndexNavigator");
            }           
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed("-Exception raised " + ee);
        }
    }

    public Status testCase2() {
        
        String apiTested = "Constructor: JHelpIndexNavigator(null, "
        + "java.lang.String name, java.lang.String label, "
        + "java.net.URL data)"
        + "\nExpected Result:  To throw NullPointerException \n";
            
        try {
            
            ClassLoader loader = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC + "/merge/MasterIndex.xml");
            URL hs_url = new URL("file", null, HSLOC
                       + "/holidays/HolidayHistory.hs");
            HelpSet hs = null;
            
            String name = "myName";
            String label = "MyLabel";
           
            JHelpIndexNavigator jnav = 
                new JHelpIndexNavigator(hs, name, label, url);
                
            if(jnav instanceof JHelpIndexNavigator) {
                return Status.passed(apiTested 
                + "-Ok: Returns an instance of JHelpIndexNavigator");
            } else {
                return Status.failed(apiTested 
                + "-Does not returns an instance of JHelpIndexNavigator");
            }           
        } catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "-Ok: Throws NullPointerException ");
            } else {
                ee.printStackTrace();
                return Status.failed("-Exception raised " + ee);
            }
        }
    }

    public Status testCase3() {
     
        String apiTested = "Constructor: JHelpIndexNavigator(HelpSet hs, "
        + "null, java.lang.String label, java.net.URL data)"
        + "\nExpected Result:  To return an instance of "
        + "JHelpIndexNavigator \n";        
        
        try {

            ClassLoader loader = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC + "/merge/MasterIndex.xml");
            URL hs_url = new URL("file", null, HSLOC
                       + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            
            String name = "";
            String label = "MyLabel";
           
            JHelpIndexNavigator jnav = 
                new JHelpIndexNavigator(hs, name, label, url);
                
            if(jnav instanceof JHelpIndexNavigator) {
                return Status.passed(apiTested 
                + "-Ok: Returns an instance of JHelpIndexNavigator");
            } else {
                return Status.failed(apiTested 
                + "-Does not returns an instance of JHelpIndexNavigator");
            }           
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed("-Exception raised " + ee);
        }
    }    

    public Status testCase4() {
     
        String apiTested = "Constructor: JHelpIndexNavigator(HelpSet hs, "
        + "java.lang.String name, null, java.net.URL data)"
        + "\nExpected Result:  To return an instance of "
        + "JHelpIndexNavigator \n";        
        
        try {

            ClassLoader loader = this.getClass().getClassLoader();
            
            URL url = new URL("file", null, HSLOC + "/merge/MasterIndex.xml");
            URL hs_url = new URL("file", null, HSLOC
                       + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            
            String name = "myName";
            String label = "";
           
            JHelpIndexNavigator jnav = 
                new JHelpIndexNavigator(hs, name, label, url);
                
            if(jnav instanceof JHelpIndexNavigator) {
                return Status.passed(apiTested 
                + "-Ok: Returns an instance of JHelpIndexNavigator");
            } else {
                return Status.failed(apiTested 
                + "-Does not returns an instance of JHelpIndexNavigator");
            }           
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed("-Exception raised " + ee);
        }
    }    

    public Status testCase5() {
     
        String apiTested = "Constructor: JHelpIndexNavigator(HelpSet hs, "
        + "java.lang.String name, java.lang.String label, null"
        + "\nExpected Result:  To throw NullPointerException \n";
        
        try {

            ClassLoader loader = this.getClass().getClassLoader();
            
            URL url = null;
            URL hs_url = new URL("file", null, HSLOC
                       + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            
            String name = "myName";
            String label = "MyLabel";
           
            JHelpIndexNavigator jnav = 
                new JHelpIndexNavigator(hs, name, label, url);
                
            if(jnav instanceof JHelpIndexNavigator) {
                return Status.passed(apiTested 
                + "-Ok: Returns an instance of JHelpIndexNavigator");
            } else {
                return Status.failed(apiTested 
                + "-Does not returns an instance of JHelpIndexNavigator");
            }           
        } catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "-Ok: Throws NullPointerException ");
            } else {
                ee.printStackTrace();
                return Status.failed("-Exception raised " + ee);
            }
        }
    }
}

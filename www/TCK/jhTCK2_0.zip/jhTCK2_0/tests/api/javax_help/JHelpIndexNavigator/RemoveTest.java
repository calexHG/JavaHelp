
/*
* 
* 
* @(#)RemoveTest.java	1.3 03/07/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpIndexNavigator;

import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.Hashtable;
import javax.help.JHelpIndexNavigator;
import javax.help.HelpSet;
import javax.help.IndexView;
import javax.help.NavigatorView;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for method javax.help.JHelpIndexNavigator.remove()
 */

public class RemoveTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public RemoveTest() {
        
    }
    
    public static void main(String argv[]) {
        RemoveTest test = new RemoveTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "Method: remove(NavigatorView nView)\n"
        + "Expected Result: To remove some NavigatorView into "
        + "this instance \n";
        
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Hashtable htab1 = new Hashtable();
            NavigatorView nview = NavigatorView.create(new HelpSet(), "myView", 
                                  "MyIndexViewLabel", Locale.getDefault(), 
                                  "javax.help.IndexView", htab1);
            IndexView view = new IndexView(hs, "myView", "myLabel", htab1);
            JHelpIndexNavigator index = new JHelpIndexNavigator(nview);
            htab1.put("data", "HolidayIndex.xml");
            if(index.canMerge(view)) {
                index.merge(view);
                index.remove(view);
                return Status.passed(apiTested 
                + "-Ok: Removes some NavigatorView into this instance");
            } else {
                return Status.failed(apiTested + "-This instance of a " 
                + "JHelpNavigator cannot merge its data with some " 
                + "other one.");
            }
        } catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "-Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "Method: remove(null)\n"
        + "Expected Result: To throw NullPointerException \n";
       
        try {
            
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Hashtable htab1 = new Hashtable();
            NavigatorView nview = NavigatorView.create(new HelpSet(), "myView", 
                                  "MyIndexViewLabel", Locale.getDefault(), 
                                  "javax.help.IndexView", htab1);
            JHelpIndexNavigator index = new JHelpIndexNavigator(nview);
            NavigatorView reView = null;
            index.remove(reView);
            return Status.failed(apiTested + "-Ok: null parameter is " 
            + "accepting to remove.");
        } catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + "-Exception raised for null " 
                + "parameter " + ee);
            } else {
                return Status.failed(apiTested + "-Exception raised: " + ee);
            }
        }
    }
}


/*
* 
* 
* @(#)JHelpNavigatorTest.java	1.3 99/03/03 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpNavigator;

import javax.help.JHelpNavigator;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.NavigatorView;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpNavigator
 
 * @author Ben John.
 */

public class JHelpNavigatorTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public JHelpNavigatorTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        JHelpNavigatorTest test = new JHelpNavigatorTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" JHelpNavigator(NavigatorView view,"
                           + " HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, 
            new DefaultHelpModel(nav.getHelpSet()));
            if((jhn instanceof JHelpNavigator) && (jhn.getNavigatorView() == nav) 
            && (jhn.getNavigatorName() == "myview")) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid JHelpNavigator object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" JHelpNavigator(NavigatorView view,"
                           + " HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, null);
            if((jhn instanceof JHelpNavigator)
				&& (jhn.getModel()==null)) {
                return Status.passed(apiTested + "Okay for null model");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid JHelpNavigator object for null model");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for null model. "
             + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \" JHelpNavigator(NavigatorView view,"
                            + " HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = null;
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, null);
            if(jhn instanceof JHelpNavigator) {
                return Status.passed(apiTested + "Okay for null NavigatorView");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid "
                + " JHelpNavigator object for null NavigatorView");
            }
        }
        catch(Exception ee) {
        	ee.printStackTrace();
            return Status.failed(apiTested 
            + "Exception raised for null NavigatorView " + ee);
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method \" JHelpNavigator(NavigatorView view) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav);
            if(jhn instanceof JHelpNavigator) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid "
                + " JHelpNavigator object ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase5() {
        String apiTested = "Method \" JHelpNavigator(NavigatorView view) \" ";
        try {
            JHelpNavigator jhNavi = new JHelpNavigator(null);
            if(jhNavi instanceof JHelpNavigator) {
                return Status.passed(apiTested 
                + "Creating JHelpNavigator object for null NavigatorView");
            }
            else {
                return Status.failed (apiTested + "Did not Construct valid "
                + " JHelpNavigator object for null NavigatorView object ");
            }
        }
        catch(Exception ee) {
            return Status.failed (apiTested + "Exception raised: " + ee 
            + " for null NavigatorView ");
        }
    }
}

/*
* 
* 
* @(#)SetModelTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpNavigator;

import com.sun.help.jck.harness.JHelpModelListener;
import javax.help.JHelpNavigator;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.HelpModel;
import javax.help.plaf.basic.BasicTOCNavigatorUI;
import javax.help.NavigatorView;
import javax.help.JHelpTOCNavigator;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.help.Map;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpNavigator
 
 * @author Ben John.
 */

public class SetModelTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetModelTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        SetModelTest test = new SetModelTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" setModel() \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, 
            new DefaultHelpModel(nav.getHelpSet()));
            jhn.setModel(new DefaultHelpModel(hs));
            if(jhn.getModel() instanceof HelpModel) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid value");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" setModel() \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
            Locale.getDefault(), "javax.help.TOCView", htab);
            UIDefaults table = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults =  {
                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
            };
            table.putDefaults(uiDefaults);
            JHelpNavigator jhn = new JHelpNavigator(nav, 
            new DefaultHelpModel(nav.getHelpSet()));
            DefaultHelpModel ds = (DefaultHelpModel)jhn.getModel();
            jhn.setModel(jhn.getModel());
            DefaultHelpModel ch = (DefaultHelpModel)jhn.getModel();
            if(ds == ch) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid value");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
	
	public Status testCase3() {
	        String apiTested = "Method \" setModel() \" ";
	        HelpSet hs = null;
	        try {
	            ClassLoader loader = this.getClass().getClassLoader();
	            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
	            hs = new HelpSet(loader, url);
	            Hashtable htab = new Hashtable();
	            htab.put("data", "HolidayTOC.xml");
	            NavigatorView nav = NavigatorView.create(hs, "myview", "mylabel", 
	            Locale.getDefault(), "javax.help.TOCView", htab);
	            UIDefaults table = UIManager.getLookAndFeelDefaults();
	            Object[] uiDefaults =  {
	                "HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"
	            };
	            table.putDefaults(uiDefaults);
	            JHelpNavigator jhn = new JHelpNavigator(nav, 
	            new DefaultHelpModel(nav.getHelpSet()));
	            DefaultHelpModel ds = (DefaultHelpModel)jhn.getModel();
	            jhn.setModel(null);
	            if(jhn.getModel()==null) {
	                return Status.passed(apiTested + "Okay for null parameter");
	            }
	            else {
	                return Status.failed(apiTested + "Didn't return valid value");
	            }
	        }
	        catch(Exception ee) {
	            return Status.failed(apiTested + "Exception raised: " + ee);
	        }
	    }
}

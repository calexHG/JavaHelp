/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... JHelpNavigator(view).setSelectedItems(selectedItems) --> JHelpNavigator(view).setSelectedItems(selectedItems)
 * testCase2 ... JHelpNavigator(view).setSelectedItems(selectedItems) --> JHelpNavigator(view).setSelectedItems(null)
 *
 * testCase3 ... JHelpNavigator(view, model).setSelectedItems(selectedItems) --> JHelpNavigator(view, model).setSelectedItems(selectedItems)
 * testCase4 ... JHelpNavigator(view, model).setSelectedItems(selectedItems) --> JHelpNavigator(view, model).setSelectedItems(null)
 */

package javasoft.sqe.tests.api.javax.help.JHelpNavigator;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.help.HelpSet;
import javax.help.TreeItem;
import javax.help.NavigatorView;
import javax.help.JHelpNavigator;
import javax.help.DefaultHelpModel;

import javax.swing.UIDefaults;
import javax.swing.UIManager;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpNavigator ... setSelectedItems(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetSelectedItemsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetSelectedItemsTest() {
    }

    public static void main(String argv[]) {
        SetSelectedItemsTest test = new SetSelectedItemsTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>setSelectedItems(javax.help.TreeItem[] selectedItems)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>selectedItems</code> valid value
     */
    public Status testCase1() {
        String apiTested = "setSelectedItems(javax.help.TreeItem[] selectedItems): "
            + "TestCase: '(new JHelpNavigator(view)).setSelectedItems(selectedItems)' "
            + "ExpectedResult: Set 'selectedItems' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView view = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(view, new DefaultHelpModel(view.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //set TreeItem[] object ... start
            TreeItem[] treeItems = new TreeItem[] {new TreeItem("first"), new TreeItem("second")};
            //set TreeItem[] object ... end

            //set treeItems ... start
            jhnavigator.setSelectedItems(treeItems);
            //set treeItems ... end

            boolean check = true;
            TreeItem[] tmpTreeItems = jhnavigator.getSelectedItems();

            if (tmpTreeItems.length != treeItems.length) {
                check = false;
            }

            for (int i = 0 ; check && (i < treeItems.length) ; i++) {
                if ( !treeItems[i].equals(tmpTreeItems[i]) ) {
                    check = false;
                }
            }

            if(check) {
                return Status.passed(apiTested + "Set 'selectedItems'");
            } else {
                return Status.failed(apiTested + "Did not set 'selectedItems': " + jhnavigator.getSelectedItems() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSelectedItems(javax.help.TreeItem[] selectedItems)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>selectedItems</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "setSelectedItems(javax.help.TreeItem[] selectedItems): "
            + "TestCase: '(new JHelpNavigator(view)).setSelectedItems(null)' "
            + "ExpectedResult: Set 'null' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView view = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(view, new DefaultHelpModel(view.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //set TreeItem[] object ... start
            TreeItem[] treeItems = null;
            //set TreeItem[] object ... end

            //set treeItems ... start
            jhnavigator.setSelectedItems(treeItems);
            //set treeItems ... end

            TreeItem[] tmpTreeItems = jhnavigator.getSelectedItems();

            if(tmpTreeItems.length == 0) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + jhnavigator.getSelectedItems() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSelectedItems(javax.help.TreeItem[] selectedItems)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>selectedItems</code> valid value
     */
    public Status testCase3() {
        String apiTested = "setSelectedItems(javax.help.TreeItem[] selectedItems): "
            + "TestCase: '(new JHelpNavigator(view, model)).setSelectedItems(selectedItems)' "
            + "ExpectedResult: Set 'selectedItems' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView view = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(view, new DefaultHelpModel(view.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //set TreeItem[] object ... start
            TreeItem[] treeItems = new TreeItem[] {new TreeItem("first"), new TreeItem("second")};
            //set TreeItem[] object ... end

            //set treeItems ... start
            jhnavigator.setSelectedItems(treeItems);
            //set treeItems ... end

            boolean check = true;
            TreeItem[] tmpTreeItems = jhnavigator.getSelectedItems();

            if (tmpTreeItems.length != treeItems.length) {
                check = false;
            }

            for (int i = 0 ; check && (i < treeItems.length) ; i++) {
                if ( !treeItems[i].equals(tmpTreeItems[i]) ) {
                    check = false;
                }
            }

            if(check) {
                return Status.passed(apiTested + "Set 'selectedItems'");
            } else {
                return Status.failed(apiTested + "Did not set 'selectedItems': " + jhnavigator.getSelectedItems() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setSelectedItems(javax.help.TreeItem[] selectedItems)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>selectedItems</code> <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "setSelectedItems(javax.help.TreeItem[] selectedItems): "
            + "TestCase: '(new JHelpNavigator(view, model)).setSelectedItems(null)' "
            + "ExpectedResult: Set 'null' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            // //cretaing JHelpNavigator object ... start
            Hashtable hashtab = new Hashtable();
            hashtab.put("data", "HolidayTOC.xml");

            NavigatorView view = NavigatorView.create(hs, "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtab);

            //initializing UI objects ... start
            UIDefaults table        = UIManager.getLookAndFeelDefaults();
            Object[] uiDefaults     = {"HelpNavigatorUI", "com.sun.help.jck.harness.TestNavigatorUI"};
            table.putDefaults(uiDefaults);
            //initializing UI objects ... end

            JHelpNavigator jhnavigator = new JHelpNavigator(view, new DefaultHelpModel(view.getHelpSet()) );
            // //cretaing JHelpNavigator object ... end

            //set TreeItem[] object ... start
            TreeItem[] treeItems = null;
            //set TreeItem[] object ... end

            //set treeItems ... start
            jhnavigator.setSelectedItems(treeItems);
            //set treeItems ... end

            TreeItem[] tmpTreeItems = jhnavigator.getSelectedItems();

            if(tmpTreeItems.length == 0) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + jhnavigator.getSelectedItems() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

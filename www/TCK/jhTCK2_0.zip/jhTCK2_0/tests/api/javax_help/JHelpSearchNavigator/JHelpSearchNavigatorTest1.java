
/*
* 
*
* @(#)JHelpSearchNavigatorTest1.java	1.2 99/03/01 Copyright 1993-1998 Sun Microsystems, Inc., 901 San Antonio Road,
* Palo	Alto, California, 94303, U.S.A.	 All Rights Reserved.
*
* This	software is the	confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").You shall not disclose
* such	Confidential Information and shall use it only in accordance with
* the terms of	the license agreement you entered into with Sun.
*/
package javasoft.sqe.tests.api.javax.help.JHelpSearchNavigator;

import java.lang.reflect.Constructor;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.apitest.AssertionTest;
import javasoft.sqe.javatest.lib.apitest.ImmutableObjectFactory;
import javasoft.sqe.javatest.lib.apitest.Factory;
import java.io.PrintWriter;
import javasoft.sqe.javatest.lib.apitest.AssertionTest.ExceptionSet;
import java.awt.Component;
import javax.help.HelpSet;
import javax.help.JHelpSearchNavigator;
import java.util.Locale;
import java.net.URL;

/**
 * This	test program is	to test	the	functionality of the constructor
 * of the class	javax.help.JHelpSearchNavigator	using AssertionTest
 * frame work.
 * The constructor is 
 * JHelpSearchNavigator(HelpSet hs,String name,String label,URL data)
 *
 */

public class JHelpSearchNavigatorTest1 extends AssertionTest {
    private static PrintWriter log;
    private static PrintWriter ref;
    Factory[] factory;
    public static String HSLOC = System.getProperty("HS_LOC");
    HelpSet hs = null;
    Constructor constructor;
    URL toc_url = null;
    URL hs_url = null;
    
    public static void main(String args[]) {
        JHelpSearchNavigatorTest1 con = new JHelpSearchNavigatorTest1();
        log = new PrintWriter(System.err);
        ref = new PrintWriter(System.out);
        Status testStatus = null;
        try {
            testStatus = con.run(args, log, ref);
        }
        catch(Exception e) {
            log.println("A major error occured :" + e);
            e.printStackTrace();
        }
        testStatus.exit();
    }
    
    /*
    * Invoking	the	constructor
    * JHelpSearchNavigator(HelpSet	hs,String name,String label,URL	data)
    * using reflection	and	setting	the	factory	of object for
    * testing the creation	of the constructor for various combinations.
    */
    
    public JHelpSearchNavigatorTest1() {
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            toc_url = new URL("file", null, HSLOC 
            + "/holidays/HolidayHistory.hs/HolidayTOC.xml");
            hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, hs_url);
            constructor = JHelpSearchNavigator.class.getConstructor(new Class[] {
                HelpSet.class, String.class, String.class, URL.class
            });
            setConstructorUnderTest(constructor);
        }
        catch(Exception e) {
            
            e.printStackTrace();
        }
        
        /**
         * The factory array is	of length 5. For a constructor test
         * the first entry is always null. The next	4 entries correspond
         * to the 4	arguments in the constructor.
         */
        setDataFactories(factory = new Factory[] {
            ImmutableObjectFactory.createObjectFactory(new Object[] {
                null
            }), ImmutableObjectFactory.createObjectFactory(new HelpSet[] {
                hs, null
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MyJHelpSearchNavigator", null
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MySearchLabel", null
            }), ImmutableObjectFactory.createObjectFactory(new URL[] {
                toc_url, null
            })
        });
    }
    
    public ExceptionSet predictExceptionSet(Object[] param) {
        ExceptionSet set = new ExceptionSet();
        if((getExecutionParameter(0) == null) || (getExecutionParameter(1) == null) 
        || (getExecutionParameter(2) == null) || (getExecutionParameter(3) == null)) {
            ExpectedException e2 = new ExpectedException(NullPointerException.class,
             "Caught	Exception") {
                
                protected void exceptionPostCondition() throws Fault {
                    hardAssert(true, "NullPointerException");
                }
            };
            set.addException(e2);
        }
        return set;
    }
    
    public void normalPostCondition() throws Fault {
        JHelpSearchNavigator sview = (JHelpSearchNavigator)getResult();
        if(sview instanceof JHelpSearchNavigator) {
            hardAssert(true, "Okay");
        }
    }
}

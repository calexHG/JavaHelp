
/*
* 
* 
* @(#)JHelpSearchNavigatorTest2.java	1.5 03/07/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpSearchNavigator;

import java.util.*;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.Hashtable;
import javax.help.JHelpSearchNavigator;
import javax.help.HelpSet;
import javax.help.SearchView;
import javax.help.NavigatorView;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 *  javax.help.JHelpSearchNavigator.JHelpSearchNavigator(NavigatorView nView)
 */

public class JHelpSearchNavigatorTest2 extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public JHelpSearchNavigatorTest2() {
        
    }
    
    public static void main(String argv[]) {
        JHelpSearchNavigatorTest2 test = new JHelpSearchNavigatorTest2();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Constructor: "
	+ "JHelpSearchNavigator(NavigatorView view) \n"
        + "Expected Result: To create an instance of JHelpSearchNavigator\n";

        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
	    htab.put("data", "JavaHelpSearch");
            NavigatorView nview = NavigatorView.create(hs, "myView", 
                                  "MySearchViewLabel", Locale.getDefault(), 
                                  "javax.help.SearchView", htab);
            
            JHelpSearchNavigator search = new JHelpSearchNavigator(nview);
            if(search instanceof JHelpSearchNavigator) {
                return Status.passed(apiTested + "Okay!");
            }
            else {
                return Status.failed(apiTested +" Instance could'nt be created" );
            }
        } 
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Constructor:  JHelpSearchNavigator(null) \n"
        + "Expected Result: To create an instance of JHelpSearchNavigator\n";
                 
	HelpSet hs = null;
        try {
            JHelpSearchNavigator jhn = new JHelpSearchNavigator(null);
            if(jhn instanceof JHelpSearchNavigator) {
                return Status.passed (apiTested + "Okay: creating an instance of JHelpSearchNavigator");
            }
            else {
                return Status.failed(apiTested + " Not creating Object for null"
                + " JHelpSearchNavigator");
            }
        } 
        catch(Exception ee) {
	    ee.printStackTrace();
            return Status.failed(apiTested + "throws " + ee + " for null value.");
        }
    }
}

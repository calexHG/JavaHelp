/*
* 
* 
* @(#)MergeTest.java	1.7 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/


package javasoft.sqe.tests.api.javax.help.JHelpSearchNavigator;

import java.util.*;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.Hashtable;
import javax.help.JHelpSearchNavigator;
import javax.help.HelpSet;
import javax.help.SearchView;
import javax.help.NavigatorView;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for method javax.help.JHelpSearchNavigator.merge()
 */

public class MergeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public MergeTest() {
        
    }
    
    public static void main(String argv[]) {
        MergeTest test = new MergeTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method:  merge(NavigatorView nView)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs2 = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "MasterSearchIndex");
            Hashtable htab1 = new Hashtable();
            htab1.put("data", "JavaHelpSearch");
            SearchView view = new SearchView(hs, "myView", "myLabel", 
                                                   htab);
            SearchView nview = new SearchView(hs2, "myView",
                                 "MySearchViewLabel", htab1);
            JHelpSearchNavigator search = new JHelpSearchNavigator(nview);
            search.merge(view);
            if(search.canMerge(view)) {
                return Status.passed (apiTested + " passed. This instance of a "
                + " JHelpSearchNavigator can merge its data with some other one");
            }
            else {
                return Status.failed (apiTested + " failed. This instance of a "
                + " JHelpSearchNavigator cannot merge its data with some other one.");
            }
        } 
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed (apiTested + "failed. Exception raised: " + ee);
        }
    }
}

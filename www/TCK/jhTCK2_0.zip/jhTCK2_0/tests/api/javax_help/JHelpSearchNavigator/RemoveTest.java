/*
* 
* 
* @(#)RemoveTest.java	1.8 03/07/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/


package javasoft.sqe.tests.api.javax.help.JHelpSearchNavigator;

import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.*;
import java.net.*;
import javax.help.JHelpSearchNavigator;
import javax.help.HelpSet;
import javax.help.NavigatorView;
import javax.help.*;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpSearchNavigator.remove(NavigatorView nview)
 */

public class RemoveTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public RemoveTest() {
        
    }
    
    public static void main(String argv[]) {
        RemoveTest test = new RemoveTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method: remove(NavigatorView nview)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs2 = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "MasterSearchIndex");
            Hashtable htab1 = new Hashtable();
            htab1.put("data", "JavaHelpSearch");
            SearchView view = new SearchView(hs, "myView", "myLabel", 
                                             htab);
            SearchView nview = new SearchView(hs2, "myView",
                                              "MySearchViewLabel", htab1);
            JHelpSearchNavigator search = new JHelpSearchNavigator(nview);
            search.merge(view);
            search.remove(view);
            return Status.passed(apiTested + " passed. Okay");
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed (apiTested + "failed. raise " + ee);
        }
    } 

    public Status testCase2() {
        String apiTested = "Method: remove(null)\n"
        + "Expected Result: To throw NullPointerException \n";

        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/merge/Master.hs");
            HelpSet hs = new HelpSet(loader, url);
            url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs2 = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "MasterSearchIndex");
            Hashtable htab1 = new Hashtable();
            htab1.put("data", "JavaHelpSearch");
            SearchView view = new SearchView(hs, "myView", "myLabel", 
                                             htab);
            SearchView nview = null;
            JHelpSearchNavigator search = new JHelpSearchNavigator(view);
            search.remove(view);
            return Status.failed(apiTested + "-OK: null parameter is " 
            + "accepting to remove.");
        }
        catch(Exception ee) {
	    if(ee instanceof IllegalArgumentException) {
                return Status.passed(apiTested + "-Exception raised for null " 
                + "parameter " + ee);
            } else {   
		ee.printStackTrace();
                return Status.failed(apiTested + "-Exception raised: " + ee);
	    }
	} 
    }
}

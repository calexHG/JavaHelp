/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... JHelpSearchNavigator(view).setSearchEngine(search) --> JHelpSearchNavigator(view).setSearchEngine(search)
 * testCase2 ... JHelpSearchNavigator(view).setSearchEngine(search) --> JHelpSearchNavigator(view).setSearchEngine(null)
 */

package javasoft.sqe.tests.api.javax.help.JHelpSearchNavigator;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Enumeration;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.NavigatorView;
import javax.help.JHelpSearchNavigator;

import javax.help.search.SearchEngine;
import javax.help.search.MergingSearchEngine;

import com.sun.help.jck.harness.FooSearchEngine;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpSearchNavigator ... setSearchEngine(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetSearchEngineTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetSearchEngineTest() {
    }

    public static void main(String argv[]) {
        SetSearchEngineTest test = new SetSearchEngineTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void setSearchEngine(javax.help.search.SearchEngine search)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>search</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void setSearchEngine(javax.help.search.SearchEngine search): "
            + "TestCase: '(new JHelpSearchNavigator(view)).setSearchEngine(search)' "
            + "ExpectedResult: Set 'search' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
            //create a HelpSet object ... end

            //create a JHelpSearchNavigator object ... start
            JHelpSearchNavigator searchnavigator = new JHelpSearchNavigator(hs, "Search", "Search", new URL("file", null, HSLOC + "/holidays/JavaHelpSearch") );
            //create a JHelpSearchNavigator object ... end

            //createing and setting a SearchEngine ... start
            FooSearchEngine search = new FooSearchEngine();
            searchnavigator.setSearchEngine(search);
            //createing and setting a SearchEngine ... end

            //get SearchEngine form the JHelpSearchNavigator object ... start
            Enumeration enum = ((MergingSearchEngine)searchnavigator.getSearchEngine()).getEngines();
            SearchEngine searchtmp = (SearchEngine)enum.nextElement();
            //get SearchEngine form the JHelpSearchNavigator object ... end


            if(search.equals(searchtmp) ) {
                return Status.passed(apiTested + "Set 'search'");
            } else {
                return Status.failed(apiTested + "Did not set 'search': " + searchnavigator.getSearchEngine() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setSearchEngine(javax.help.search.SearchEngine search)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>search</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "void setSearchEngine(javax.help.search.SearchEngine search): "
            + "TestCase: '(new JHelpSearchNavigator(view)).setSearchEngine(null)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs") );
            //create a HelpSet object ... end

            //create a JHelpSearchNavigator object ... start
            JHelpSearchNavigator searchnavigator = new JHelpSearchNavigator(hs, "Search", "Search", new URL("file", null, HSLOC + "/holidays/JavaHelpSearch") );
            //create a JHelpSearchNavigator object ... end

            //createing and setting a SearchEngine ... start
            SearchEngine search = null;
            searchnavigator.setSearchEngine(search);
            //createing and setting a SearchEngine ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch(IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

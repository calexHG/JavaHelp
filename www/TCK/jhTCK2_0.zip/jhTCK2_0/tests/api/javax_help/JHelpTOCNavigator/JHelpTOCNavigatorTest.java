
/*
* 
* 
* @(#)JHelpTOCNavigatorTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.JHelpTOCNavigator;

import java.io.PrintWriter;
import javax.help.JHelpTOCNavigator;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.NavigatorView;
import javax.help.DefaultHelpModel;
import java.net.URL;
import java.util.Hashtable;
import java.util.Locale;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.JHelpTOCNavigator
 * 
 *
 * @author Ben John.
 */

public class JHelpTOCNavigatorTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public JHelpTOCNavigatorTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        JHelpTOCNavigatorTest test = new JHelpTOCNavigatorTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method: JHelpTOCNavigator(HelpSet hs, " 
                           + "java.lang.String name ,java.lang.String label, " 
                           + "java.net.URL data)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(hs, "Name", 
                                        "LabelName", toc_url);
		    if((tocNavi instanceof JHelpTOCNavigator)
				&& (tocNavi.getNavigatorName()=="Name")){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Got Exception :" + ee);
        }
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Method: JHelpTOCNavigator(HelpSet hs, " 
                            + "java.lang.String name ,java.lang.String label, " 
                            + "java.net.URL data) ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(null, "Name", 
                                        "LabelName", toc_url);
            return Status.failed(apiTested 
				+ "Failed for null HelpSet;Exception not  raised");
         }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested
                + "Got Exception for null HelpSet :" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception for null HelpSet :" + ee);
            }
        }
    } //testCase2 finished
    
    public Status testCase3() {
        String apiTested = "Method: JHelpTOCNavigator(HelpSet hs, "
         + "java.lang.String name ,java.lang.String label, " + "java.net.URL data)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(hs, null, 
                                        "LabelName", toc_url);
            return Status.failed(apiTested 
				+ "Failed for null Name;Exception not  raised");
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Got Exception for null Name :" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception for null Name :" + ee);
            }
        }
    } //testCase3 finished
    
    public Status testCase4() {
        String apiTested = "Method: JHelpTOCNavigator(HelpSet hs, "
         + "java.lang.String name ,java.lang.String label, " + "java.net.URL data)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(hs, "Name", null, 
                                        toc_url);
            return Status.failed(apiTested
				+ "Failed for null Labelname;Exception not  raised");
         }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Got Exception for null Labelname :" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception for null Labelname :" + ee);
            }
        }
    } //testCase4 finished
    
    public Status testCase5() {
        String apiTested = "Method: JHelpTOCNavigator(HelpSet hs, " 
                           + "java.lang.String name ,java.lang.String label, "
                           + "java.net.URL data)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(hs, "Name", 
                                        "LabelName", null);
            return Status.failed(apiTested 
				+ "Failed for null URL;Exception not  raised");
         }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Got Exception for null URL :" + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Got Exception for null URL :" + ee);
            }
        }
    } //testCase5 finished
    
    public Status testCase6() {
        String apiTested = "Method: JHelpTOCNavigator(NavigatorView view)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", htab);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(naViewObj);
            if(tocNavi instanceof JHelpTOCNavigator) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised " + ee);
        }
    } //testCase6 finished
    
    public Status testCase7() {
        String apiTested = "Method: JHelpTOCNavigator(NavigatorView view)";
        try {
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(null);
            if(tocNavi instanceof JHelpTOCNavigator) {
                return Status.passed(apiTested + "Okay for null");
            }
            else {
                return Status.passed(apiTested + "Didn't return valid object " 
                + "for null parameter ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception Raised for null Parameter " + ee);
        }
    } //testCase7 finished
    
    public Status testCase8() {
        String apiTested = "Method: JHelpTOCNavigator(NavigatorView view, "
        + "HelpModel model)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", htab);
            DefaultHelpModel dhModel = new DefaultHelpModel(hs);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(naViewObj, dhModel);
            if(tocNavi instanceof JHelpTOCNavigator) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object");
            }
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception Raised " + ee);
        }
    } //testCase8 finished
    
    public Status testCase9() {
        String apiTested = "Method: JHelpTOCNavigator(NavigatorView view, " 
                           + "HelpModel model)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", htab);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(naViewObj, null);
            if(tocNavi instanceof JHelpTOCNavigator) {
                return Status.passed(apiTested + "Okay for null HelpModel");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object" 
                + " for null HelpMode");
            }
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception Raised for null " 
            + "HelpMode " + ee);
        }
    } //testCase9 finished
    
    public Status testCase10() {
        String apiTested = "Method: JHelpTOCNavigator(NavigatorView view, " 
        + "HelpModel model)";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL toc_url = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            URL hs_url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, hs_url);
            DefaultHelpModel dhModel = new DefaultHelpModel(hs);
            JHelpTOCNavigator tocNavi = new JHelpTOCNavigator(null, null);
            if(tocNavi instanceof JHelpTOCNavigator) {
                return Status.passed(apiTested + "Okay for null,null");
            }
            else {
                return Status.failed(apiTested + "Didn't return valid object" 
                + " for null NavigatorView ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised for null " 
            + "NavigatorView" + ee);
        }
    } //testCase10 finished
}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... Map.ID.create(id, hs).getHelpSet() --> Map.ID.create(id, hs).getHelpSet()
 */

package javasoft.sqe.tests.api.javax.help.MapID;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.Map.ID;
import javax.help.HelpSet;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.Map.ID ... getHelpSet()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetHelpSetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetHelpSetTest() {
    }

    public static void main(String argv[]) {
        GetHelpSetTest test = new GetHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.help.HelpSet getHelpSet()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "javax.help.HelpSet getHelpSet(): "
            + "TestCase: 'Map.ID.create(id, hs).getHelpSet()' "
            + "ExpectedResult: 'id.helpset' "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            //create HelpSet object ... end

            //create an ID object ... start
            ID id = ID.create("hol_intro", hs);
            //create an ID object ... end


            if(hs.equals(id.getHelpSet()) ) {
                return Status.passed(apiTested + "Got 'id.helpset'");
            } else {
                return Status.failed(apiTested + "Did not get 'id.helpset': " + id.getHelpSet() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

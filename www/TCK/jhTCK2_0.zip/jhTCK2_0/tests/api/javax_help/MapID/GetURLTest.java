/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... Map.ID.create(id, hs).getURL() --> Map.ID.create(id, hs).getURL()
 */

package javasoft.sqe.tests.api.javax.help.MapID;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.Map.ID;
import javax.help.HelpSet;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.Map.ID ... getURL()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetURLTest() {
    }

    public static void main(String argv[]) {
        GetURLTest test = new GetURLTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.net.URL getURL()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.net.URL getURL(): "
            + "TestCase: 'Map.ID.create(id, hs).getURL()' "
            + "ExpectedResult: 'id.url' "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            //create HelpSet object ... end

            //create an ID object ... start
            ID id = ID.create("hol_intro", hs);
            //create an ID object ... end

            //create testing URL object ... start
            URL testURL = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            //create testing URL object ... end


            if(id.getURL().toExternalForm().equals(testURL.toExternalForm()) ) {
                return Status.passed(apiTested + "Got 'id.url'");
            } else {
                return Status.failed(apiTested + "Did not get 'id.url': " + id.getURL() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.checkMaster(master) --> MergeHelpUtilities.checkMaster(null)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... checkMaster(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class CheckMasterTest0 extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public CheckMasterTest0() {
    }

    public static void main(String argv[]) {
        CheckMasterTest0 test = new CheckMasterTest0();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void checkMaster(javax.swing.tree.DefaultMutableTreeNode master)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> <code>null</code> value
     */
    public Status testCase1() {
        String apiTested = "void checkMaster(javax.swing.tree.DefaultMutableTreeNode master): "
            + "TestCase: 'MergeHelpUtilities.checkMaster(null)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //checkMaster master ... start
            MergeHelpUtilities.checkMaster(null);
            //checkMaster master ... end


            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

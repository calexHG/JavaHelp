/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.getChildWithName(parent, name) --> MergeHelpUtilities.getChildWithName(parent, name)
 * testCase2 ... MergeHelpUtilities.getChildWithName(parent, name) --> MergeHelpUtilities.getChildWithName(parent, invalid)
 * testCase3 ... MergeHelpUtilities.getChildWithName(parent, name) --> MergeHelpUtilities.getChildWithName(parent, "")
 * testCase4 ... MergeHelpUtilities.getChildWithName(parent, name) --> MergeHelpUtilities.getChildWithName(parent, null)
 * testCase5 ... MergeHelpUtilities.getChildWithName(parent, name) --> MergeHelpUtilities.getChildWithName(null, name)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... getChildWithName(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetChildWithNameTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetChildWithNameTest() {
    }

    public static void main(String argv[]) {
        GetChildWithNameTest test = new GetChildWithNameTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>parent</code> valid value
     * @param <code>name</code>   valid value
     */
    public Status testCase1() {
        String apiTested = "javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name): "
            + "TestCase: 'MergeHelpUtilities.getChildWithName(parent, name)' "
            + "ExpectedResult: 'node' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //set node name ... start
            String name = new String("Arctic Wolf");
            //set node name ... end

            //get node with name ... start
            DefaultMutableTreeNode node = MergeHelpUtilities.getChildWithName((DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1).getChildAt(10), name);
            //get node with name ... end

            //get node from the tree ... start
            DefaultMutableTreeNode nodeTree = (DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1).getChildAt(10).getChildAt(1);
            //get node from the tree ... end


            if(node.equals(nodeTree) ) {
                return Status.passed(apiTested + "Got 'node'");
            } else {
                return Status.failed(apiTested + "Did not get 'node': " + MergeHelpUtilities.getChildWithName(parent, name) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>parent</code> valid value
     * @param <code>name</code>   invalid value
     */
    public Status testCase2() {
        String apiTested = "javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name): "
            + "TestCase: 'MergeHelpUtilities.getChildWithName(parent, invalid)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //set node name ... start
            String name = new String("invalid value");
            //set node name ... end

            //get node with name ... start
            DefaultMutableTreeNode node = MergeHelpUtilities.getChildWithName(parent, name);
            //get node with name ... end


            if(node == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + MergeHelpUtilities.getChildWithName(parent, name) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>parent</code> valid value
     * @param <code>name</code>   "" value
     */
    public Status testCase3() {
        String apiTested = "javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name): "
            + "TestCase: 'MergeHelpUtilities.getChildWithName(parent, \"\")' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //set node name ... start
            String name = new String("");
            //set node name ... end

            //get node with name ... start
            DefaultMutableTreeNode node = MergeHelpUtilities.getChildWithName(parent, name);
            //get node with name ... end


            if(node == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + MergeHelpUtilities.getChildWithName(parent, name) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>parent</code> valid value
     * @param <code>name</code>   <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name): "
            + "TestCase: 'MergeHelpUtilities.getChildWithName(parent, null)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //set node name ... start
            String name = null;
            //set node name ... end

            //get node with name ... start
            DefaultMutableTreeNode node = MergeHelpUtilities.getChildWithName(parent, name);
            //get node with name ... end


            if(node == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + MergeHelpUtilities.getChildWithName(parent, name) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

    /**
     * Method test: <code>javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>parent</code> <code>null</code> value
     * @param <code>name</code>   valid value
     */
    public Status testCase5() {
        String apiTested = "javax.swing.tree.DefaultMutableTreeNode getChildWithName(javax.swing.tree.DefaultMutableTreeNode parent, java.lang.String name): "
            + "TestCase: 'MergeHelpUtilities.getChildWithName(null, name)' "
            + "ExpectedResult: NullPointerException "
            + "ObtainedResult: ";

        try {
            //set root node ... start
            DefaultMutableTreeNode parent = null;
            //set root node ... end

            //set node name ... start
            String name = new String("test");
            //set node name ... end

            //get node with name ... start
            DefaultMutableTreeNode node = MergeHelpUtilities.getChildWithName(parent, name);
            //get node with name ... end


	    return Status.failed(apiTested + "Did not get NullPointerException: " + MergeHelpUtilities.getChildWithName(parent, name) );
	    
	} catch (NullPointerException npe) {
                return Status.passed(apiTested + "Got NullPointerException");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

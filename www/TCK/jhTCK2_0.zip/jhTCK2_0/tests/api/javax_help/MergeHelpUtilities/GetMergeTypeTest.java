/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.getMergeType(node) --> MergeHelpUtilities.getMergeType(node)
 * testCase2 ... MergeHelpUtilities.getMergeType(node) --> MergeHelpUtilities.getMergeType(node)
 * testCase3 ... MergeHelpUtilities.getMergeType(node) --> MergeHelpUtilities.getMergeType(null)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... getMergeType(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetMergeTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetMergeTypeTest() {
    }

    public static void main(String argv[]) {
        GetMergeTypeTest test = new GetMergeTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase1() {
        String apiTested = "java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.getMergeType(node)' "
            + "ExpectedResult: 'mergeType' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //get node with merge type ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1);
            //get node with merge type ... end

            //set expected merge type ... start
            String expected = new String("javax.help.SortMerge");
            //set expected merge type ... end


            if((MergeHelpUtilities.getMergeType(node)).equals(expected) ) {
                return Status.passed(apiTested + "Got 'mergeType'");
            } else {
                return Status.failed(apiTested + "Did not get 'mergeType': " + MergeHelpUtilities.getMergeType(node) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase2() {
        String apiTested = "java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.getMergeType(node)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //get node without merge type ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1).getChildAt(10).getChildAt(1);
            //get node without merge type ... end

            //set expected merge type ... start
            String expected = null;
            //set expected merge type ... end


            if(MergeHelpUtilities.getMergeType(node) == expected) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + MergeHelpUtilities.getMergeType(node) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "java.lang.String getMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.getMergeType(null)' "
            + "ExpectedResult: NullPointerException "
            + "ObtainedResult: ";

        try {
            //get node without merge type and with parent with merge type ... start
            DefaultMutableTreeNode node = null;
            //get node without merge type and with parent with merge type ... end

            //set merge type ... start
            MergeHelpUtilities.getMergeType(node);
            //set merge type ... end

	    return Status.failed(apiTested + "Did not get 'mergeType': " );

	} catch (NullPointerException npe) {
	    return Status.passed(apiTested + "Got NullPointerExeception'");

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(master, slave)
 * testCase2 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(master, slave)
 * testCase3 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(master, slave)
 * testCase4 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(master, slave)
 * testCase5 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(master, null)
 * testCase6 ... MergeHelpUtilities.haveEqualName(master, slave) --> MergeHelpUtilities.haveEqualName(null, slave)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... haveEqualName(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class HaveEqualNameTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public HaveEqualNameTest() {
    }

    public static void main(String argv[]) {
        HaveEqualNameTest test = new HaveEqualNameTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  valid value
     */
    public Status testCase1() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(master, slave)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet objects ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet objects ... end

            //get TOCView objects form the HelpSet objects ... start
            TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
            TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
            //get TOCView objects form the HelpSet objects ... end

            //get root nodes from the TOCs ... start
            DefaultMutableTreeNode master = tocviewmaster.getDataAsTree();
            DefaultMutableTreeNode slave  = tocviewslave.getDataAsTree();
            //get root nodes from the TOCs ... end


            if(MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), (DefaultMutableTreeNode)slave.getFirstChild()) ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), (DefaultMutableTreeNode)slave.getFirstChild()) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  valid value
     */
    public Status testCase2() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(master, slave)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet objects ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
            //create a HelpSet objects ... end

            //get TOCView objects form the HelpSet objects ... start
            TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
            TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
            //get TOCView objects form the HelpSet objects ... end

            //get root nodes from the TOCs ... start
            DefaultMutableTreeNode master = tocviewmaster.getDataAsTree();
            DefaultMutableTreeNode slave  = tocviewslave.getDataAsTree();
            //get root nodes from the TOCs ... end


            if(MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), (DefaultMutableTreeNode)slave.getFirstChild()) ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), (DefaultMutableTreeNode)slave.getFirstChild()) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  valid value
     */
    public Status testCase3() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(master, slave)' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode node = tocview.getDataAsTree();
            //get root node from the TOC ... end


            if(MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)node.getFirstChild().getChildAt(0), (DefaultMutableTreeNode)node.getFirstChild()) ) {
                return Status.failed(apiTested + "Did not get 'false': " + MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)node.getFirstChild().getChildAt(0), (DefaultMutableTreeNode)node.getFirstChild()) );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  valid value
     */
    public Status testCase4() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(master, slave)' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet objects ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
            //create a HelpSet objects ... end

            //get TOCView objects form the HelpSet objects ... start
            TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
            TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
            //get TOCView objects form the HelpSet objects ... end

            //get root nodes from the TOCs ... start
            DefaultMutableTreeNode master = tocviewmaster.getDataAsTree();
            DefaultMutableTreeNode slave  = tocviewslave.getDataAsTree();
            //get root nodes from the TOCs ... end


            if(MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild().getChildAt(0), (DefaultMutableTreeNode)slave.getFirstChild().getChildAt(0)) ) {
                return Status.failed(apiTested + "Did not get 'false': " + MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild().getChildAt(0), (DefaultMutableTreeNode)slave.getFirstChild().getChildAt(0)) );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> valid value
     * @param <code>slave</code>  <code>null</code> value
     */
    public Status testCase5() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(master, null)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode master = tocviewmaster.getDataAsTree();
            //get root node from the TOC ... end


            if(MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), null) ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + MergeHelpUtilities.haveEqualName((DefaultMutableTreeNode)master.getFirstChild(), null) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>master</code> <code>null</code> value
     * @param <code>slave</code>  valid value
     */
    public Status testCase6() {
        String apiTested = "boolean haveEqualName(javax.swing.tree.DefaultMutableTreeNode master, javax.swing.tree.DefaultMutableTreeNode slave): "
            + "TestCase: 'MergeHelpUtilities.haveEqualName(null, slave)' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet objects ... start
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet objects ... end

            //get TOCView objects form the HelpSet objects ... start
            TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
            //get TOCView objects form the HelpSet objects ... end

            //get root nodes from the TOCs ... start
            DefaultMutableTreeNode slave  = tocviewslave.getDataAsTree();
            //get root nodes from the TOCs ... end


            if(MergeHelpUtilities.haveEqualName(null, (DefaultMutableTreeNode)slave.getFirstChild()) ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + MergeHelpUtilities.haveEqualName(null, (DefaultMutableTreeNode)slave.getFirstChild()) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

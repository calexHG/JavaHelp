/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.remove(node) --> MergeHelpUtilities.remove(node)
 * testCase2 ... MergeHelpUtilities.remove(node) --> MergeHelpUtilities.remove(null)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... remove(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class RemoveTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public RemoveTest() {
    }

    public static void main(String argv[]) {
        RemoveTest test = new RemoveTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void remove(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void remove(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.remove(node)' "
            + "ExpectedResult: Remove 'node' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode node = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //remove first root child ... start
            DefaultMutableTreeNode remove = (DefaultMutableTreeNode)node.getFirstChild().getChildAt(0);
            MergeHelpUtilities.remove(remove);
            //remove first root child ... end


            if(remove.equals((DefaultMutableTreeNode)node.getFirstChild().getChildAt(0)) ) {
                return Status.failed(apiTested + "Did not remove 'node'");
            } else {
                return Status.passed(apiTested + "Removed 'node'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "void remove(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.remove(null)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //remove node ... start
            MergeHelpUtilities.remove(null);
            //remove node ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

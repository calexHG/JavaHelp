/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergeHelpUtilities.setMergeType(node) --> MergeHelpUtilities.setMergeType(node)
 * testCase2 ... MergeHelpUtilities.setMergeType(node) --> MergeHelpUtilities.setMergeType(node)
 * testCase3 ... MergeHelpUtilities.setMergeType(node) --> MergeHelpUtilities.setMergeType(null)
 */

package javasoft.sqe.tests.api.javax.help.MergeHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.MergeHelpUtilities;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.MergeHelpUtilities ... setMergeType(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetMergeTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetMergeTypeTest() {
    }

    public static void main(String argv[]) {
        SetMergeTypeTest test = new SetMergeTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.setMergeType(node)' "
            + "ExpectedResult: Set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //get node without merge type and with parent with merge type ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1).getChildAt(2);
            //get node without merge type and with parent with merge type ... end

            //set merge type ... start
            MergeHelpUtilities.setMergeType(node);
            //set merge type ... end


            if((MergeHelpUtilities.getMergeType(node)).equals(MergeHelpUtilities.getMergeType((DefaultMutableTreeNode)node.getParent())) ) {
                return Status.passed(apiTested + "Set 'mergeType'");
            } else {
                return Status.failed(apiTested + "Did not set 'mergeType': " + MergeHelpUtilities.getMergeType(node) );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase2() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.setMergeType(node)' "
            + "ExpectedResult: Not set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //create a HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create a HelpSet object ... end

            //get TOCView object form the HelpSet object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object form the HelpSet object ... end

            //get root node from the TOC ... start
            DefaultMutableTreeNode parent = tocview.getDataAsTree();
            //get root node from the TOC ... end

            //get node with merge type and with parent with merge type ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent.getChildAt(0).getChildAt(1).getChildAt(10);
            //get node with merge type and with parent with merge type ... end

            //set merge type ... start
            MergeHelpUtilities.setMergeType(node);
            //set merge type ... end


            if((MergeHelpUtilities.getMergeType(node)).equals(MergeHelpUtilities.getMergeType((DefaultMutableTreeNode)node.getParent())) ) {
                return Status.failed(apiTested + "Set 'mergeType': " + MergeHelpUtilities.getMergeType(node) );
            } else {
                return Status.passed(apiTested + "Did not set 'mergeType'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: 'MergeHelpUtilities.setMergeType(null)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //get node without merge type and with parent with merge type ... start
            DefaultMutableTreeNode node = null;
            //get node without merge type and with parent with merge type ... end

            //set merge type ... start
            MergeHelpUtilities.setMergeType(node);
            //set merge type ... end


	    return Status.failed(apiTested + "Did not throw NullPointerException " );

	} catch (NullPointerException npe) {
                return Status.passed(apiTested + "Got NullPointerExeption");	    
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

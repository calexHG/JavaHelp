
/*
* 
* 
* @(#)CreateTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.NavigatorView;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import javax.help.NavigatorView;
import javax.help.InvalidNavigatorViewException;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.NavigatorView
 
 * @author Ben John.
 */

public class CreateTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        CreateTest test = new CreateTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, " 
                           + "java.lang.String label,java.util.Locale locale, " 
                           + "java.lang.String className, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", htab);
            if(naViewObj instanceof NavigatorView 
            && naViewObj.getHelpSet() == hs && naViewObj.getParameters() == htab 
            && naViewObj.getName() == "myView") {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct " 
                + "valid NavigatorView");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, "
                           + "java.lang.String label, java.util.Locale locale, "
                           + "java.lang.String className, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "sampleclass", htab);
            return Status.failed(apiTested + "Construct valid NavigatorView " 
            + "for Invalid Class parameter");
        }
        catch(InvalidNavigatorViewException e) {
            if(e.getHelpSet() == hs) {
                return Status.passed(apiTested 
                + " InvalidNavigatorViewException Raised for Invalid Class Name");
            }
            else {
                return Status.failed(apiTested + "Construct Invalid " 
                + "InvalidNavigatorViewException object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, " 
                           + "java.lang.String label,java.util.Locale locale, "
                           + "java.lang.String className, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(null, "myView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", htab);
            return Status.failed(apiTested + "Construct valid NavigatorView " 
            + "object with null HelpSet");
        }
        catch(InvalidNavigatorViewException e) {
            return Status.passed(apiTested + " InvalidNavigatorViewException " 
            + "Raised for null HelpSet");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for null " 
            + "HelpSet Parameter" + ee);
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, " 
                           + "java.lang.String label,java.util.Locale locale, " 
                           + "java.lang.String className, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, null, "myLabel", 
                                      Locale.getDefault(), "javax.help.TOCView", 
                                      htab);
            return Status.failed(apiTested + "Did not raised Exception");
        }
        catch(InvalidNavigatorViewException e) {
            return Status.passed(apiTested + " InvalidNavigatorViewException " 
            + "Raised for null Name");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for " 
            + "null Name " + ee);
        }
    }
    
    public Status testCase5() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, " 
        + "java.lang.String label, java.util.Locale locale, " 
        + "java.lang.String className, "
        + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "MyView", null, 
                                      Locale.getDefault(), "javax.help.TOCView",
                                      htab);
             return Status.failed(apiTested + "Did not Exception raised" 
                + "with Null Label");
        }
        catch(InvalidNavigatorViewException e) {
            return Status.passed(apiTested + " InvalidNavigatorViewException " 
            + "Raised for null Label");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for " 
            + "null Label " + ee);
        }
    }
    
    public Status testCase6() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name," 
        + "java.lang.String label,java.util.Locale locale, " 
        + "java.lang.String className, " 
        + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "MyView", 
                                     "myLabel", null, "javax.help.TOCView", htab);
            if((naViewObj instanceof NavigatorView) 
            && (naViewObj.getHelpSet() == hs) 
            && (naViewObj.getParameters() == htab)
            && (naViewObj.getName() == "MyView")) {
            return Status.passed(apiTested + "Okay for Null Locale.");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid " 
                + "NavigatorView for null Locale object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase7() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name, " 
        + "java.lang.String label,java.util.Locale locale, " 
        + "java.lang.String className, " 
        + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            NavigatorView naViewObj = NavigatorView.create(hs, "MyView", 
                                      "myLabel", Locale.getDefault(), null, htab);
            return Status.failed(apiTested + "Did not Construct valid " 
            + "NavigatorView for null classname");
        }
        catch(InvalidNavigatorViewException ex) {
            return Status.passed(apiTested + "InvalidNavigatorViewException " 
            + "raised for null class");
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase8() {
        String apiTested = "Method: create(HelpSet hs,java.lang.String name," 
        + " java.lang.String label,java.util.Locale locale, " 
        + "java.lang.String className, " 
        + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            NavigatorView naViewObj = NavigatorView.create(hs, "MyView", 
                                      "myLabel", Locale.getDefault(), 
                                      "javax.help.TOCView", null);
            if((naViewObj instanceof NavigatorView) 
            && (naViewObj.getHelpSet() == hs) 
            && (naViewObj.getParameters() == null) 
            && (naViewObj.getName() == "MyView")) {
                return Status.passed(apiTested + "Okay for Null Hashtable.");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid " 
                + "NavigatorView for null Hashtable");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}


/*
* 
* 
* @(#)NavigatorViewTest.java	1.1 99/03/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.NavigatorView;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.FlatMap;
import javax.help.NavigatorView;
import javax.help.InvalidNavigatorViewException;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import com.sun.help.jck.harness.NavigatorViewHelperTest;

/**
 * Tests for javax.help.NavigatorView
 
 * @author Ben John.
 */

public class NavigatorViewTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public NavigatorViewTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        NavigatorViewTest test = new NavigatorViewTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method: NavigatorView(HelpSet hs,"
			    			+ "String name,"
			    			+ "String label,"
			    			+ "Locale locale,"
			    			+ "Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
			NavigatorViewHelperTest hsTest = new NavigatorViewHelperTest(hs,"myName",
								"myLabel",Locale.getDefault(),htab);
            if(hsTest instanceof NavigatorView 
            && hsTest.getHelpSet() == hs && hsTest.getParameters() == htab 
            && hsTest.getName() == "myName") {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct " 
                + "valid NavigatorView");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
	 public Status testCase2() {
	        String apiTested = "Method: NavigatorView(HelpSet hs,"
				    			+ "String name,"
				    			+ "String label,"
				    			+ "Locale locale,"
				    			+ "Hashtable params)";
	        HelpSet hs = null;
	        try {
	            ClassLoader loader = this.getClass().getClassLoader();
	            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	            hs = new HelpSet(loader, url);
	            Hashtable htab = new Hashtable();
	            htab.put("one", "ValueOne");
	            htab.put("Two", "ValueTwo");
	            htab.put("Three", "ValueThree");
				NavigatorViewHelperTest hsTest = new NavigatorViewHelperTest(null,
						"myName","myLabel",Locale.getDefault(),htab);
	            if(hsTest instanceof NavigatorView 
	            && hsTest.getHelpSet() == null && hsTest.getParameters() == htab 
	            && hsTest.getName() == "myName") {
	                return Status.passed(apiTested + "Okay for null HelpSet");
	            }
	            else {
	                return Status.failed(apiTested + "Did not Construct " 
	                + "valid NavigatorView for null HelpSet");
	            }
	        }
	        catch(Exception ee) {
	            return Status.failed(apiTested + "Exception " 
						+" raised for null HelpSet " + ee);
	        }
	    }
		
	 public Status testCase3() {
	        String apiTested = "Method: NavigatorView(HelpSet hs,"
					    			+ "String name,"
					    			+ "String label,"
					    			+ "Locale locale,"
					    			+ "Hashtable params)";
	        HelpSet hs = null;
	        try {
	            ClassLoader loader = this.getClass().getClassLoader();
	            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	            hs = new HelpSet(loader, url);
	            Hashtable htab = new Hashtable();
	            htab.put("one", "ValueOne");
	            htab.put("Two", "ValueTwo");
	            htab.put("Three", "ValueThree");
				NavigatorViewHelperTest hsTest = new NavigatorViewHelperTest(hs,null,
								"myLabel",Locale.getDefault(),htab);
                return Status.failed(apiTested + "Did not Construct " 
                               + "valid NavigatorView for nul name parameter");
           		} 
	        catch(NullPointerException e2) {
	            return Status.passed(apiTested + "Exception raised for "
						+ "null name parameter " + e2);
	        } 
	        catch(Exception ee) {
	            return Status.failed(apiTested + "Exception raised for "
						+ " null name parameter " + ee);
			        }										
		    }
		    
	    
	 public Status testCase4() {
        String apiTested = "Method: NavigatorView(HelpSet hs,"
			    			+ "String name,"
			    			+ "String label,"
			    			+ "Locale locale,"
			    			+ "Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
			NavigatorViewHelperTest hsTest = new NavigatorViewHelperTest(hs,
					"myName","myLabel",Locale.getDefault(),null);
			    
            if(hsTest instanceof NavigatorView 
		        && hsTest.getHelpSet() == hs && hsTest.getParameters() == null
               && hsTest.getName() == "myName") {
            return Status.passed(apiTested + "Okay for null Hashtable parameter");
           }
	        else {
               return Status.failed(apiTested + "Did not Construct " 
                + "valid NavigatorView for null Hashtable parameter");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for " 
					+ " null Hashtable parameter " + ee);
        }
    }
 public Status testCase5() {
        String apiTested = "Method: NavigatorView(HelpSet hs,"
			    			+ "String name,"
			    			+ "String label,"
			    			+ "Locale locale,"
			    			+ "Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
			NavigatorViewHelperTest hsTest = new NavigatorViewHelperTest(hs,"MyName",
								null,Locale.getDefault(),htab);
            return Status.failed(apiTested + "Did not Construct " 
                     + "valid NavigatorView for null label parameter");
      		} 
        catch(NullPointerException e2) {
            return Status.passed(apiTested + "Exception raised for"
						+ " null label parameter " + e2);
	        } 
		catch(Exception ee) {
	         return Status.failed(apiTested + "Exception raised for "
			 			+ "null label parameter " + ee);
	        }										
    }
		    
}

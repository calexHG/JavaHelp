/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... Presentation(name, displayViews, displayViewImages,size, location, title, toolbar, helpActions).isToolbar() --> Presentation(name, true, true, size, location, title, null, true, helpActions).isToolbar()
 * testCase2 ... Presentation(name, displayViews, displayViewImages, size, location, title, toolbar, helpActions).isToolbar() --> Presentation(name, true, true, size, location, title, null, false, helpActions).isToolbar()
 */

package javasoft.sqe.tests.api.javax.help.Presentation;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Point;
import java.awt.Dimension;

import java.util.Vector;

import javax.help.Map;
import javax.help.HelpSet.Presentation;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.Presentation ... isToolbar()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class IsToolbarTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public IsToolbarTest() {
    }

    public static void main(String argv[]) {
        IsToolbarTest test = new IsToolbarTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>boolean isToolbar()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "boolean isToolbar(): "
            + "TestCase: '(new Presentation(name, true, true, size, location, title, null, true, helpActions)).isToolbar()' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = new String("Presentation name");
            boolean displayViews = true;
            boolean displayViewImages = true;
            Dimension size = new Dimension(100, 100);
            Point location = new Point(50, 50);
            String title = new String("Presentation title");
	    Map.ID imageID = null;
            boolean toolbar = true;
            Vector helpActions = new Vector();
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Presentation presentation = 
		new Presentation(name, displayViews, displayViewImages, 
				 size, location, title, imageID,
				 toolbar, helpActions);
            //create Presentation object from given values ... end


            if(presentation.isToolbar() ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + presentation.isToolbar() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean isToolbar()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "boolean isToolbar(): "
            + "TestCase: '(new Presentation(name, true, true, size, location, title, null, false, helpActions)).isToolbar()' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = new String("Presentation name");
            boolean displayViews = true;
            boolean displayViewImages = true;
            Dimension size = new Dimension(100, 100);
            Point location = new Point(50, 50);
            String title = new String("Presentation title");
	    Map.ID imageID = null;
            boolean toolbar = false;
            Vector helpActions = new Vector();
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Presentation presentation = 
		new Presentation(name, displayViews, displayViewImages,
				 size, location, title, imageID,
				 toolbar, helpActions);
            //create Presentation object from given values ... end


            if(presentation.isToolbar() ) {
                return Status.failed(apiTested + "Did not get 'false': " + presentation.isToolbar() );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

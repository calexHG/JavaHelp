/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... Presentation(name, displayViews, displayViewImages, size, location, title, imageID, toolbar, helpActions) --> Presentation(name, true, true, size, location, title, imageID, true, helpActions)
 * testCase2 ... Presentation(name, displayViews, displayViewImages, size, location, title,imageID, toolbar, helpActions) --> Presentation("", true, true, null, location, null, null,  false, helpActions)
 * testCase3 ... Presentation(name, displayViews, displayViewImages, size, location, title, imageID, toolbar, helpActions) --> Presentation(null, false, true, size, null, "", imageID, true, null)
 * testCase4 ... Presentation(name, displayViews, displayViewImages, size, location, title, imageID, toolbar, helpActions) --> Presentation(null, false, true, null, null, null, null, false, null)
 */

package javasoft.sqe.tests.api.javax.help.Presentation;

import java.io.PrintWriter;

import java.net.URL;

import java.awt.Point;
import java.awt.Dimension;

import java.util.Vector;

import javax.help.Map;
import javax.help.HelpSet;
import javax.help.HelpSet.Presentation;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.HelpSet.Presentation ... Presentation()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class PresentationTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public PresentationTest() {
    }

    public static void main(String argv[]) {
        PresentationTest test = new PresentationTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>Presentation(java.lang.String name, boolean displayViews,  boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, MapID imageID, boolean toolbar, java.util.Vector helpActions)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>         valid value
     * @param <code>displayViews</code> <code>true</code>
     * @param <code>displayViewImages</code> <code>true</code>
     * @param <code>size</code>         valid value
     * @param <code>location</code>     valid value
     * @param <code>title</code>        valid value
     * @param <code>imageID</code>	valid value
     * @param <code>toolbar</code>      <code>true</code>
     * @param <code>helpActions</code>  valid value
     */
    public Status testCase1() {
        String apiTested = "Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, MapID imageID, boolean toolbar, java.util.Vector helpActions): "
            + "TestCase: Construct with: 'name == valid; displayViews == true; displayViewImages == true; size == valid; location == valid; title == valid; imageID == valid; toolbar == true; helpActions == valid' "
            + "ExpectedResult: Presentation object with given values "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = new String("Presentation name");
            boolean displayViews = true;
            boolean displayViewImages = true;
            Dimension size = new Dimension(100, 100);
            Point location = new Point(50, 50);
            String title = new String("Presentation title");
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(null, url);
	    Map.ID imageID = Map.ID.create("toplevelfolder", hs);
            boolean toolbar = true;
            Vector helpActions = new Vector();
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Object presentation = 
		new Presentation(name, displayViews, displayViewImages, size, 
				 location, title, imageID, toolbar, 
				 helpActions);
            //create Presentation object from given values ... end


            if(presentation instanceof Presentation) { //is instance of Presentation class
                if (size.equals(((Presentation)presentation).getSize()) ) { //size value is correct
                    if ( ((Presentation)presentation).isViewDisplayed() ) { //displayViews value is correct
			if ( ((Presentation)presentation).isViewImagesDisplayed() ) { //displayViewImagess value is correct
			    if (imageID.equals(((Presentation)presentation).getImageID()) ) { //imageID value is correct
				if ( ((Presentation)presentation).isToolbar() ) { //toolbar value is correct
				    if (location.equals(((Presentation)presentation).getLocation()) ) { //location value is correct
					return Status.passed(apiTested + "OK");
				    } else { //location value is not correct
					return Status.failed(apiTested + "Did not construct Presentation object with correct 'location' value: original: " + location + " obtained: " + ((Presentation)presentation).getLocation() );
				    }
				} else { //toolbar value is correct
				    return Status.failed(apiTested + "Did not construct Presentation object with correct 'toolbar' value: original: " + toolbar + " obtained: " + ((Presentation)presentation).isToolbar() );
				}
			    } else { //imageID value is not correct
				return Status.failed(apiTested + "Did not construct Presentation object with correct 'imageID' value: original: " + imageID + " obtained: " + ((Presentation)presentation).getImageID() );
			    }
			} else { //displayViewImages value is not correct
			    return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViewImages' value: original: " + displayViewImages + " obtained: " + ((Presentation)presentation).isViewImagesDisplayed() );
			}
		    } else { //displayViews value is not correct
			return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViews' value: original: " + displayViews + " obtained: " + ((Presentation)presentation).isViewDisplayed() );
		    }
                } else { //size value is not correct
                    return Status.failed(apiTested + "Did not construct Presentation object with correct 'size' value: original: " + size + " obtained: " + ((Presentation)presentation).getSize() );
                }
            } else { //is not instance of Presentation class
                return Status.failed(apiTested + "Did not construct Presentation object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, Map.ID imageID, boolean toolbar, java.util.Vector helpActions)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>         "" value
     * @param <code>displayViews</code> <code>true</code>
     * @param <code>displayViewImages</code> <code>true</code>
     * @param <code>size</code>         <code>null</code> value
     * @param <code>location</code>     valid value
     * @param <code>title</code>        <code>null</code> value
     * @param <code>imageID</code>	<code>null</code> value
     * @param <code>toolbar</code>      <code>false</code>
     * @param <code>helpActions</code>  valid value
     */
    public Status testCase2() {
        String apiTested = "Presentation(java.lang.String name, boolean displayViews, java.awt.Dimension size, java.awt.Point location, java.lang.String title, Map.ID imageID, boolean toolbar, java.util.Vector helpActions): "
            + "TestCase: Construct with: 'name == \"\"; displayViews == true; displayViewImages == true; size == null; location == valid; title == null; imageID == null; toolbar == false; helpActions == valid' "
            + "ExpectedResult: Presentation object with given values "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = new String("");
            boolean displayViews = true;
            boolean displayViewImages = false;
            Dimension size = null;
            Point location = new Point(50, 50);
            String title = null;
	    Map.ID imageID = null;
            boolean toolbar = false;
            Vector helpActions = new Vector();
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Object presentation = 
		new Presentation(name, displayViews, displayViewImages, size, 
				 location, title, imageID, toolbar, 
				 helpActions);
            //create Presentation object from given values ... end


            if(presentation instanceof Presentation) { //is instance of Presentation class
                if (size == ((Presentation)presentation).getSize() ) { //size value is correct
                    if ( ((Presentation)presentation).isViewDisplayed() ) { //displayViews value is correct
			if ( !((Presentation)presentation).isViewImagesDisplayed() ) { //displayViewImages value is correct
			    if ((((Presentation)presentation).getImageID())== null ) { //imageID value is correct
				if ( !((Presentation)presentation).isToolbar() ) { //toolbar value is correct
				    if (location.equals(((Presentation)presentation).getLocation()) ) { //location value is correct
					return Status.passed(apiTested + "OK");
				    } else { //location value is not correct
					return Status.failed(apiTested + "Did not construct Presentation object with correct 'location' value: original: " + location + " obtained: " + ((Presentation)presentation).getLocation() );
				    }
				} else { //toolbar value is correct
				    return Status.failed(apiTested + "Did not construct Presentation object with correct 'toolbar' value: original: " + toolbar + " obtained: " + ((Presentation)presentation).isToolbar() );
				}
			    } else { //imageID value is not correct
				return Status.failed(apiTested + "Did not construct Presentation object with correct 'imageID' value: original: " + imageID + " obtained: " + ((Presentation)presentation).getImageID() );
			    }
			} else { //displayViewImages value is not correct
			    return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViewImages' value: original: " + displayViewImages + " obtained: " + ((Presentation)presentation).isViewImagesDisplayed() );
			}
                    } else { //displayViews value is not correct
                        return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViews' value: original: " + displayViews + " obtained: " + ((Presentation)presentation).isViewDisplayed() );
                    }
                } else { //size value is not correct
                    return Status.failed(apiTested + "Did not construct Presentation object with correct 'size' value: original: " + size + " obtained: " + ((Presentation)presentation).getSize() );
                }
            } else { //is not instance of Presentation class
                return Status.failed(apiTested + "Did not construct Presentation object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, Map.ID imageID, boolean toolbar, java.util.Vector helpActions)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>         <code>null</code> value
     * @param <code>displayViews</code> <code>false</code>
     * @param <code>displayViewImages</code> <code>false</code>
     * @param <code>size</code>         valid value
     * @param <code>location</code>     <code>null</code> value
     * @param <code>title</code>        "" value
     * @param <code>imageID</code>	valid value
     * @param <code>toolbar</code>      <code>true</code>
     * @param <code>helpActions</code>  <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, boolean toolbar, java.util.Vector helpActions): "
            + "TestCase: Construct with: 'name == null; displayViews == false; displayViewImages == false; size == valid; location == null; title == \"\"; toolbar == true; helpActions == null' "
            + "ExpectedResult: Presentation object with given values "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = null;
            boolean displayViews = false;
            boolean displayViewImages = false;
            Dimension size = new Dimension(100, 100);
            Point location = null;
            String title = new String("");
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(null, url);
	    Map.ID imageID = Map.ID.create("toplevelfolder", hs);
            boolean toolbar = true;
            Vector helpActions = null;
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Object presentation = 
		new Presentation(name, displayViews, displayViewImages, size, 
				 location, title, imageID, toolbar, 
				 helpActions);
            //create Presentation object from given values ... end


            if(presentation instanceof Presentation) { //is instance of Presentation class
                if (size.equals(((Presentation)presentation).getSize()) ) { //size value is correct
                    if ( !((Presentation)presentation).isViewDisplayed() ) { //displayViews value is correct
			if ( !((Presentation)presentation).isViewDisplayed() ) { //displayViews value is correct
			    if (imageID.equals(((Presentation)presentation).getImageID()) ) { //imageID value is correct
				if ( ((Presentation)presentation).isToolbar() ) { //toolbar value is correct
				    if (location == ((Presentation)presentation).getLocation() ) { //location value is correct
					return Status.passed(apiTested + "OK");
				    } else { //location value is not correct
					return Status.failed(apiTested + "Did not construct Presentation object with correct 'location' value: original: " + location + " obtained: " + ((Presentation)presentation).getLocation() );
				    }
				} else { //toolbar value is correct
				    return Status.failed(apiTested + "Did not construct Presentation object with correct 'toolbar' value: original: " + toolbar + " obtained: " + ((Presentation)presentation).isToolbar() );
				}
			    } else { //imageID value is not correct
				return Status.failed(apiTested + "Did not construct Presentation object with correct 'imageID' value: original: " + imageID + " obtained: " + ((Presentation)presentation).getImageID() );
			    }
			    } else { //displayViewImages value is not correct
				return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViewImages' value: original: " + displayViewImages + " obtained: " + ((Presentation)presentation).isViewImagesDisplayed() );
			    }
                    } else { //displayViews value is not correct
                        return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViews' value: original: " + displayViews + " obtained: " + ((Presentation)presentation).isViewDisplayed() );
                    }
                } else { //size value is not correct
                    return Status.failed(apiTested + "Did not construct Presentation object with correct 'size' value: original: " + size + " obtained: " + ((Presentation)presentation).getSize() );
                }
            } else { //is not instance of Presentation class
                return Status.failed(apiTested + "Did not construct Presentation object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, Map.ID imageID, boolean toolbar, java.util.Vector helpActions)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>name</code>         <code>null</code> value
     * @param <code>displayViews</code> <code>false</code>
     * @param <code>displayViewImages</code> <code>false</code>
     * @param <code>size</code>         <code>null</code> value
     * @param <code>location</code>     <code>null</code> value
     * @param <code>title</code>        <code>null</code> value
     * @param <code>imageID</code>	<code>null</code> value
     * @param <code>toolbar</code>      <code>false</code>
     * @param <code>helpActions</code>  <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "Presentation(java.lang.String name, boolean displayViews, boolean displayViewImages, java.awt.Dimension size, java.awt.Point location, java.lang.String title, map.ID imageID, boolean toolbar, java.util.Vector helpActions): "
            + "TestCase: Construct with: 'name == null; displayViews == false; displayViewImages == false; size == null; location == null; title == null; imageID == null; toolbar == false; helpActions == null' "
            + "ExpectedResult: Presentation object with given values "
            + "ObtainedResult: ";

        try {
            //create necessary variables ... start
            String name = null;
            boolean displayViews = false;
            boolean displayViewImages = false;
            Dimension size = null;
            Point location = null;
            String title = null;
	    Map.ID imageID = null;
            boolean toolbar = false;
            Vector helpActions = null;
            //create necessary variables ... end

            //create Presentation object from given values ... start
            Object presentation = 
		new Presentation(name, displayViews, displayViewImages, size, 
				 location, title, imageID, toolbar, 
				 helpActions);
            //create Presentation object from given values ... end


            if(presentation instanceof Presentation) { //is instance of Presentation class
                if (size == ((Presentation)presentation).getSize() ) { //size value is correct
                    if ( !((Presentation)presentation).isViewDisplayed() ) { //displayViews value is correct
			if ( !((Presentation)presentation).isViewImagesDisplayed() ) { //displayViewImages value is correct
			    if ((((Presentation)presentation).getImageID())== null ) { //imageID value is correct
				if ( !((Presentation)presentation).isToolbar() ) { //toolbar value is correct
				    if (location == ((Presentation)presentation).getLocation() ) { //location value is correct
					return Status.passed(apiTested + "OK");
				    } else { //location value is not correct
					return Status.failed(apiTested + "Did not construct Presentation object with correct 'location' value: original: " + location + " obtained: " + ((Presentation)presentation).getLocation() );
				    }
				} else { //toolbar value is correct
				    return Status.failed(apiTested + "Did not construct Presentation object with correct 'toolbar' value: original: " + toolbar + " obtained: " + ((Presentation)presentation).isToolbar() );
				}
			    } else { //imageID value is not correct
				return Status.failed(apiTested + "Did not construct Presentation object with correct 'imageID' value: original: " + imageID + " obtained: " + ((Presentation)presentation).getImageID() );
			    }
			} else { //displayViewImages value is not correct
			    return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViewImages' value: original: " + displayViewImages + " obtained: " + ((Presentation)presentation).isViewImagesDisplayed() );
			}
		    } else { //displayViews value is not correct
                        return Status.failed(apiTested + "Did not construct Presentation object with correct 'displayViews' value: original: " + displayViews + " obtained: " + ((Presentation)presentation).isViewDisplayed() );
                    }
                } else { //size value is not correct
                    return Status.failed(apiTested + "Did not construct Presentation object with correct 'size' value: original: " + size + " obtained: " + ((Presentation)presentation).getSize() );
                }
            } else { //is not instance of Presentation class
                return Status.failed(apiTested + "Did not construct Presentation object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... PrintSetupAction(control) --> PrintSetupAction(control)
 * testCase2 ... PrintSetupAction(control) --> PrintSetupAction(null)
 */

package javasoft.sqe.tests.api.javax.help.PrintSetupAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.PrintSetupAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.PrintSetupAction ... PrintSetupAction(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class PrintSetupActionTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public PrintSetupActionTest() {
    }

    public static void main(String argv[]) {
        PrintSetupActionTest test = new PrintSetupActionTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>PrintSetupAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> valid value
     */
    public Status testCase1() {
        String apiTested = "PrintSetupAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == valid' "
            + "ExpectedResult: PrintSetupAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            Object control = new Object();
            Object object = new PrintSetupAction(control);
            //create new PrintSetupAction object ... end

            if(object instanceof PrintSetupAction) { //is instance of PrintSetupAction class
                if (control.equals(((PrintSetupAction)object).getControl()) ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct PrintSetupAction object with correct 'control' object: original: " + control + " obtained: " + ((PrintSetupAction)object).getControl() );
                }
            } else { //is instance of PrintSetupAction class
                return Status.failed(apiTested + "Did not construct PrintSetupAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>PrintSetupAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "PrintSetupAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == null' "
            + "ExpectedResult: PrintSetupAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            Object control = null;
            Object object = new PrintSetupAction(control);
            //create new PrintSetupAction object ... end

            if(object instanceof PrintSetupAction) { //is instance of PrintSetupAction class
                if (control == ((PrintSetupAction)object).getControl() ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct PrintSetupAction object with correct 'control' object: original: " + control + " obtained: " + ((PrintSetupAction)object).getControl() );
                }
            } else { //is instance of PrintSetupAction class
                return Status.failed(apiTested + "Did not construct PrintSetupAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

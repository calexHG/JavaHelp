/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... PrintSetupAction(control).propertyChange(evt) --> PrintSetupAction(control).propertyChange(evt)
 * testCase2 ... PrintSetupAction(control).propertyChange(evt) --> PrintSetupAction(control).propertyChange(evt)
 * testCase3 ... PrintSetupAction(control).propertyChange(evt) --> PrintSetupAction(control).propertyChange(evt)
 * testCase4 ... PrintSetupAction(control).propertyChange(evt) --> PrintSetupAction(control).propertyChange(invalid)
 */

package javasoft.sqe.tests.api.javax.help.PrintSetupAction;

import java.io.PrintWriter;

import java.net.URL;

import java.beans.PropertyChangeEvent;

import javax.help.PrintSetupAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.PrintSetupAction ... propertyChange(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class PropertyChangeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public PropertyChangeTest() {
    }

    public static void main(String argv[]) {
        PropertyChangeTest test = new PropertyChangeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void propertyChange(java.beans.PropertyChangeEvent evt)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>evt</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void propertyChange(java.beans.PropertyChangeEvent evt): "
            + "TestCase: '(new PrintSetupAction(control)).propertyChange(evt)' "
            + "ExpectedResult: Change the 'enabled' value "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            PrintSetupAction printSetupAction = new PrintSetupAction(new Object() );
            //create new PrintSetupAction object ... end

            //create an event object ... start
            Object source = new Object();
            String propertyName = new String("enabled");
            Boolean oldValue = new Boolean(true);
            Boolean newValue = new Boolean(false);
            PropertyChangeEvent evt = new PropertyChangeEvent(source, propertyName, oldValue, newValue);
            //create an event object ... end

            //call the event ... start
            printSetupAction.propertyChange(evt);
            //call the event ... end


            if(newValue.booleanValue() == printSetupAction.isEnabled() ) {
                return Status.passed(apiTested + "Changed the 'enabled' value");
            } else {
                return Status.failed(apiTested + "Did not change the 'enabled' value: " + printSetupAction.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void propertyChange(java.beans.PropertyChangeEvent evt)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>evt</code> valid value
     */
    public Status testCase2() {
        String apiTested = "void propertyChange(java.beans.PropertyChangeEvent evt): "
            + "TestCase: '(new PrintSetupAction(control)).propertyChange(evt)' "
            + "ExpectedResult: Change the 'enabled' value "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            PrintSetupAction printSetupAction = new PrintSetupAction(new Object() );
            //create new PrintSetupAction object ... end

            //create an event object ... start
            Object source = new Object();
            String propertyName = new String("enabled");
            Boolean oldValue = new Boolean(false);
            Boolean newValue = new Boolean(false);
            PropertyChangeEvent evt = new PropertyChangeEvent(source, propertyName, oldValue, newValue);
            //create an event object ... end

            //call the event ... start
            printSetupAction.propertyChange(evt);
            //call the event ... end


            if(newValue.booleanValue() == printSetupAction.isEnabled() ) {
                return Status.passed(apiTested + "Changed the 'enabled' value");
            } else {
                return Status.failed(apiTested + "Did not change the 'enabled' value: " + printSetupAction.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void propertyChange(java.beans.PropertyChangeEvent evt)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>evt</code> valid value
     */
    public Status testCase3() {
        String apiTested = "void propertyChange(java.beans.PropertyChangeEvent evt): "
            + "TestCase: '(new PrintSetupAction(control)).propertyChange(evt)' "
            + "ExpectedResult: Change the 'enabled' value "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            PrintSetupAction printSetupAction = new PrintSetupAction(new Object() );
            //create new PrintSetupAction object ... end

            //create an event object ... start
            Object source = new Object();
            String propertyName = new String("enabled");
            Boolean oldValue = new Boolean(false);
            Boolean newValue = new Boolean(true);
            PropertyChangeEvent evt = new PropertyChangeEvent(source, propertyName, oldValue, newValue);
            //create an event object ... end

            //call the event ... start
            printSetupAction.propertyChange(evt);
            //call the event ... end


            if(newValue.booleanValue() == printSetupAction.isEnabled() ) {
                return Status.passed(apiTested + "Changed the 'enabled' value");
            } else {
                return Status.failed(apiTested + "Did not change the 'enabled' value: " + printSetupAction.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void propertyChange(java.beans.PropertyChangeEvent evt)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>evt</code> invalid value
     */
    public Status testCase4() {
        String apiTested = "void propertyChange(java.beans.PropertyChangeEvent evt): "
            + "TestCase: '(new PrintSetupAction(control)).propertyChange(invalid)' "
            + "ExpectedResult: No changes in the PrintSetupAction object "
            + "ObtainedResult: ";

        try {
            //create new PrintSetupAction object ... start
            PrintSetupAction printSetupAction = new PrintSetupAction(new Object() );
            //create new PrintSetupAction object ... end

            //create an event object ... start
            Object source = new Object();
            String propertyName = new String("incorrect");
            Boolean oldValue = new Boolean(true);
            Boolean newValue = new Boolean(false);
            PropertyChangeEvent evt = new PropertyChangeEvent(source, propertyName, oldValue, newValue);
            //create an event object ... end

            //store original 'printSetupAction' object state ... start
            boolean before = printSetupAction.isEnabled();
            //store original 'printSetupAction' object state ... end

            //call the event ... start
            printSetupAction.propertyChange(evt);
            //call the event ... end


            if(before == printSetupAction.isEnabled() ) {
                return Status.passed(apiTested + "No changes in the PrintSetupAction object");
            } else {
                return Status.failed(apiTested + "Ghanges in the PrintSetupAction object: " + printSetupAction.isEnabled() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

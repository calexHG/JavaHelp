/*
 * @(#)GetBeginTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *  
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.SearchHit;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.SearchHit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.SearchHit
 *
 * @author Meena C
 */

public class GetBeginTest extends MultiTest {
        
    public GetBeginTest() {
        
    }
    
    public static void main(String argv[]) {
        GetBeginTest test = new GetBeginTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getBegin() : " 
        + "\nTestCase : Construct SearchHit with MAX_VALUE for begin, " 
        + "call getBegin." 
        + "\nExpected Result : Should  return given value." 
        + "\nObtained Result : ";
        
        try {
            double con = Double.MAX_VALUE;
            int begin = Integer.MAX_VALUE;
            int end = Integer.MAX_VALUE;
            SearchHit searchHit = new SearchHit(con, begin, end);
            int gotBegin = searchHit.getBegin();
            if(gotBegin == begin) {
                return Status.passed(apiTested + "Returned given begin value." 
                    + "Given begin = " + begin + " , Got begin = " 
                    + gotBegin + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given begin " 
                    + "value. Given begin = " + begin 
                    + " , Got begin = " + gotBegin + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "getBegin() : " 
        + "\nTestCase : Construct SearchHit with MIN_VALUE for begin, " 
        + "call getBegin." 
        + "\nExpected Result : Should  return given value." 
        + "\nObtained Result : ";
        
        try {
            double con = Double.MIN_VALUE;
            int begin = Integer.MIN_VALUE;
            int end = Integer.MIN_VALUE;
            SearchHit searchHit = new SearchHit(con, begin, end);
            int gotBegin = searchHit.getBegin();
            if(gotBegin == begin) {
                return Status.passed(apiTested + "Returned given begin value." 
                    + " Given begin = " + begin + " , Got begin = " 
                    + gotBegin + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given begin " 
                    + "value. Given begin = " + begin 
                    + " , Got begin = " + gotBegin + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

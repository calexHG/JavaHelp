/*
 * @(#)GetConfidenceTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.SearchHit;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.SearchHit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.SearchHit
 *
 * @author Meena C
 */

public class GetConfidenceTest extends MultiTest {
        
    public GetConfidenceTest() {
        
    }
    
    public static void main(String argv[]) {
        GetConfidenceTest test = new GetConfidenceTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "getConfidence() : " 
        + "\nTestCase: Construct SearchHit with MAX_VALUE for confidence, call " 
        + "getConfidence." 
        + "\nExpected Result : Should  return given value." 
        + "\nObtained Result : ";
        
        try {
            double con = Double.MAX_VALUE;
            int begin = Integer.MAX_VALUE;
            int end = Integer.MAX_VALUE;
            SearchHit searchHit = new SearchHit(con, begin, end);
            double gotConfidence = searchHit.getConfidence();
            if(gotConfidence == con) {
                return Status.passed(apiTested + "Returned given confidence " 
                    + "value. Given confidence = " + con 
                    + " , Got confidence = " + gotConfidence + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given " 
                    + "confidence value. Given confidence = " + con 
                    + " , Got confidence = " + gotConfidence + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "getConfidence() : " 
        + "\nTestCase : Construct SearchHit with MIN_VALUE for confidence, " 
        + "call getConfidence." 
        + "\nExpected Result : Should  return given value." 
        + "\nObtained Result : ";
        
        try {
            double con = Double.MIN_VALUE;
            int begin = Integer.MIN_VALUE;
            int end = Integer.MIN_VALUE;
            SearchHit searchHit = new SearchHit(con, begin, end);
            double gotConfidence = searchHit.getConfidence();
            if(gotConfidence == con) {
                return Status.passed(apiTested + "Returned given confidence " 
                    + "value. Given confidence = " + con 
                    + " , Got confidence = " + gotConfidence + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given " 
                    + "confidence value. Given confidence = " + con 
                    + " , Got confidence = " + gotConfidence + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

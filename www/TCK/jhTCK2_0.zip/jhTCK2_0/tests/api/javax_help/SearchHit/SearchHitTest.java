/*
 * @(#)SearchHitTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.SearchHit;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.SearchHit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.SearchHit
 *
 * @author Meena C
 */

public class SearchHitTest extends MultiTest {
      
    public SearchHitTest() {
        
    }
    
    public static void main(String argv[]) {
        SearchHitTest test = new SearchHitTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "SearchHit(double confidence ,int begin,int end): " 
        + "\nTestCase : Construct SearchHit with MAX_VALUE , call get s." 
        + "\nExpected Result : Should create SearchHit object and get shd " 
        + "return given values." 
        + "\nObtained Result : ";
        
        try {
            double con = Double.MAX_VALUE;
            int begin = Integer.MAX_VALUE;
            int end = Integer.MAX_VALUE;
            SearchHit searchHit = new SearchHit(con, begin, end);
            double gotCon = searchHit.getConfidence();
            int gotBegin = searchHit.getBegin();
            int gotEnd = searchHit.getEnd();
            if(searchHit instanceof SearchHit) {
                if(gotCon == con) {
                    if(gotBegin == begin) {
                        if(gotEnd == end) {
                            return Status.passed(apiTested + "Constructed " 
                                + "SearchHit object with given values.\n");
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " SearchHit object with given end value ." 
                                + "\nGiven end value = " + end 
                                + " , Got  end value = " + gotEnd);
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "SearchHit object with given begin value." 
                            + "\nGiven begin value = " + begin 
                            + " , Got  begin value = " + gotBegin);
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "SearchHit object with given confidence value ." 
                        + "\nGiven con value = " + con 
                        + " , Got con value = " + gotCon);
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "SearchHit object");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

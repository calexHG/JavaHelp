
/*
* 
* 
* @(#)InTOCTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.SearchTOCItem;

import javax.help.search.SearchItem;
import javax.help.SearchTOCItem;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.SearchHit;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchTOCItem;
 
 * @author Ben John.
 */

public class InTOCTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public InTOCTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        InTOCTest test = new InTOCTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" inTOC() \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            SearchItem si = new SearchItem(url, "TITLE", 
                            Locale.getDefault().toString(), "hol.html", 3, 
                            1, 10, myv);
            SearchTOCItem sTOCItem = new SearchTOCItem(si);
            sTOCItem.inTOC();
            if(sTOCItem.inTOC() == false) {
                return Status.passed(apiTested + "Okay ; returns false for " 
                + "SearchTOCItem(SearchItem si) constructor");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid " 
                + "object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" inTOC() \" ";
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            Map.ID mid2 = Map.ID.create("halloween", hs);
            SearchTOCItem sTOCItem = new SearchTOCItem(mid, mid2, hs, 
                                     Locale.getDefault());
            if(sTOCItem.inTOC() == true) {
                return Status.passed(apiTested + "Okay ; returns true for " 
                + "SearchTOCItem(Map.ID id, Map.ID imageID,HelpSet hs, " 
                + "java.util.Locale locale)  constructor ");
            }
            else {
                return Status.failed(apiTested + "Did not returns true for " 
                + "SearchTOCItem(Map.ID id, Map.ID imageID,HelpSet hs, " 
                + "java.util.Locale locale)  constructor ");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised " + ee);
        }
    }
}

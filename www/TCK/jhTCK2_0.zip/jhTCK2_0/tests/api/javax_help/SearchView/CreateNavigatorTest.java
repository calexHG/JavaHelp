
/*
* 
*
* @(#)CreateNavigatorTest.java	1.2 99/03/01 Copyright 1993-1998 Sun Microsystems, Inc., 901 San Antonio Road,
* Palo Alto, California, 94303, U.S.A.  All Rights Reserved.
*
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not disclose
* such Confidential Information and shall use it only in accordance with
* the terms of the license agreement you entered into with Sun.
*/

/**
 *  <p>This is a program to test the functionality of 
 *  <p>createNavigator(HelpModel hm) method of class javax.help.SearchView</p>
 */

//current package
package javasoft.sqe.tests.api.javax.help.SearchView;

/*imports*/
import java.lang.reflect.Method;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.apitest.AssertionTest;
import javasoft.sqe.javatest.lib.apitest.ImmutableObjectFactory;
import javasoft.sqe.javatest.lib.apitest.Factory;
import java.io.PrintWriter;
import javasoft.sqe.javatest.lib.apitest.AssertionTest.ExceptionSet;
import java.awt.Component;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.HelpModel;
import javax.help.SearchView;
import javax.help.InvalidNavigatorViewException;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;

/**
 * <P>
 * This example tests a method createNavigator(HelpModel hm) of the
 * BandedSampleModel class using the AssertionTest Framework.
 * </P>
 *
 * @author Chellakumaran Ramasamy
 */

public class CreateNavigatorTest extends AssertionTest {
    private static PrintWriter log;
    private static PrintWriter ref;
    Factory[] factory;
    Method method;
    public static String HSLOC = System.getProperty("HS_LOC");
    DefaultHelpModel dhm1 = null;
    DefaultHelpModel dhm2 = null;
    HelpSet hs = null;
    Hashtable htab = null;
    
    public static void main(String args[]) {
        CreateNavigatorTest cnt = new CreateNavigatorTest();
        log = new PrintWriter(System.err);
        ref = new PrintWriter(System.out);
        Status testStatus = null;
        try {
            testStatus = cnt.run(args, log, ref);
        }
        catch(Exception e) {
            log.println("A major error occured :" + e);
        }
        testStatus.exit();
    }
    
    /*
    * Invoking the method createNavigator(HelpModel hm) by using
    * reflection and setting the factory of HelpModel for testing the  
    * functionality of the method for various  combinations.
    */
    
    public CreateNavigatorTest() {
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            dhm1 = new DefaultHelpModel(hs);
            method = SearchView.class.getMethod("createNavigator", new Class[] {
                HelpModel.class
            });
            setMethodUnderTest(method);
        }
        catch(Exception e) {
            //System.out.println("Method not found :" + e);
            e.printStackTrace();
        }
        try {
            setDataFactories(new Factory[] {
                ImmutableObjectFactory.createObjectFactory(new Object[] {
                    new SearchView(hs, "MySerachView", "MysearchLabel", htab)
                }), ImmutableObjectFactory.createObjectFactory(new Object[] {
                    dhm1, null
                })
            });
        }
        catch(Exception ee) {
            ee.printStackTrace();
            
        }
    }
    
    public void normalPostCondition() throws Fault {
        Component c = (Component)getResult();
        if(c == null) {
            hardAssert(true, "Expected a HelpModel but received null");
        }
        if(!(c instanceof Component)) {
            hardAssert(true, "Expected DefaultHelpModel but got " + c);
        }
    }
}


/*
* 
*
* @(#)SearchViewTest1.java	1.2 99/03/01 Copyright 1993-1998 Sun Microsystems, Inc., 901 San Antonio Road,
* Palo Alto, California, 94303, U.S.A.  All Rights Reserved.
*
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not disclose
* such Confidential Information and shall use it only in accordance with
* the terms of the license agreement you entered into with Sun.
*/
package javasoft.sqe.tests.api.javax.help.SearchView;

import java.lang.reflect.Constructor;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.apitest.AssertionTest;
import javasoft.sqe.javatest.lib.apitest.ImmutableObjectFactory;
import javasoft.sqe.javatest.lib.apitest.Factory;
import java.io.PrintWriter;
import javasoft.sqe.javatest.lib.apitest.AssertionTest.ExceptionSet;
import java.awt.Component;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.HelpModel;
import javax.help.Map;
import javax.help.SearchView;
import java.util.Hashtable;
import java.net.URL;

/**
 * This test program is to test the functionality of the constructor 
 * of the class javax.help.SearchView using AssertionTest
 * frame work.  The constructor is:
 * SearchView (HelpSet hs,String name,String label,Hashtable htab)
 *
 * @author Chellakumaran Ramasamy
 * @see SearchView,AssertionTest
 */

public class SearchViewTest1 extends AssertionTest {
    private static PrintWriter log;
    private static PrintWriter ref;
    Factory[] factory;
    public static String HSLOC = System.getProperty("HS_LOC");
    DefaultHelpModel dhm1 = null;
    DefaultHelpModel dhm2 = null;
    HelpSet hs = null;
    Hashtable htab = null;
    Constructor constructor;
    
    public static void main(String args[]) {
        SearchViewTest1 con = new SearchViewTest1();
        log = new PrintWriter(System.err);
        ref = new PrintWriter(System.out);
        Status testStatus = null;
        try {
            testStatus = con.run(args, log, ref);
        }
        catch(Exception e) {
            log.println("A major error occured :" + e);
            e.printStackTrace();
        }
        testStatus.exit();
    }
    
    /*
    * Invoking the constructor SaerchView ( HelpSet hs,String name,
    * String label,Hashtable) using reflection and setting the factory 
    * of integer's for testing the creation of the constructor for 
    * various combinations.
    */
    
    public SearchViewTest1() {
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            dhm1 = new DefaultHelpModel(hs);
            constructor = SearchView.class.getConstructor(new Class[] {
                HelpSet.class, String.class, String.class, Hashtable.class
            });
            setConstructorUnderTest(constructor);
        }
        catch(Exception e) {
            
            e.printStackTrace();
        }
        
        /**
         * The factory array is of length 5. For a constructor test
         * the first entry is always null. The next 4 entries correspond
         * to the 4 arguments in the constructor.
         */
        setDataFactories(factory = new Factory[] {
            ImmutableObjectFactory.createObjectFactory(new Object[] {
                null
            }), ImmutableObjectFactory.createObjectFactory(new HelpSet[] {
                hs
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MySearchView", null
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MySearchLabel", null
            }), ImmutableObjectFactory.createObjectFactory(new Hashtable[] {
                htab, null
            })
        });
    }
    
    public ExceptionSet predictExceptionSet(Object[] param) {
        ExceptionSet set = new ExceptionSet();
        if((getExecutionParameter(1) == null) 
        || (getExecutionParameter(2) == null)) {
            ExpectedException e2 = new ExpectedException(NullPointerException.class,
             "Caught Exception") {
                
                protected void exceptionPostCondition() throws Fault {
                    hardAssert(true, "NullPointerException");
                }
            };
            set.addException(e2);
        }
        return set;
    }
    
    public void normalPostCondition() throws Fault {
        SearchView sview = (SearchView)getResult();
        HelpSet hset = ((HelpSet)getExecutionParameter(0));
        String sname = ((String)getExecutionParameter(1));
        String slabel = ((String)getExecutionParameter(2));
        Hashtable htable = ((Hashtable)getExecutionParameter(3));
        hardAssert((hset == sview.getHelpSet()), "Expected" + hset + "got" 
        + sview.getHelpSet());
        hardAssert((sname == sview.getName()), "Expected" + sname + "got" 
        + sview.getName());
        hardAssert((slabel == sview.getLabel()), "Expected" + slabel + "got" 
        + sview.getLabel());
        hardAssert((htable == sview.getParameters()), "Expected" + htable 
        + "got" + sview.getParameters());
    }
}


/*
* 
*
* @(#)SearchViewTest2.java	1.2 99/03/01 Copyright 1993-1998 Sun Microsystems, Inc., 901 San Antonio Road,
* Palo Alto, California, 94303, U.S.A.  All Rights Reserved.
*
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not disclose
* such Confidential Information and shall use it only in accordance with
* the terms of the license agreement you entered into with Sun.
*/
package javasoft.sqe.tests.api.javax.help.SearchView;

import java.lang.reflect.Constructor;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.apitest.AssertionTest;
import javasoft.sqe.javatest.lib.apitest.ImmutableObjectFactory;
import javasoft.sqe.javatest.lib.apitest.Factory;
import java.io.PrintWriter;
import javasoft.sqe.javatest.lib.apitest.AssertionTest.ExceptionSet;
import java.awt.Component;
import javax.help.HelpSet;
import javax.help.DefaultHelpModel;
import javax.help.HelpModel;
import javax.help.Map;
import javax.help.SearchView;
import javax.help.InvalidNavigatorViewException;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;

/**
 * This test program is to test the functionality of the constructor 
 * of the class javax.help.SearchView using AssertionTest
 * frame work.  The constructor is:
 * SearchView(HelpSet hs,String name,String label,Locale locale,Hashtable htab)
 *
 * @author Chellakumaran Ramasamy
 * @see SearchView,AssertionTest
 */

public class SearchViewTest2 extends AssertionTest {
    private static PrintWriter log;
    private static PrintWriter ref;
    Factory[] factory;
    public static String HSLOC = System.getProperty("HS_LOC");
    DefaultHelpModel dhm1 = null;
    DefaultHelpModel dhm2 = null;
    HelpSet hs = null;
    Hashtable htab = null;
    Constructor constructor;
    Locale locale = null;
    
    public static void main(String args[]) {
        SearchViewTest2 con = new SearchViewTest2();
        log = new PrintWriter(System.err);
        ref = new PrintWriter(System.out);
        Status testStatus = null;
        try {
            testStatus = con.run(args, log, ref);
        }
        catch(Exception e) {
            log.println("A major error occured :" + e);
            e.printStackTrace();
        }
        testStatus.exit();
    }
    
    /*
    * Invoking the constructor SearchView (HelpSet hs,String name,String label,
    * Locale locale,Hashtable htab) using reflection and setting the factory of 
    * Objects for testing the creation of the constructor for various
    * combinations of actual values and null .
    */
    
    public SearchViewTest2() {
        try {
            locale = Locale.getDefault();
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            dhm1 = new DefaultHelpModel(hs);
            constructor = SearchView.class.getConstructor(new Class[] {
                HelpSet.class, String.class, String.class, Locale.class, 
                Hashtable.class
            });
            setConstructorUnderTest(constructor);
        }
        catch(Exception e) {
            
            e.printStackTrace();
        }
        
        /**
         * The factory array is of length 6. For a constructor test
         * the first entry is always null. The next 5 entries correspond
         * to the 5 arguments in the constructor.
         */
        setDataFactories(factory = new Factory[] {
            ImmutableObjectFactory.createObjectFactory(new Object[] {
                null
            }), ImmutableObjectFactory.createObjectFactory(new HelpSet[] {
                hs
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MySeaBrchView", null
            }), ImmutableObjectFactory.createStringFactory(new String[] {
                "MySearchLabel", null
            }), ImmutableObjectFactory.createObjectFactory(new Locale[] {
                locale, null
            }), ImmutableObjectFactory.createObjectFactory(new Hashtable[] {
                htab, null
            })
        });
    }
    
    public ExceptionSet predictExceptionSet(Object[] param) {
        ExceptionSet set = new ExceptionSet();
        if((getExecutionParameter(1) == null) 
        || (getExecutionParameter(2) == null)) {
            ExpectedException e2 = new ExpectedException(NullPointerException.class, 
                                   "Caught Exception") {
                
                protected void exceptionPostCondition() throws Fault {
                    hardAssert(true, "NullPointerException");
                }
            };
            set.addException(e2);
        }
        return set;
    }
    
    public void normalPostCondition() throws Fault {
        SearchView sview = (SearchView)getResult();
        HelpSet hset = ((HelpSet)getExecutionParameter(0));
        String sname = ((String)getExecutionParameter(1));
        String slabel = ((String)getExecutionParameter(2));
        Locale locale = (Locale)getExecutionParameter(3);
        Hashtable htable = ((Hashtable)getExecutionParameter(4));
        hardAssert((hset == sview.getHelpSet()), "Expected" + hset + "got" 
        + sview.getHelpSet());
        hardAssert((sname == sview.getName()), "Expected" + sname + "got" 
        + sview.getName());
        hardAssert((slabel == sview.getLabel()), "Expected" + slabel + "got" 
        + sview.getLabel());
        hardAssert((locale == sview.getLocale()), "Expected" + locale + "got" 
        + sview.getLocale());
        hardAssert((htable == sview.getParameters()), "Expected" + htable 
        + "got" + sview.getParameters());
    }
}

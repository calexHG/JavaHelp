/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SeparatorAction(control) --> SeparatorAction(control)
 * testCase2 ... SeparatorAction(control) --> SeparatorAction(null)
 */

package javasoft.sqe.tests.api.javax.help.SeparatorAction;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.SeparatorAction;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.SeparatorAction ... SeparatorAction(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SeparatorActionTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SeparatorActionTest() {
    }

    public static void main(String argv[]) {
        SeparatorActionTest test = new SeparatorActionTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>SeparatorAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> valid value
     */
    public Status testCase1() {
        String apiTested = "SeparatorAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == valid' "
            + "ExpectedResult: SeparatorAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new SeparatorAction object ... start
            Object control = new Object();
            Object object = new SeparatorAction(control);
            //create new SeparatorAction object ... end

            if(object instanceof SeparatorAction) { //is instance of SeparatorAction class
                if (control.equals(((SeparatorAction)object).getControl()) ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct SeparatorAction object with correct 'control' object: original: " + control + " obtained: " + ((SeparatorAction)object).getControl() );
                }
            } else { //is instance of SeparatorAction class
                return Status.failed(apiTested + "Did not construct SeparatorAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SeparatorAction(java.lang.Object control)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>control</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "SeparatorAction(java.lang.Object control): "
            + "TestCase: Construct with: 'control == null' "
            + "ExpectedResult: SeparatorAction object with given values "
            + "ObtainedResult: ";

        try {
            //create new SeparatorAction object ... start
            Object control = null;
            Object object = new SeparatorAction(control);
            //create new SeparatorAction object ... end

            if(object instanceof SeparatorAction) { //is instance of SeparatorAction class
                if (control == ((SeparatorAction)object).getControl() ) { //control value is correct
                    return Status.passed(apiTested + "OK");
                } else { //control value is not correct
                    return Status.failed(apiTested + "Did not construct SeparatorAction object with correct 'control' object: original: " + control + " obtained: " + ((SeparatorAction)object).getControl() );
                }
            } else { //is instance of SeparatorAction class
                return Status.failed(apiTested + "Did not construct SeparatorAction object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SortMerge.setMergeType(node) --> SortMerge.setMergeType(node)
 * testCase2 ... SortMerge.setMergeType(node) --> SortMerge.setMergeType(node)
 * testCase3 ... SortMerge.setMergeType(node) --> SortMerge.setMergeType(null)
 */

package javasoft.sqe.tests.api.javax.help.SortMerge;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.TreeItem;
import javax.help.SortMerge;

import javax.swing.tree.DefaultMutableTreeNode;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.SortMerge ... setMergeType(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetMergeTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetMergeTypeTest() {
    }

    public static void main(String argv[]) {
        SetMergeTypeTest test = new SetMergeTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: SortMerge.setMergeType(node) "
            + "ExpectedResult: javax.help.SortMerge "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create HelpSet object ... end

            //get TOCView object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object ... end

            //get node ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)tocview.getDataAsTree().getFirstChild(); //Animal Categories
            //get node ... end

            //set merge type ... start
            SortMerge.setMergeType(node);
            //set merge type ... end

	    TreeItem item = (TreeItem)node.getUserObject();

            String type = item.getMergeType();
	    if (type.compareTo("javax.help.SortMerge") == 0) {
                return Status.passed(apiTested + type);
            } else {
                return Status.failed(apiTested + "returned " + type);
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase2() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: SortMerge.setMergeType(node) "
            + "ExpectedResult: javax.help.SortMerge "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create HelpSet object ... end

            //get TOCView object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object ... end

            //get node ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)tocview.getDataAsTree().getFirstChild().getChildAt(1).getChildAt(2); //Animal Categories/Pictures/Bears
            //get node ... end

            //set merge type ... start
            SortMerge.setMergeType(node);
            //set merge type ... end


	    String type = ((TreeItem)node.getUserObject()).getMergeType();
	    if (type.compareTo("javax.help.SortMerge")==0) {
                return Status.passed(apiTested + type);
            } else {
                return Status.failed(apiTested + type);
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> valid value
     */
    public Status testCase3() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: SortMerge.setMergeType(node) "
            + "ExpectedResult: javax.help.AppendMerge "
            + "ObtainedResult: ";

        try {
            //create HelpSet object ... start
            HelpSet hs = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            //create HelpSet object ... end

            //get TOCView object ... start
            TOCView tocview = (TOCView)hs.getNavigatorView("TOC");
            //get TOCView object ... end

            //get node ... start
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)tocview.getDataAsTree().getFirstChild().getChildAt(1).getChildAt(10); //Animal Categories/Pictures/Wolves
            //get node ... end

            //set merge type ... start
            SortMerge.setMergeType(node);
            //set merge type ... end


	    String type = ((TreeItem)node.getUserObject()).getMergeType();
	    System.out.println("treeItem=" + (TreeItem)node.getUserObject() + " type=" + type);
	    if (type.compareTo("javax.help.AppendMerge")==0) {
                return Status.passed(apiTested + type);
            } else {
                return Status.failed(apiTested + type);
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

    /**
     * Method test: <code>void setMergeType(javax.swing.tree.DefaultMutableTreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "void setMergeType(javax.swing.tree.DefaultMutableTreeNode node): "
            + "TestCase: SortMerge.setMergeType(null) "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //call sortNode method ... start
            SortMerge.setMergeType(null);
            //call sortNode method ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SwingHelpUtility.getImageIcon(baseClass, image) --> SwingHelpUtility.getImageIcon(baseClass, image)
 * testCase2 ... SwingHelpUtility.getImageIcon(baseClass, image) --> SwingHelpUtility.getImageIcon(baseClass, invalid)
 * testCase3 ... SwingHelpUtility.getImageIcon(baseClass, image) --> SwingHelpUtility.getImageIcon(baseClass, null)
 * testCase4 ... SwingHelpUtility.getImageIcon(baseClass, image) --> SwingHelpUtility.getImageIcon(null, image)
 */

package javasoft.sqe.tests.api.javax.help.SwingHelpUtilities;

import java.io.PrintWriter;

import java.net.URL;

import javax.swing.ImageIcon;

import javax.help.SwingHelpUtilities;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;


/**
 * Tests for javax.help.SwingHelpUtilities ... getImageIcon(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetImageIconTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetImageIconTest() {
    }

    public static void main(String argv[]) {
        GetImageIconTest test = new GetImageIconTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>baseClass</code> valid value
     * @param <code>image</code>     valid value
     */
    public Status testCase1() {
        String apiTested = "javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image): "
            + "TestCase: 'SwingHelpUtilities.get(baseClass, image)' "
            + "ExpectedResult: 'ImageIcon object' "
            + "ObtainedResult: ";

        try {
            //setup necessary variables ... start
            Class baseClass = this.getClass();
            String image = "duke.gif";

            //setup necessary variables ... end

            //create ImageIcon object ... start
            ImageIcon icon = SwingHelpUtilities.getImageIcon(baseClass, image);
            //create ImageIcon object ... end

            if (icon == null) {
                System.out.println("NULL");
            }


            if(icon instanceof ImageIcon) {
                return Status.passed(apiTested + "Got 'ImageIcon object'");
            } else {
                return Status.failed(apiTested + "Did not get 'ImageIcon object': " + icon.getClass().getName() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>baseClass</code> valid value
     * @param <code>image</code>     invalid value
     */
    public Status testCase2() {
        String apiTested = "javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image): "
            + "TestCase: 'SwingHelpUtilities.get(baseClass, invalid)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //setup necessary variables ... start
            Class baseClass = this.getClass();
            String image = (new URL("file", null, HSLOC + "/incorrect.gif")).getFile();
            //setup necessary variables ... end

            //create ImageIcon object ... start
            ImageIcon icon = SwingHelpUtilities.getImageIcon(baseClass, image);
            //create ImageIcon object ... end


            if(icon == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + icon);
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>baseClass</code> valid value
     * @param <code>image</code>     <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image): "
            + "TestCase: 'SwingHelpUtilities.get(baseClass, null)' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //setup necessary variables ... start
            Class baseClass = this.getClass();
            String image = null;
            //setup necessary variables ... end

            //create ImageIcon object ... start
            ImageIcon icon = SwingHelpUtilities.getImageIcon(baseClass, image);
            //create ImageIcon object ... end


            if(icon == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + icon);
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + exc);
        }
    }


    /**
     * Method test: <code>javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>baseClass</code> <code>null</code> value
     * @param <code>image</code>     valid value
     */
    public Status testCase4() {
        String apiTested = "javax.swing.ImageIcon getImageIcon(java.lang.Class baseClass, java.lang.String image): "
            + "TestCase: 'SwingHelpUtilities.get(null, image)' "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //setup necessary variables ... start
            Class baseClass = null;
            String image = (new URL("file", null, HSLOC + "/duke.gif")).getFile();
            //setup necessary variables ... end

            //create ImageIcon object ... start
            ImageIcon icon = SwingHelpUtilities.getImageIcon(baseClass, image);
            //create ImageIcon object ... end


            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + exc);
        }
    }

}

/*
 * @(#)GetHelpSetTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TOCItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TOCItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCItem
 *
 * @author Meena C
 */

public class GetHelpSetTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetHelpSetTest() {
        
    }
    
    public static void main(String argv[]) {
        GetHelpSetTest test = new GetHelpSetTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = " : TOCItem.getHelpSet() : " 
        + "\nTestCase : Construct TOCItem using default constructor and " 
        + "call getHelpSet()" 
        + "\nExpected Result : Shd return null." 
        + "\nObtained Result : ";
        
        try {
            TOCItem tocItem = new TOCItem();
            HelpSet gotHS = tocItem.getHelpSet();
            if(gotHS == null) {
                return Status.passed(apiTested + "Returned null HelpSet.\n");
            } else {
                return Status.failed(apiTested + "Did not return null HelpSet." 
                	+ "\nGot HelpSet : " + gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = " : TOCItem.getHelpSet() : " 
        + "\nTestCase : Construct TOCItem using TOCItem(Map.ID mapId , " 
        + "Map.ID imageID , Locale locale ) with valid values and call " 
        + "getHelpSet()" 
        + "\nExpected Result : Shd return the HelpSet specified by mapId." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            HelpSet gotHS = tocItem.getHelpSet();
            if(gotHS.equals(hs)) {
                return Status.passed(apiTested + "Returned specified HelpSet." 
                	+ "\nGiven HelpSet : " + hs + "\nGot HelpSet : " 
                	+ gotHS + "\n");
            } else {
                return Status.failed(apiTested + "Did not return specified " 
                	+ "HelpSet.\nGiven HelpSet : " + hs + "\nGot HelpSet : " 
                	+ gotHS + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

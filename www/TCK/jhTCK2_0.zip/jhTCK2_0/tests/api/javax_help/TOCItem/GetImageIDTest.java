/*
 * @(#)GetImageIDTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TOCItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TOCItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCItem
 *
 * @author Meena C
 */

public class GetImageIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetImageIDTest() {
        
    }
    
    public static void main(String argv[]) {
        GetImageIDTest test = new GetImageIDTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = " : TOCItem.getImageID() : " 
        + "\nTestCase : Construct TOCItem using default constructor and " 
        + "call getImageID()" 
        + "\nExpected Result : Shd return null." 
        + "\nObtained Result : ";
        
        try {
            TOCItem tocItem = new TOCItem();
            ID gotImageID = tocItem.getImageID();
            if(gotImageID == null) {
                return Status.passed(apiTested + "Returned null ImageID.\n");
            } else {
                return Status.failed(apiTested + "Did not return null ImageID." 
                	+ "\nGot ImageID : " + gotImageID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = " : TOCItem.getImageID() : " 
        + "\nTestCase : Construct TOCItem using TOCItem(Map.ID mapId , " 
        + "Map.ID imageID , Locale locale ) with valid values and call " 
        + "getImageID()" 
        + "\nExpected Result : Shd return specified image ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            ID gotImageID = tocItem.getImageID();
            if(gotImageID.equals(imageID)) {
                return Status.passed(apiTested + "Returned specified imageId." 
                	+ "\nGiven imageID : " + imageID + "\nGot imageID : " 
                	+ gotImageID + "\n");
            } else {
                return Status.failed(apiTested + "Did not return specified " 
                	+ "ImageID.\nGiven ImageID : " + imageID 
                	+ "\nGot ImageID : " + gotImageID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

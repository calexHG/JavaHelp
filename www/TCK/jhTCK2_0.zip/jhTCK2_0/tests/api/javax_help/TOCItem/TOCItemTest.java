/*
 * @(#)TOCItemTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TOCItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TOCItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCItem
 *
 * @author Meena C
 */

public class TOCItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public TOCItemTest() {
        
    }
    
    public static void main(String argv[]) {
        TOCItemTest test = new TOCItemTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
                new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = "TOCItem() : " 
        + "\nTestCase : Construct TOCItem using Default Constructor." 
        + "\nExpected Result : Should create TOCItem object." 
        + "\nObtained Result : ";
        
        try {
            TOCItem tocItem = new TOCItem();
            if(tocItem instanceof TOCItem) {
                return Status.passed(apiTested + "Constructed  " 
                    + "TOCItem object.\n");
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + " TOCItem object.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = "TOCItem(Map.ID mapID,Map.ID imageID,Locale locale):" 
        + "\nTestCase : Pass valid values for mapId , imageId , locale." 
        + "\nExpected Result : Shd construct TOCItem with given values." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID().equals(mapID)) {
                    if(tocItem.getImageID().equals(imageID)) {
                        if(tocItem.getLocale().equals(locale)) {
                            if(tocItem.getHelpSet().equals(hs)) {
                                return Status.passed(apiTested + "Constructed" 
                                    + " TOCItem object with given valid " 
                                    + "values.\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with " 
                                    + "specified Helpset.\nGiven HelpSet: " 
                                    + hs + "\nGot HelpSet : " 
                                    + tocItem.getHelpSet() + "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " TOCItem object with specified Locale." 
                                + "\nGiven Locale: " +locale+ "\nGot Locale: " 
                                + tocItem.getLocale() + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "TOCItem object with specified imageID." 
                            + "\nGiven imageID : " + imageID 
                            + "\nGot imageID: "+tocItem.getImageID()+ "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "TOCItem object with specified ID.\nGiven ID : " 
                        + mapID + "\nGot ID : " + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "TOCItem object.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
        
        String apiTested = "TOCItem(Map.ID mapID,Map.ID imageID,Locale locale):" 
        + "\nTestCase : Construct TOCItem with null for mapID and valid " 
        + "values for imageID and locale" 
        + "\nExpected Result : Shd construct TOCItem with given imageID and " 
        + "locale and null mapID and Helpset." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String imageid = "toplevelfolder";
            ID mapID = null;
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID() == mapID) {
                    if(tocItem.getImageID().equals(imageID)) {
                        if(tocItem.getLocale().equals(locale)) {
                            if(tocItem.getHelpSet() == null) {
                                return Status.passed(apiTested + "Constructed " 
                                    + "TOCItem object with given imageID & " 
                                    + "locale & null mapID and Helpset.\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with null" 
                                    + " Helpset.\nGot HelpSet:" 
                                    + tocItem.getHelpSet()+ "\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + "TOCItem object with specified Locale." 
                                + "\nGiven Locale : " + locale 
                                + "\nGot Locale : " +tocItem.getLocale()+"\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "TOCItem object with specified imageID." 
                            + "\nGiven imageID : " + imageID 
                            + "\nGot imageID : "+tocItem.getImageID()+"\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct TOCItem" 
                        + " object with null ID.\nGot ID : " 
                        + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "TOCItem object.\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
        
        String apiTested = "TOCItem(Map.ID mapID,Map.ID imageID,Locale locale):" 
        + "\nTestCase : Construct TOCItem with null for imageID and valid " 
        + "values for mapID and locale" 
        + "\nExpected Result : Shd construct TOCItem with given mapID and " 
        + "locale and null imageID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            String imageid = "toplevelfolder";
            ID imageID = null;
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID().equals(mapID)) {
                    if(tocItem.getImageID() == null) {
                        if(tocItem.getLocale().equals(locale)) {
                            if(tocItem.getHelpSet().equals(hs)) {
                                return Status.passed(apiTested + "Constructed " 
                                    + " TOCItem object with given mapID " 
                                    + "and locale and null imageID.\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with specified " 
                                    + "Helpset.\nGiven HelpSet : " + hs + "\n"
                                    + "Got HelpSet:"+tocItem.getHelpSet()+"\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " TOCItem object with specified Locale." 
                                + "\nGiven Locale :" +locale+"\nGot Locale : " 
                                + tocItem.getLocale() + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "TOCItem object with null imageID.\nGot imageID:" 
                            + tocItem.getImageID() + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct TOCItem" 
                        + " object with specified ID.\nGiven ID : " + mapID 
                        + "\nGot ID : " + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "TOCItem object.\n");
            }
        } catch(Exception e) {
            e.printStackTrace();
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
        
        String apiTested = "TOCItem(Map.ID mapID,Map.ID imageID,Locale locale):" 
        + "\nTestCase : Construct TOCItem with null for locale and valid values" 
        + " for mapID and imageID" 
        + "\nExpected Result : Shd construct TOCItem with given mapID and " 
        + "imageID and null locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = null;
            TOCItem tocItem = new TOCItem(mapID, imageID, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID().equals(mapID)) {
                    if(tocItem.getImageID().equals(imageID)) {
                        if(tocItem.getLocale() == locale) {
                            if(tocItem.getHelpSet().equals(hs)) {
                                return Status.passed(apiTested + "Constructed " 
                                    + "TOCItem object given mapID and " 
                                    + "imageID and null locale.\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with specified " 
                                    + "Helpset.\nGiven HelpSet : " + hs + "\n"
                                    + "Got HelpSet:"+tocItem.getHelpSet()+"\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " TOCItem object with specified Locale." 
                                + "\nGiven Locale:"+locale + "\nGot Locale : " 
                                + tocItem.getLocale() + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct" 
                            + " TOCItem object with specified imageID." 
                            + "\nGiven imageID:" +imageID+ "\nGot imageID : " 
                            + tocItem.getImageID() + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "TOCItem object with specified ID.\nGiven ID : " 
                        + mapID + "\nGot ID : " + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                        + "TOCItem object\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
        
        String apiTested = "TOCItem(Map.ID mapID,Map.ID imageID,HelpSet hs, " 
        + "Locale locale) : " 
        + "\nTestCase : Construct TOCItem with same hs as that of mapID " 
        + "\nExpected Result : Shd construct TOCItem with given values." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, hs, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID().equals(mapID)) {
                    if(tocItem.getImageID().equals(imageID)) {
                        if(tocItem.getLocale().equals(locale)) {
                            if(tocItem.getHelpSet().equals(hs)) {
                                return Status.passed(apiTested + "Constructed " 
                                    + "TOCItem object with given values.\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with specified " 
                                    + "Helpset.\nGiven HelpSet : " + hs + "\n" 
                                    +"Got HelpSet: "+tocItem.getHelpSet()+"\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " TOCItem object with specified Locale." 
                                + "\nGiven Locale : " + locale 
                                + "\nGot Locale : " +tocItem.getLocale()+"\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct" 
                            + " TOCItem object with specified imageID." 
                            + "\nGiven imageID : " +imageID+ "\nGot imageID :" 
                            + tocItem.getImageID() + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "TOCItem object with specified ID.\nGiven ID : " 
                        + mapID + "\nGot ID : " + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "TOCItem object\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase7() {
        
        String apiTested = "TOCItem(Map.ID mapID , Map.ID imageID ,HelpSet hs," 
        + " Locale locale) : " 
        + "\nTestCase : Construct TOCItem with different hs than that of mapID " 
        + "\nExpected Result : Shd construct TOCItem with given values." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            URL url1 = new URL("file", null, HSLOC+"/merge/Master.hs");
            HelpSet hs = new HelpSet(cl, url);
            HelpSet hs1 = new HelpSet(cl, url1);
            String id = "hol_intro";
            String imageid = "toplevelfolder";
            ID mapID = ID.create(id, hs);
            ID imageID = ID.create(imageid, hs);
            Locale locale = Locale.getDefault();
            TOCItem tocItem = new TOCItem(mapID, imageID, hs1, locale);
            if(tocItem instanceof TOCItem) {
                if(tocItem.getID().equals(mapID)) {
                    if(tocItem.getImageID().equals(imageID)) {
                        if(tocItem.getLocale().equals(locale)) {
                            if(tocItem.getHelpSet().equals(hs1)) {
                                return Status.passed(apiTested + "Constructed " 
                                    + "TOCItem object with given values\n");
                            } else {
                                return Status.failed(apiTested + "Did not " 
                                    + "Construct TOCItem object with specified " 
                                    + "Helpset.\nGiven HelpSet : " + hs1 + "\n" 
                                    +"Got HelpSet:" +tocItem.getHelpSet()+"\n");
                            }
                        } else {
                            return Status.failed(apiTested + "Did not Construct" 
                                + " TOCItem object with specified Locale." 
                                + "\nGiven Locale : " +locale+ "\nGot Locale: " 
                                + tocItem.getLocale() + "\n");
                        }
                    } else {
                        return Status.failed(apiTested + "Did not Construct " 
                            + "TOCItem object with specified imageID." 
                            + "\nGiven imageID : " +imageID+"\nGot imageID : " 
                            + tocItem.getImageID() + "\n");
                    }
                } else {
                    return Status.failed(apiTested + "Did not Construct " 
                        + "TOCItem object with specified ID.\nGiven ID : " 
                        + mapID + "\nGot ID : " + tocItem.getID() + "\n");
                }
            } else {
                return Status.failed(apiTested + "Did not Construct " 
                    + "TOCItem object\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

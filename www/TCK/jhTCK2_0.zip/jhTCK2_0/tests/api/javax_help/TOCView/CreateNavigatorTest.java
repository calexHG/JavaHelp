

/*
* 
* 
* @(#)CreateNavigatorTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TOCView;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.TOCView;
import javax.help.TreeItemFactory;
import javax.help.TOCView.DefaultTOCFactory;
import javax.help.HelpModel;
import javax.help.DefaultHelpModel;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCView
 
 * @author Ben John.
 */

public class CreateNavigatorTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateNavigatorTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        CreateNavigatorTest test = new CreateNavigatorTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"  createNavigator(HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
            HelpModel hm = new DefaultHelpModel(hs);
            java.awt.Component cc = tview.createNavigator(hm);
            if(cc instanceof java.awt.Component) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \"  createNavigator(HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
            HelpModel hm = new DefaultHelpModel(hs);
            java.awt.Component cc = tview.createNavigator(null);
            if(cc instanceof java.awt.Component) {
                return Status.passed(apiTested + "Okay with null HelpModel");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \"  createNavigator(HelpModel model) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL url2 = new URL("file", null, HSLOC + "/holidays/HolidayTOC.xml");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "something.xml");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
            HelpModel hm = new DefaultHelpModel(hs);
            java.awt.Component cc = tview.createNavigator(hm);
            return Status.failed(apiTested 
            + "Did not raise Exception for Invalid data");
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested 
                + "Exception raised for Invalid data: " + ee);
            }
            else {
                return Status.failed(apiTested 
                + "Exception raised for Invalid data: " + ee);
            }
        }
    }
}

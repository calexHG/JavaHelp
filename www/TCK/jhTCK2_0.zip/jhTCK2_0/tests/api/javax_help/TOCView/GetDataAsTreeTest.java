
/*
* 
* 
* @(#)GetDataAsTreeTest.java	1.4 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TOCView;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.TOCView;
import javax.help.TOCItem;
import javax.help.TreeItemFactory;
import javax.help.TOCView.DefaultTOCFactory;
import javax.swing.tree.DefaultMutableTreeNode;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCView
 
 * @author Ben John.
 */

public class GetDataAsTreeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetDataAsTreeTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        GetDataAsTreeTest test = new GetDataAsTreeTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
			    new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getDataAsTree() \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
	    TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
			
            DefaultMutableTreeNode node = tview.getDataAsTree();
			
	    boolean check=false;
	    for (int i=0; i < node.getChildCount(); i++) {
		DefaultMutableTreeNode cnode = (DefaultMutableTreeNode) node.getChildAt(i);
		TOCItem item = (TOCItem) cnode.getUserObject();
		if (i == 0) {
		    if (item.getName().equals("History of the Holidays")) {
			check = true;
		    }
		}
	    }


            if(check) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
  
    public Status testCase2() {
        String apiTested = "Method \" getDataAsTree() \" \n" +
	    "TestCase: getDataAsTree with no data";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
	    TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
			
            DefaultMutableTreeNode node = tview.getDataAsTree();
			
            if(node.getChildCount() == 0) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}

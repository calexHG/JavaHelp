
/*
* 
* 
* @(#)TOCViewTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TOCView;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.TOCView;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCView
 
 * @author Ben John.
 */

public class TOCViewTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public TOCViewTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        TOCViewTest test = new TOCViewTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name,"
        + " java.lang.String label, " + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", htab);
            if((tview instanceof TOCView) && (tview.getHelpSet() == hs) 
            && (tview.getParameters() == htab) 
            && (tview.getName() == "MYTOCVIEW")) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid TOCView");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
                           + " java.lang.String label, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(null, "MYTOCVIEW", "MYTOCLABEL", htab);
            return Status.failed(apiTested 
                + "Did not Exception raised for null HelpSet");
            }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + "Exception raised for " 
                + "null HelpSet " + ee);
            }
            else {
                return Status.failed(apiTested + "Exception raised for " 
                + "null HelpSet " + ee);
            }
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
                           + " java.lang.String label, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, null, "MYTOCLABEL", htab);
            return Status.failed(apiTested + "Did not Exception " 
                + "raised for null name Parameter");
          }
		 catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + "Exception raised for " 
                + "null name " + ee);
            }
            else {
                return Status.failed(apiTested + "Exception raised for " 
                + "null name " + ee);
            }
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
        + " java.lang.String label, java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", null, htab);
            return Status.failed(apiTested + "Did not Exception" 
                + "raised for null Label");
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + "Exception raised for " 
                + "null Label " + ee);
            }
            else {
                return Status.failed(apiTested + "Exception raised for " 
                + "null Label " + ee);
            }
        }
    }
    
    public Status testCase5() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
        + " java.lang.String label, java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", null);
            if((tview instanceof TOCView) && (tview.getHelpSet() == hs) 
            && (tview.getParameters() == null) 
            && (tview.getName() == "MYTOCVIEW")) {
                return Status.passed(apiTested + "Okay for null Hashtable");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid " 
                + "TOCView for null Hashtable");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for null " 
            + "Hashtable " + ee);
        }
    }
    
    public Status testCase6() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
                           + " java.lang.String label, java.util.Locale, " 
                           + "java.util.Hashtable params)";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", 
                            Locale.getDefault(), htab);
            if((tview instanceof TOCView) && (tview.getHelpSet() == hs) 
            && (tview.getParameters() == htab) 
            && (tview.getName() == "MYTOCVIEW") 
            && (tview.getLocale() instanceof java.util.Locale) 
            && (tview.getLocale() == Locale.getDefault())) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct " 
                + "valid TOCView");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase7() {
        String apiTested = "Method: TOCView(HelpSet hs, java.lang.String name," 
                            + " java.lang.String label, java.util.Locale, " 
                            + " java.util.Hashtable params) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("one", "ValueOne");
            htab.put("Two", "ValueTwo");
            htab.put("Three", "ValueThree");
            TOCView tview = new TOCView(hs, "MYTOCVIEW", "MYTOCLABEL", null, htab);
            if((tview instanceof TOCView) && (tview.getHelpSet() == hs) 
            && (tview.getParameters() == htab) 
            && (tview.getName() == "MYTOCVIEW") && (tview.getLocale() == null)) {
                return Status.passed(apiTested + "Okay For Locale null");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid " 
                + "TOCView for null Locale");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised for null " 
            + "Locale " + ee);
        }
    }
}


/*
* 
* 
* @(#)CreateItemTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TOCViewDefaultTOCFactory;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.TOCView;
import javax.help.TOCView.DefaultTOCFactory;
import javax.help.TreeItem;
import javax.help.TOCItem;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCView
 
 * @author Ben John.
 */

public class CreateItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public CreateItemTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        CreateItemTest test = new CreateItemTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" createItem() \" ";
        try {
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
			TOCItem item = (TOCItem) tview.createItem();
            if((item.getImageID()==null) && 
				(item.getHelpSet()==null) && 
				(item.getName()==null) &&
				(item.getID() == null) &&
				(item.getLocale() == null)){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return valid TreeItem object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" createItem(java.lang.String tagName, "
                           + " java.util.Hashtable atts,HelpSet hs, "
                           + " java.util.Locale locale) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
            htab.put("target", "halloween");
            htab.put("image", "toplevelfolder");
			htab.put("text", "Valid Name");
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
			TOCItem item = (TOCItem) tview.createItem("tocitem", htab, hs, 
                                  Locale.getDefault());
            if((item.getID().id.equals("halloween")) &&
					(item.getImageID().id.equals("toplevelfolder")) && 
					(item.getHelpSet()== hs) && 
					(item.getName().equals("Valid Name")) &&
					(item.getLocale() == Locale.getDefault())){
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return valid TreeItem object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \" createItem(java.lang.String tagName, "
                           + " java.util.Hashtable atts,HelpSet hs, "
                           + " java.util.Locale locale) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
            TOCItem item = (TOCItem)tview.createItem("tocitem", null, hs, 
                                  Locale.getDefault());
            if((item.getID()==null)&&(item.getImageID()==null) && 
				(item.getHelpSet()== hs) && (item.getName()==null) &&
				(item.getLocale() == Locale.getDefault())) {
                return Status.passed(apiTested + "Okay for Hashtable null");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return valid TreeItem object for Hashtable null");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method \" createItem(java.lang.String tagName, "
                           + "java.util.Hashtable atts,HelpSet hs, "
                           + "java.util.Locale locale) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
			htab.put("target", "halloween");
            htab.put("image", "toplevelfolder");
			htab.put("text", "Valid Name");
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
            TOCItem item = (TOCItem) tview.createItem("tocitem", htab, null, 
                                  Locale.getDefault());
            if((item.getID()==null)&&(item.getImageID()==null) && 
				(item.getHelpSet()== null) && 
				(item.getName().equals("Valid Name")) &&
				(item.getLocale() == Locale.getDefault())) {
                return Status.passed(apiTested + "Okay for HelpSet null");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return valid TreeItem object for HelpSet null");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase5() {
        String apiTested = "Method \" createItem(java.lang.String tagName, "
                           + " java.util.Hashtable atts,HelpSet hs, "
                           + " java.util.Locale locale) \" ";
        HelpSet hs = null;
        try {
            ClassLoader loader = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            hs = new HelpSet(loader, url);
            Hashtable htab = new Hashtable();
			htab.put("target", "halloween");
            htab.put("image", "toplevelfolder");
			htab.put("text", "Valid Name");
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
            TOCItem item = (TOCItem) tview.createItem("tocitem", htab, hs, null);
            if((item.getID().id.equals("halloween")) &&
				(item.getImageID().id.equals("toplevelfolder")) && 
				(item.getHelpSet()== hs) && 
				(item.getName().equals("Valid Name")) &&
				(item.getLocale() == null)){
				
			    return Status.passed(apiTested + "Okay for Locale null");
            }
            else {
                return Status.failed(apiTested 
                + "Did not return valid TreeItem object for Locale null");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
	
		 public Status testCase6() {
	         String apiTested = "Method \" createItem(java.lang.String tagName, "
	                            + " java.util.Hashtable atts,HelpSet hs, "
	                            + " java.util.Locale locale) \" ";
	         HelpSet hs = null;
	         try {
	             ClassLoader loader = this.getClass().getClassLoader();
	             URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	             hs = new HelpSet(loader, url);
	             Hashtable htab = new Hashtable();
                 htab.put("image", "toplevelfolder");
                 htab.put("text", "Valid Name");
	             TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
	             TOCItem item = (TOCItem) tview.createItem("tocitem", htab, hs, 
				 			Locale.getDefault());
	             if((item.getID()== null ) &&
	 				(item.getImageID().id.equals("toplevelfolder")) && 
	 				(item.getHelpSet()== hs) && 
	 				(item.getName().equals("Valid Name")) &&
	 				(item.getLocale() == Locale.getDefault())){
	 				
	 			    return Status.passed(apiTested + "Okay ");
	             }
	             else {
	                 return Status.failed(apiTested 
	                 + "Did not return valid TreeItem object");
	             }
	         }
	         catch(Exception ee) {
	             return Status.failed(apiTested + "Exception raised: " + ee);
	         }
	     }
	 	
	 public Status testCase7() {
       String apiTested = "Method \" createItem(java.lang.String tagName, "
                          + " java.util.Hashtable atts,HelpSet hs, "
                            + " java.util.Locale locale) \" ";
         HelpSet hs = null;
         try {
             ClassLoader loader = this.getClass().getClassLoader();
             URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
             hs = new HelpSet(loader, url);
             Hashtable htab = new Hashtable();
			 htab.put("target","halloween");
             htab.put("text", "Valid Name");
             TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
             TOCItem item = (TOCItem) tview.createItem("tocitem", htab, hs, 
			 			Locale.getDefault());
             if((item.getID().id.equals("halloween")) &&
 				(item.getImageID()==null) && 
 				(item.getHelpSet()== hs) && 
 				(item.getName().equals("Valid Name")) &&
 				(item.getLocale() == Locale.getDefault())){
 				
 			    return Status.passed(apiTested + "Okay ");
             }
             else {
                 return Status.failed(apiTested 
                 + "Did not return valid TreeItem ");
             }
         }
         catch(Exception ee) {
             return Status.failed(apiTested + "Exception raised: " + ee);
         }
     }
	 	
	
		 public Status testCase8() {
	       String apiTested = "Method \" createItem(java.lang.String tagName, "
	                          + " java.util.Hashtable atts,HelpSet hs, "
	                            + " java.util.Locale locale) \" ";
	         HelpSet hs = null;
	         try {
	             ClassLoader loader = this.getClass().getClassLoader();
	             URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	             hs = new HelpSet(loader, url);
	             Hashtable htab = new Hashtable();
				 htab.put("target","halloween");
	             htab.put("image", "toplevelfolder");
	             TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
	             TOCItem item = (TOCItem) tview.createItem("tocitem", htab, hs, 
				 			Locale.getDefault());
	             if((item.getID().id.equals("halloween")) &&
	 				(item.getImageID().id.equals("toplevelfolder")) && 
	 				(item.getHelpSet()== hs) && 
	 				(item.getName()==null) &&
	 				(item.getLocale() == Locale.getDefault())){
	 				
	 			    return Status.passed(apiTested + "Okay ");
	             }
	             else {
	                 return Status.failed(apiTested 
	                 + "Did not return valid TreeItem object");
	             }
	         }
	         catch(Exception ee) {
	             return Status.failed(apiTested + "Exception raised: " + ee);
	         }
	     }
		 	
	 public Status testCase9() {
	        String apiTested = "Method \" createItem(java.lang.String tagName, "
	                           + " java.util.Hashtable atts,HelpSet hs, "
	                           + " java.util.Locale locale) \" ";
	        HelpSet hs = null;
	        try {
	            ClassLoader loader = this.getClass().getClassLoader();
	            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	            hs = new HelpSet(loader, url);
	            Hashtable htab = new Hashtable();
				htab.put("target", "halloween");
	            htab.put("image", "toplevelfolder");
				htab.put("text", "Valid Name");
	            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
	            TreeItem item = tview.createItem("TOC", htab, hs, 
	                                  Locale.getDefault());
				return Status.failed(apiTested 
	                + "Did not Exception throws for illegal tagName"); 
	            }
	        catch(Exception ee) {
				if(ee instanceof IllegalArgumentException){
					return Status.passed(apiTested + "Exception raised: " + ee);
				} else {
	            	return Status.failed(apiTested + "Exception raised: " + ee);
				}
	        }
	    }
}

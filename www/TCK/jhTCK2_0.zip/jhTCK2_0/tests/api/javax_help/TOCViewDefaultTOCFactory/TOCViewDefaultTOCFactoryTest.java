
/*
* 
* 
* @(#)TOCViewDefaultTOCFactoryTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TOCViewDefaultTOCFactory;

import java.io.PrintWriter;
import javax.help.BadIDException;
import javax.help.HelpSet;
import javax.help.Map;
import javax.help.TOCView;
import javax.help.TOCView.DefaultTOCFactory;
import java.util.Hashtable;
import java.util.Locale;
import java.net.URL;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TOCView
 
 * @author Ben John.
 */

public class TOCViewDefaultTOCFactoryTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public TOCViewDefaultTOCFactoryTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        TOCViewDefaultTOCFactoryTest test = new TOCViewDefaultTOCFactoryTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" TOCView.DefaultTOCFactory() \" ";
        try {
            TOCView.DefaultTOCFactory tview = new TOCView.DefaultTOCFactory();
            if(tview instanceof TOCView.DefaultTOCFactory) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid TOCView.DefaultTOCFactory");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}

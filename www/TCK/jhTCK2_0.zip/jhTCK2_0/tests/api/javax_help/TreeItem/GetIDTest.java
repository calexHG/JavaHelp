/*
 * @(#)GetIDTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TreeItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TreeItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem
 *
 * @author Meena C
 */

public class GetIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetIDTest() {
        
    }
    
    public static void main(String argv[]) {
        GetIDTest test = new GetIDTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
               
        String apiTested = " : TreeItem.getID() : " 
        + "\nTestCase : Construct TreeItem object with valid values and " 
        + "then call getID() " 
        + "\nExpected Result : Shd return the given ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            ID gotID = treeItem.getID();
            if(gotID.equals(mapID)) {
                return Status.passed(apiTested +"Returned given ID.\nGiven ID:" 
                    + mapID + "\nGot ID : " + gotID + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given ID." 
                    + "\nGiven ID : " + mapID + "\nGot ID : " + gotID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
        
        String apiTested = " : TreeItem.getID() : " 
        + "\nTestCase : Construct TreeItem object with null ID and call getID()" 
        + "\nExpected Result : Shd return null for ID." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = null;
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            ID gotID = treeItem.getID();
            if(gotID == mapID) {
                return Status.passed(apiTested+"Returned null ID.\nGiven ID : " 
                    + mapID + "\nGot ID : " + gotID + "\n");
            } else {
                return Status.failed(apiTested + "Did not return null ID." 
                    + "\n Given ID : " + mapID + "\nGot ID : " + gotID + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

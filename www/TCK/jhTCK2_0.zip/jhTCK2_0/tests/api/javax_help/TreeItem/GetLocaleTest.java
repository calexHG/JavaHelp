/*
 * @(#)GetLocaleTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TreeItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import java.util.Calendar;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TreeItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem
 *
 * @author Meena C
 */

public class GetLocaleTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    Locale availLoc[] = Calendar.getAvailableLocales();
    
    public GetLocaleTest() {
        
    }
    
    public static void main(String argv[]) {
        GetLocaleTest test = new GetLocaleTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
            new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        
        String apiTested = " : TreeItem.getLocale() : " 
        + "\nTestCase : Construct TreeItem object with Default locale and " 
        + "call getLocale()" 
        + "\nExpected Result : Shd return given locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            Locale gotLocale = treeItem.getLocale();
            if(gotLocale.equals(locale)) {
                return Status.passed(apiTested + "Got specified Locale." 
                    + "\nGiven Locale : " + locale + "\nGot Locale : " 
                    + gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not return specified " 
                	+ "Locale.\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = " : TreeItem.getLocale() : " 
        + "\nTestCase : Construct TreeItem object with first item from the " 
        + "array of available locales and call getLocale()" 
        + "\nExpected Result : Shd return given locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = availLoc[0];
            TreeItem treeItem = new TreeItem(mapID, locale);
            Locale gotLocale = treeItem.getLocale();
            if(gotLocale.equals(locale)) {
                return Status.passed(apiTested + "Returned given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = " : TreeItem.getLocale() : " 
        + "\nTestCase : Construct TreeItem object with middle item from " 
        + "the array of available locales and call getLocale()" 
        + "\nExpected Result : Shd return given locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            int len = availLoc.length;
            Locale locale = availLoc[len / 2];
            TreeItem treeItem = new TreeItem(mapID, locale);
            Locale gotLocale = treeItem.getLocale();
            if(gotLocale.equals(locale)) {
                return Status.passed(apiTested + "Returned given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = " : TreeItem.getLocale() : " 
        + "\nTestCase : Construct TreeItem object with last item from the " 
        + "array of available locales and call getLocale()" 
        + "\nExpected Result : Shd return given locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            int len = availLoc.length;
            Locale locale = availLoc[len - 1];
            TreeItem treeItem = new TreeItem(mapID, locale);
            Locale gotLocale = treeItem.getLocale();
            if(gotLocale.equals(locale)) {
                return Status.passed(apiTested + "Returned given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not return given Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = " : TreeItem.getLocale() : " 
        + "\nTestCase : Construct TreeItem object with null locale and call" 
        + " getLocale()" 
        + "\nExpected Result : Shd return null locale." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = null;
            TreeItem treeItem = new TreeItem(mapID, locale);
            Locale gotLocale = treeItem.getLocale();
            if(gotLocale == locale) {
                return Status.passed(apiTested + "Returned null Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not return null Locale." 
                	+ "\nGiven Locale : " + locale + "\nGot Locale : " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCaseN ... TreeItem().getMergeType() --> TreeItem().getMergeType()
 *
 * testCaseN ... TreeItem(name).getMergeType() --> TreeItem(name).getMergeType()
 *
 * testCaseN ... TreeItem(id, locale).getMergeType() --> TreeItem(id, locale).getMergeType()
 */

package javasoft.sqe.tests.api.javax.help.TreeItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.TreeItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem ... getMergeType()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetMergeTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetMergeTypeTest() {
    }

    public static void main(String argv[]) {
        GetMergeTypeTest test = new GetMergeTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.lang.String getMergeType()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.lang.String getMergeType(): "
            + "TestCase: '(new TreeItem()).getMergeType()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create TreeItem object ... start
            TreeItem item = new TreeItem();
            //create TreeItem object ... end


            if(item.getMergeType() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getMergeType()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "java.lang.String getMergeType(): "
            + "TestCase: '(new TreeItem(name)).getMergeType()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create TreeItem object ... start
            TreeItem item = new TreeItem(new String("TreeItem") );
            //create TreeItem object ... end


            if(item.getMergeType() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getMergeType()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "java.lang.String getMergeType(): "
            + "TestCase: '(new TreeItem(id, locale)).getMergeType()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //create necessary help object ... start
            //create necessary help object ... end

            //create TreeItem object ... start
            TreeItem item = new TreeItem(ID.create("hol_intro", new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"))),  Locale.getDefault());
            //create TreeItem object ... end


            if(item.getMergeType() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

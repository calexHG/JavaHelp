/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... TreeItem().getURL() --> TreeItem().getURL()
 *
 * testCase2 ... TreeItem(name).getURL() --> TreeItem(name).getURL()
 *
 * testCase3 ... TreeItem(id, locale).getURL() --> TreeItem(id, locale).getURL()
 */

package javasoft.sqe.tests.api.javax.help.TreeItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.TreeItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem ... getURL()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetURLTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetURLTest() {
    }

    public static void main(String argv[]) {
        GetURLTest test = new GetURLTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.net.URL getURL()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.net.URL getURL(): "
            + "TestCase: '(new TreeItem()).getURL()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem();
            //creating TreeItem object ... end


            if(item.getURL() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + item.getURL() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.net.URL getURL()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "java.net.URL getURL(): "
            + "TestCase: '(new TreeItem(name)).getURL()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem("tree item");
            //creating TreeItem object ... end


            if(item.getURL() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null': " + item.getURL() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.net.URL getURL()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "java.net.URL getURL(): "
            + "TestCase: '(new TreeItem(id, locale)).getURL()' "
            + "ExpectedResult: 'id.url' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            String id = "hol_intro";
            ID mapID  = ID.create(id, hs);
            //creating Map.ID object ... end

            //creating TreeItem object ... start
            TreeItem item = new TreeItem(mapID, Locale.getDefault() );
            //creating TreeItem object ... end


            if(mapID.getURL().equals(item.getURL()) ) {
                return Status.passed(apiTested + "Got 'id.url'");
            } else {
                return Status.failed(apiTested + "Did not get 'id.url': " + item.getURL() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

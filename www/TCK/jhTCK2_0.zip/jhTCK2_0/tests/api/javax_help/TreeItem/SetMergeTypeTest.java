/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... TreeItem().setMergeType(mergeType) --> TreeItem().setMergeType(mergeType)
 * testCase2 ... TreeItem().setMergeType(mergeType) --> TreeItem().setMergeType(null)
 *
 * testCase3 ... TreeItem(name).setMergeType(mergeType) --> TreeItem(name).setMergeType(mergeType)
 * testCase4 ... TreeItem(name).setMergeType(mergeType) --> TreeItem(name).setMergeType(null)
 *
 * testCase5 ... TreeItem(id, locale).setMergeType(mergeType) --> TreeItem(id, locale).setMergeType(mergeType)
 * testCase6 ... TreeItem(id, locale).setMergeType(mergeType) --> TreeItem(id, locale).setMergeType(null)
 */

package javasoft.sqe.tests.api.javax.help.TreeItem;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;

import javax.help.Map.ID;
import javax.help.HelpSet;
import javax.help.TreeItem;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem ... setMergeType(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SetMergeTypeTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SetMergeTypeTest() {
    }

    public static void main(String argv[]) {
        SetMergeTypeTest test = new SetMergeTypeTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>setMergeType(java.lang.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> valid value
     */
    public Status testCase1() {
        String apiTested = "setMergeType(java.lang.String mergeType): "
            + "TestCase: '(new TreeItem()).setMergeType(mergeType)' "
            + "ExpectedResult: Set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem();
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = "mergetype";
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype.equals(item.getMergeType()) ) {
                return Status.passed(apiTested + "Set 'mergeType'");
            } else {
                return Status.failed(apiTested + "Did not set 'mergeType': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setMergeType(java.lang.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> <code>null</code> value
     */
    public Status testCase2() {
        String apiTested = "setMergeType(java.lang.String mergeType): "
            + "TestCase: '(new TreeItem()).setMergeType(null)' "
            + "ExpectedResult: Set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem();
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = null;
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype == item.getMergeType() ) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setMergeType(java.lsng.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> valid value
     */
    public Status testCase3() {
        String apiTested = "setMergeType(java.lsng.String mergeType): "
            + "TestCase: '(new TreeItem(name)).setMergeType(mergeType)' "
            + "ExpectedResult: Set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem("tree item");
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = "mergetype";
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype.equals(item.getMergeType()) ) {
                return Status.passed(apiTested + "Set 'mergeType'");
            } else {
                return Status.failed(apiTested + "Did not set 'mergeType': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setMergeType(java.lsng.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> <code>null</code> value
     */
    public Status testCase4() {
        String apiTested = "setMergeType(java.lsng.String mergeType): "
            + "TestCase: '(new TreeItem(name)).setMergeType(null)' "
            + "ExpectedResult: Set 'null' "
            + "ObtainedResult: ";

        try {
            //creating TreeItem object ... start
            TreeItem item = new TreeItem("tree item");
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = null;
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype == item.getMergeType() ) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setMergeType(java.lang.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> valid value
     */
    public Status testCase5() {
        String apiTested = "setMergeType(java.lang.String mergeType): "
            + "TestCase: '(new TreeItem(id, locale)).setMergeType(mergeType)' "
            + "ExpectedResult: Set 'mergeType' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            String id = "hol_intro";
            ID mapID  = ID.create(id, hs);
            //creating Map.ID object ... end

            //creating TreeItem object ... start
            TreeItem item = new TreeItem(mapID, Locale.getDefault() );
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = "mergetype";
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype.equals(item.getMergeType()) ) {
                return Status.passed(apiTested + "Set 'mergeType'");
            } else {
                return Status.failed(apiTested + "Did not set 'mergeType': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>setMergeType(java.lang.String mergeType)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>mergeType</code> <code>null</code> value
     */
    public Status testCase6() {
        String apiTested = "setMergeType(java.lang.String mergeType): "
            + "TestCase: '(new TreeItem(id, locale)).setMergeType(null)' "
            + "ExpectedResult: Set 'null' "
            + "ObtainedResult: ";

        try {
            //creating HelpSet object ... start
            ClassLoader cl = this.getClass().getClassLoader();
            URL hsurl      = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs     = new HelpSet(cl, hsurl);
            //creating HelpSet object ... end

            //creating Map.ID object ... start
            String id = "hol_intro";
            ID mapID  = ID.create(id, hs);
            //creating Map.ID object ... end

            //creating TreeItem object ... start
            TreeItem item = new TreeItem(mapID, Locale.getDefault() );
            //creating TreeItem object ... end

            //set merge type ... start
            String mergetype = null;
            item.setMergeType(mergetype);
            //set merge type ... end


            if(mergetype == item.getMergeType() ) {
                return Status.passed(apiTested + "Set 'null'");
            } else {
                return Status.failed(apiTested + "Did not set 'null': " + item.getMergeType() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * @(#)SetNameTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TreeItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TreeItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem
 *
 * @author Meena C
 */

public class SetNameTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SetNameTest() {
        
    }
    
    public static void main(String argv[]) {
        SetNameTest test = new SetNameTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
             
        String apiTested = ": TreeItem.setName(String name) : " 
        + "\nTestCase : Construct TreeItem and call setName with null " 
        + "\nExpected Result : Shd set name as null." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = null;
            treeItem.setName(name);
            String gotName = treeItem.getName();
            if(gotName == null) {
                return Status.passed(apiTested + "Set name as null." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            } else {
                return Status.failed(apiTested + "Did not set name as null." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = ": TreeItem.setName(String name) : " 
        + "\nTestCase : Construct TreeItem and call setName with a valid name " 
        + "\nExpected Result : Shd set the given name." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = "Testing";
            treeItem.setName(name);
            String gotName = treeItem.getName();
            if(gotName.equals(name)) {
                return Status.passed(apiTested + "Set the given name." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            } else {
                return Status.failed(apiTested + "Did not set the given name." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = ": TreeItem.setName(String name) : " 
        + "\nTestCase : Construct TreeItem and call setName with a valid name " 
        + "\nExpected Result : Shd set the given name." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = "*#.%&)@/+?123";
            treeItem.setName(name);
            String gotName = treeItem.getName();
            if(gotName.equals(name)) {
                return Status.passed(apiTested + "Set the given name." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            } else {
                return Status.failed(apiTested + "Did not set the given name." 
                	+ "\nGiven name : " + name + "\nGot name : " 
                	+ gotName + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
 * @(#)ToStringTest.java	1.2 01/08/07
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES. 
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.TreeItem;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.Map.ID;
import javax.help.TreeItem;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TreeItem
 *
 * @author Meena C
 */

public class ToStringTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public ToStringTest() {
        
    }
    
    public static void main(String argv[]) {
        ToStringTest test = new ToStringTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        		new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = " : TreeItem.toString() : " 
        + "\nTestCase : Construct TreeItem object and call toString() " 
        + "without setting name. " 
        + "\nExpected Result : Shd get the expected String." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String str = treeItem.toString();
            String checkStr = mapID + "(" + treeItem.getName() + ")";
            if(checkStr.equals(str)) {
                return Status.passed(apiTested + "Got the expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            } else {
                return Status.failed(apiTested + "Did not get expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = " : TreeItem.toString() : " 
        	+ "\nTestCase : Construct TreeItem object and call toString() " 
        	+ "after setting name. " 
        	+ "\nExpected Result : Shd get the expected String." 
        	+ "\nObtained Result : ";
        	
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = ID.create(id, hs);
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = "Testing";
            treeItem.setName(name);
            String str = treeItem.toString();
            String checkStr = mapID + "(" + treeItem.getName() + ")";
            if(checkStr.equals(str)) {
                return Status.passed(apiTested + "Got the expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            } else {
                return Status.failed(apiTested + "Did not get expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = " : TreeItem.toString() : " 
        + "\nTestCase : Construct TreeItem object with ID as null and " 
        + "call toString() after setting name. " 
        + "\nExpected Result : Shd get the expected String." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = null;
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = "*#.%&+?123";
            treeItem.setName(name);
            String str = treeItem.toString();
            String checkStr = mapID + "(" + treeItem.getName() + ")";
            if(checkStr.equals(str)) {
                return Status.passed(apiTested + "Got the expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            } else {
                return Status.failed(apiTested + "Did not get expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = " : TreeItem.toString() : " 
        + "\nTestCase : Construct TreeItem object with ID as null and " 
        + "call toString() and without setting name. " 
        + "\nExpected Result : Shd get the expected String." 
        + "\nObtained Result : ";
        
        try {
            ClassLoader cl = this.getClass().getClassLoader();
            URL url = new URL("file", null, HSLOC+"/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(cl, url);
            String id = "hol_intro";
            ID mapID = null;
            Locale locale = Locale.getDefault();
            TreeItem treeItem = new TreeItem(mapID, locale);
            String name = "*#.%&)+?123";
            String str = treeItem.toString();
            String checkStr = mapID + "(" + treeItem.getName() + ")";
            if(checkStr.equals(str)) {
                return Status.passed(apiTested + "Got the expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            } else {
                return Status.failed(apiTested + "Did not get expected string." 
                	+ "\nExpected Str : " + checkStr + "\nGot str : " 
                	+ str + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}


/*
* 
* 
* @(#)GetAllIDsTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TryMap;

import java.io.PrintWriter;
import java.net.URL;
import java.util.Enumeration;
import javax.help.HelpSet;
import javax.help.TryMap;
import javax.help.Map;
import javax.help.FlatMap;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TryMap
 *
 
 * @author Ben John.
 */

public class GetAllIDsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetAllIDsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetAllIDsTest test = new GetAllIDsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
			    new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getAllIDs()\" ";
        ClassLoader loader = this.getClass().getClassLoader();
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	    URL urlmap = new URL("file", null, HSLOC + "/holidays/Map.jhm");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm1 = new FlatMap(new URL("file", null, HSLOC 
					       + "/holidays/Map.jhm"), hs);
            TryMap try1 = new TryMap();
            try1.add(tfm1);
	    String idarr[]={"players","trial","sanhedrin","1thanksproc"
			    ,"easter","aprilfools" ,"augustus", "creche" ,"handle",
			    "santa","stpatty","jeru3","jeru2","jeru1","ides", "goodfri",
			    "gwthanksproc","althanksproc","jackolantern","music","date",
			    "halloween","fathers", "rosh","herod","onlove","hol_intro",
			    "july4","reformation","yom","season","passover","stlucia",
			    "memorial","tree","climate", "year","cinco","magi",
			    "fawkes","chanukah","herod2","ashwed","mluther","poinsettia",
			    "thanksgiving","pilate", "traditions","palmsun","visit",
			    "toplevelfolder","star","valentine", "easter_history",
	                    "hist_figures"};
	    boolean mastercheck = true;
	    Enumeration enum = try1.getAllIDs();
	    while (enum.hasMoreElements()) {
		Map.ID mid = (Map.ID) enum.nextElement();
		String ss = (String) mid.id;
		boolean check = false;
		for (int i=0; i < idarr.length; i++) {
		    if (ss.equals(idarr[i])) {
			check = true;
			break;
		    }
		}
		if (!check) {
		    mastercheck = false;
		}
	    }
            if(mastercheck) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return Valid " 
				     + "Enumeration object with proper IDs'");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    }
}

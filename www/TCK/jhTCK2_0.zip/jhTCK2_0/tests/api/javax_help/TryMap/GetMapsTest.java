
/*
* 
* 
* @(#)GetMapsTest.java	1.3 01/08/06 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TryMap;

import java.io.PrintWriter;
import java.net.URL;
import javax.help.TryMap;
import javax.help.FlatMap;
import javax.help.*;
import javax.help.HelpSet;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TryMap
 *
 
 * @author Ben John.
 */

public class GetMapsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetMapsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetMapsTest test = new GetMapsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getMaps()\" ";
        ClassLoader loader = this.getClass().getClassLoader();
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            FlatMap tfm1 = new FlatMap(new URL("file", null, HSLOC 
                           + "/holidays/Map.jhm"), hs);
            FlatMap tfm2 = new FlatMap(new URL("file", null, HSLOC 
                           + "/holidays/Map.jhm"), hs);
            TryMap try1 = new TryMap();
            try1.add(tfm1);
            try1.add(tfm2);
            boolean check = false;
            java.util.Enumeration enum = try1.getMaps();
            if(enum.nextElement() == tfm1) {
                check = true;
            }
            else {
                check = false;
                return Status.failed(apiTested + "Did not valid ");
            }
            if(enum.nextElement() == tfm2) {
                check = true;
            }
            else {
                check = false;
                return Status.failed(apiTested + "Did not valid ");
            }
            if(check == true) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not valid ");
            }
        }
        catch(Exception exyz) {
            exyz.printStackTrace();
            return Status.failed(apiTested + "Exception raised" + exyz);
        }
    }
}

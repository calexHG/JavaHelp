
/*
* 
* 
* @(#)IsIDTest.java	1.5 03/07/08 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.TryMap;

import java.io.PrintWriter;
import java.net.URL;
import javax.help.HelpSet;
import javax.help.TryMap;
import javax.help.Map;
import javax.help.FlatMap;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.TryMap
 *
 
 * @author Ben John.
 */

public class IsIDTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public IsIDTest() {
        
    }
    
    public static void main(String argv[]) {
        IsIDTest test = new IsIDTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" isID()\" ";
        ClassLoader loader = this.getClass().getClassLoader();
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
	    URL mapURL = new URL("file", null, HSLOC + "/holidays/Map.jhm");
            URL uu = new URL(mapURL, "hol/hol.html");
            HelpSet hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            FlatMap tfm1 = new FlatMap(mapURL, hs);
            TryMap try1 = new TryMap();
            try1.add(tfm1);
            if(try1.isID(uu) == true) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not return true");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    } 
    
    public Status testCase2() {
        String apiTested = "Method \" isID()\" ";
        ClassLoader loader = this.getClass().getClassLoader();
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            URL uu = new URL("file", null, HSLOC + "/holidays/hol/aa.html");
            HelpSet hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            FlatMap tfm1 = new FlatMap(new URL("file", null, HSLOC 
                           + "/holidays/Map.jhm"), hs);
            TryMap try1 = new TryMap();
            try1.add(tfm1);
            if(try1.isID(uu) == false) {
                return Status.passed(apiTested + "Okay Returns False " 
                + "for Invalid URL");
            }
            else {
                return Status.failed(apiTested + "Did not return false " 
                + "for Invalid URL");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \" isID()\" ";
        ClassLoader loader = this.getClass().getClassLoader();
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs");
            HelpSet hs = new HelpSet(loader, url);
            Map.ID mid = Map.ID.create("hol_intro", hs);
            FlatMap tfm1 = new FlatMap(new URL("file", null, HSLOC 
                           + "/holidays/Map.jhm"), hs);
            TryMap try1 = new TryMap();
            try1.add(tfm1);
            if(try1.isID(null) == false) {
                return Status.passed(apiTested + "Returns False for null URL,");
            }
            else {
                return Status.failed(apiTested + "Did not return false " 
                + "for Null URL.");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception Raised:" + ee);
        }
    }
}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... UniteAppendMerge(master, slave).processMerge(node) --> UniteAppendMerge(master, slave).processMerge(null)
 */

package javasoft.sqe.tests.api.javax.help.UniteAppendMerge;

import java.io.PrintWriter;

import java.net.URL;

import javax.help.HelpSet;
import javax.help.TOCView;
import javax.help.UniteAppendMerge;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.UniteAppendMerge ... processMerge(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class ProcessMergeTest0 extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public ProcessMergeTest0() {
    }

    public static void main(String argv[]) {
        ProcessMergeTest0 test = new ProcessMergeTest0();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.swing.tree.TreeNode processMerge(javax.swing.tree.TreeNode node)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>node</code> <code>null</code> value
     */
    public Status testCase1() {
        String apiTested = "javax.swing.tree.TreeNode processMerge(javax.swing.tree.TreeNode node): "
            + "TestCase: (new UniteAppendMerge(master, slave)).processMerge(null) "
            + "ExpectedResult: 'java.lang.NullPointerException' "
            + "ObtainedResult: ";

        try {
            //create HelpSet objects ... start
            HelpSet hsmaster = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/vertebrates/Vertebrates.hs") );
            HelpSet hsslave  = new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/newmerge/invertebrates/Invertebrates.hs") );
            //create HelpSet objects ... end

            //get TOCView objects ... start
            TOCView tocviewmaster = (TOCView)hsmaster.getNavigatorView("TOC");
            TOCView tocviewslave  = (TOCView)hsslave.getNavigatorView("TOC");
            //get TOCView objects ... end

            //create a UniteAppendMerge object ... start
            UniteAppendMerge uniteappendmerge = new UniteAppendMerge(tocviewmaster, tocviewslave);
            //create a UniteAppendMerge object ... end

            //call processMerge method ... start
            uniteappendmerge.processMerge(null);
            //call processMerge method ... end


            return Status.failed(apiTested + "Did not get 'java.lang.NullPointerException'");
        } catch (NullPointerException exc) {
            return Status.passed(apiTested + "Got 'java.lang.NullPointerException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

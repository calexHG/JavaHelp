
/*
* 
* 
* @(#)USOExceptionTest.java	1.2 99/03/01 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.UnsupportedOperationException;

import java.io.PrintWriter;
import java.net.URL;
import javax.help.UnsupportedOperationException;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.UnsupportedOperationException
 *
 
 * @author Ben John.
 */

public class USOExceptionTest extends MultiTest {
    
    public USOExceptionTest() {
        
    }
    
    public static void main(String argv[]) {
        USOExceptionTest test = new USOExceptionTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \"UnsupportedOperationException() \" ";
        try {
            throw new UnsupportedOperationException();
        }
        catch(UnsupportedOperationException uoe) {
            if(uoe instanceof UnsupportedOperationException) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct default " + "UnsupportedOperationException object");
            }
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method: UnsupportedOperationException(String s)";
        try {
            throw new UnsupportedOperationException("StringMessage");
        }
        catch(UnsupportedOperationException uoe) {
            if(uoe instanceof UnsupportedOperationException) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct default " + "UnsupportedOperationException object with message " + "parameter");
            }
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method: UnsupportedOperationException(String s)";
        try {
            throw new UnsupportedOperationException(null);
        }
        catch(UnsupportedOperationException uoe) {
            if(uoe instanceof UnsupportedOperationException) {
                return Status.passed(apiTested + "Okay ; even argument is null");
            }
            else {
                return Status.failed(apiTested + "Did not Construct default " + "UnsupportedOperationException object with null parameter");
            }
        }
    }
}

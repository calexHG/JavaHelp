
/*
* @(#)GetStopWordsTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.search.ConfigFile;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.search.ConfigFile;
import java.util.Locale;
import java.util.Vector;
import java.util.Enumeration;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.ConfigFile
 * Method getStopWords() Test 
 *
 * @author Sudhakar.Adini
 */

public class GetStopWordsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetStopWordsTest() {
        
    }
    
    public static void main(String argv[]) {
        GetStopWordsTest test = new GetStopWordsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Constructor: getStopWords()" 
            + "\nTestCase : Call getStopWords() " 
            + "\nExpected Result :It should return the stopwords  " 
            + "\nObtained Result : ";
        
        try {
            
            String configFile = HSLOC + "/holidays/Config.txt";
            Vector files = new Vector();
            boolean noStopWords = false;
            boolean check=false;
            String words[]={"popular","customs", "influence",
			"mixture", "sacred", "secular"};                                                  
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            Enumeration en = con.getStopWords();
            while(en.hasMoreElements()) {
                String word = (String)en.nextElement();
                for (int i=0; i < words.length ; i++)
                    if (word.equals(words[i])) {
                        check = true;
                        break;
                    }
            }
            if(check) {
                return Status.passed(apiTested + "Okay ");
            } else {
                return Status.failed(apiTested + "Did not return stopwords");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 


    public Status testCase2() {
        String apiTested = " Constructor: getStopWords()" 
        + "\nTestCase : Call getStopWords() " 
        + "\nExpected Result :It should return the empty Enumeration" 
        + "\nObtained Result : ";
        
        try {
            
            String configFile = HSLOC + "/holidays/Config1.txt";
            Vector files = new Vector();
            boolean noStopWords = true;
			boolean check=false;
			String words[]={"holidays","secular","unaware"};							
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            Enumeration en = con.getStopWords();
            if(en.hasMoreElements()) {			
            check=true;
			}
			if(!check)
               	return Status.passed(apiTested + "Okay ");
			else
				return Status.failed(apiTested + "Failed");         
           
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
}


/*
* @(#)GetURLStringTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/

package javasoft.sqe.tests.api.javax.help.search.ConfigFile;
import javax.help.HelpSet;
import javax.help.JHelp;
import javax.swing.JComponent;
import javax.help.DefaultHelpModel;
import javax.help.search.ConfigFile;
import java.util.Locale;
import java.util.Vector;
import java.util.Enumeration;
import java.net.URL;
import java.io.PrintWriter;
import java.util.Hashtable;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;


/**
 * Tests for javax.help.search.ConfigFile
 * Method getURLString(String file) Test
 *
 * @author Sudhakar.Adini
 */

public class GetURLStringTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetURLStringTest() {
        
    }
    
    public static void main(String argv[]) {
        GetURLStringTest test = new GetURLStringTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = " Method: getURLString(String file)" 
        + "\nTestCase : Call getURLString() without IndexRemove " 
        + "\nExpected Result :It return  filename of a file in String format " 
        + "\nObtained Result : ";
        try {
            
            String configFile = HSLOC + "/holidays/Config.txt";
            Vector files = new Vector();
            boolean noStopWords = false;
            String file = "hol.html";
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            String file1 = con.getURLString(file);            
            if(file1.equals(file)) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested + "failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
    
    public Status testCase2() {
        String apiTested = " Method: getURLString(String file)" 
        + "\nTestCase : Call getURLString() with IndexRemove" 
        + "\nExpected Result:It return url filename of a file in String format" 
        + "\nObtained Result : ";
        try {
            
            String configFile = HSLOC + "/holidays/Config.txt";
            Vector files = new Vector();
            boolean noStopWords = false;
            String file = 
             "c:/ws_javahelp/javahelp/src/javahelp/hs/holidays/hol/hall.html";
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            String file1 = con.getURLString(file);            
            if(file1.equals("/javahelp/hs/holidays/hol/hall.html")) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested + "failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } 
    
    public Status testCase3() {
        String apiTested = " Method: getURLString(String file)" 
        + "\nTestCase : Call getURLString() with IndexPrepend" 
        + "\nExpected Result:It return url filename of a file in String format" 
        + "\nObtained Result : ";
        try {
            
            String configFile = HSLOC + "/holidays/Config1.txt";
            Vector files = new Vector();
            boolean noStopWords = false;
            String file = 
             "javahelp/hs/holidays/hol/hol.html";
			String file2 = 
            "c:/ws_javahelp/javahelp/src/javahelp/hs/holidays/hol/hol.html"; 
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            String file1 = con.getURLString(file);			
            if(file1.equals(file2)) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested + "failed");
            }
        }
        catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e.toString());
        }
    } 	
	
    public Status testCase4() {
        String apiTested = " Method: getURLString(String file)" 
        + "\nTestCase : Call getURLString() by passing null for file" 
        + "\nExpected Result :It should throw the NullPointerException  " 
        + "\nObtained Result : ";
        try {
            
            String configFile = HSLOC + "/holidays/Config.txt";
            Vector files = new Vector();
            boolean noStopWords = false;
            String file = null; //"hol.html";							
            ConfigFile con = new ConfigFile(configFile, files, noStopWords);
            String file1 = con.getURLString(file);			
            if(file1 == null) {
                return Status.passed(apiTested + "okay");
            }
            else {
                return Status.failed(apiTested + "failed");
            }
        }
        catch(Exception e) {
        if(e instanceof NullPointerException)
        return Status.passed(apiTested + "Got Exception: " + e.toString());
        else 	
         return Status.failed(apiTested + "Got Exception: " + e.toString());
        }
    } 
}

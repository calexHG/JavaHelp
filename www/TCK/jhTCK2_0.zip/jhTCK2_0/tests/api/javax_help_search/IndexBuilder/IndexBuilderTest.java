
/*
* @(#)IndexBuilderTest.java	1.1 99/03/02
* 
* Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.search.IndexBuilder;
import javax.help.search.IndexBuilder;
import javax.help.search.SearchQuery;
import javax.help.HelpSet;
import javax.help.Map;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import java.io.File;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.IndexBuilder;
 
 * @author Sudhakar.Adini
 */

class MyIndexBuilder extends IndexBuilder {
    
    public MyIndexBuilder(java.lang.String indexDir) throws Exception {
        super(indexDir);
    }
    
    public void close() throws Exception {
        
    }
    
    public void storeStopWords(java.util.Enumeration stopWords) {
        
    }
    
    public java.util.Enumeration getStopWords() {
        return null;
    }
    
    public void openDocument(java.lang.String name) throws Exception {
        
    }
    
    public void closeDocument() throws Exception {
        
    }
    
    public void storeLocation(java.lang.String text, int position) 
        throws Exception {
        
    }
    
    public void storeTitle(java.lang.String title) throws Exception {
        
    }
}

public class IndexBuilderTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    File file;
    public IndexBuilderTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        IndexBuilderTest test = new IndexBuilderTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
         	 	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Constructor:IndexBuilder(java.lang.String indexDir)" 
        + "\nTestCase :IndexBuilder(java.lang.String indexDir) " 
        + "\nExpected Result :It should construct the  IndexBuilder object " 
        + "\nObtained Result : ";
        try {            
            MyIndexBuilder index =null;
            file = new File("IndexBuilder");
            if(!file.exists())
            	index = new MyIndexBuilder("IndexBuilder");            	          
            if(file.isDirectory() && index instanceof IndexBuilder) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested+"Not Constructed valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
        finally{
            if(file.exists())
            file.delete();
            }	
    } //testCase1 finished
    
    public Status testCase2() {
        String apiTested = "Constructor:IndexBuilder(java.lang.String indexDir)" 
        + "\nTestCase :IndexBuilder(null) " 
        + "\nExpected Result :It should throw the NullPointerException " 
        + "\nObtained Result : ";
        try {
            MyIndexBuilder index = new MyIndexBuilder(null);
            if(index instanceof IndexBuilder) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested+"Not Constructed valid object");
            }
        }
        catch(Exception ee) {
            if(ee instanceof NullPointerException) {
                return Status.passed(apiTested + "Got NullPointerException");
            }
            else {
                return Status.failed(apiTested + "Got otherexception : " 
                + ee.toString());
            }
        }
    } 
}

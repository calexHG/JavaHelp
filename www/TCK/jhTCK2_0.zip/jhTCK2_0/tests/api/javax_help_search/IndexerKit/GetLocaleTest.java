/*
 * @(#)GetLocaleTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.search.IndexerKit;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.search.IndexerKit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import com.sun.help.jck.harness.TestIndexerKit;

/**
 * Tests for javax.help.search.IndexerKit
 *
 * @author Meena C
 */

public class GetLocaleTest extends MultiTest {
    
    public GetLocaleTest() {
        
    }
    
    public static void main(String argv[]) {
        GetLocaleTest test = new GetLocaleTest();
        Status s = test.run(argv, new PrintWriter(System.out),
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "getLocale() : " 
        + "\nTestCase : Constuct TestIndexerKit and call getLocale after " 
        + "setting a Locale " 
        + "\nExpected Result : Shd return the given Locale " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            Locale locale = new Locale("fr", "FR");
            indexerKit.setLocale(locale);
            Locale gotLocale = indexerKit.getLocale();
            if(locale.equals(gotLocale)) {
                return Status.passed(apiTested + "Got the given Locale." 
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get the given Locale" 
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "getLocale() : " 
        + "\nTestCase : Constuct TestIndexerKit and call getLocale without " 
        + "setting a Locale " 
        + "\nExpected Result : Shd return  null Locale " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            Locale gotLocale = indexerKit.getLocale();
            if(gotLocale == null) {
                return Status.passed(apiTested + "Got  null Locale.\n");
            } else {
                return Status.failed(apiTested + "Did not get null Locale\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

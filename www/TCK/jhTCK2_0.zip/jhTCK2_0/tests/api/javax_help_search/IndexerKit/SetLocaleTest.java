/*
 * @(#)SetLocaleTest.java	1.1 99/03/02
 * 
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * CopyrightVersion 1.0
 */
package javasoft.sqe.tests.api.javax.help.search.IndexerKit;
import java.io.PrintWriter;
import java.util.Locale;
import javax.help.search.IndexerKit;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import com.sun.help.jck.harness.TestIndexerKit;

/**
 * Tests for javax.help.search.IndexerKit
 *
 * @author Meena C
 */

public class SetLocaleTest extends MultiTest {
    
    public SetLocaleTest() {
        
    }
    
    public static void main(String argv[]) {
        SetLocaleTest test = new SetLocaleTest();
        Status s = test.run(argv, new PrintWriter(System.out) ,
        	new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
    	
        String apiTested = "setLocale(Locale locale) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with " 
        + "valid locale " 
        + "\nExpected Result : Shd set the given Locale " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            Locale locale = Locale.JAPANESE;
            indexerKit.setLocale(locale);
            Locale gotLocale = indexerKit.getLocale();
            if(locale.equals(gotLocale)) {
                return Status.passed(apiTested + "Set the given Locale." 
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not set the given Locale"  
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase2() {
    	
        String apiTested = "setLocale(Locale locale) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with " 
        + "null locale " 
        + "\nExpected Result : Shd set the null Locale " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            Locale locale = null;
            indexerKit.setLocale(locale);
            Locale gotLocale = indexerKit.getLocale();
            if(locale == gotLocale) {
                return Status.passed(apiTested + "Set the null Locale." 
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            } else {
                return Status.failed(apiTested + "Did not set the null Locale." 
                	+ "\nGiven Locale = " + locale + " , Got Locale = " 
                	+ gotLocale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase3() {
    	
        String apiTested = "setLocale(String lang) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with " 
        + "only language spec.d" 
        + "\nExpected Result : Shd set  Locale object with given lang" 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            String lang = "fr";
            indexerKit.setLocale(lang);
            Locale locale = indexerKit.getLocale();
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("") && 
               gotVar.equals("")) {
                return Status.passed(apiTested + "Got the  Locale." 
                	+ " \nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get the spec.d Locale" 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase4() {
    	
        String apiTested = "setLocale(String lang) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with "
        + "language and country spec.d" 
        + "\nExpected Result : Shd set Locale object with given lang & country" 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            String lang = "fr_FR";
            indexerKit.setLocale(lang);
            Locale locale = indexerKit.getLocale();
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("FR") &&
               gotVar.equals("")) {
                return Status.passed(apiTested + "Got the  Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get spec.d Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase5() {
    	
        String apiTested = "setLocale(String lang) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with " 
        + "language,country,variant spec.d" 
        + "\nExpected Result : Shd set  Locale object with given lang ," 
        + " country and variant " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            String lang = "fr_FR_WIN";
            indexerKit.setLocale(lang);
            Locale locale = indexerKit.getLocale();
            String gotLang = locale.getLanguage();
            String gotCtry = locale.getCountry();
            String gotVar = locale.getVariant();
            if(gotLang.equals("fr") && gotCtry.equals("FR") && 
               gotVar.equals("WIN")) {
                return Status.passed(apiTested + "Got the  Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not get same Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
    
    public Status testCase6() {
    	
        String apiTested = "setLocale(String lang) : " 
        + "\nTestCase : Constuct TestIndexerKit and call setLocale with " 
        + "null lang" 
        + "\nExpected Result : Shd set null Locale object " 
        + "\nObtained Result : ";
        
        try {
            TestIndexerKit indexerKit = new TestIndexerKit();
            String lang = null;
            indexerKit.setLocale(lang);
            Locale locale = indexerKit.getLocale();
            if(locale == null) {
                return Status.passed(apiTested + "Set the null Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            } else {
                return Status.failed(apiTested + "Did not set the null Locale." 
                	+ "\nGiven lang = " + lang + " , Got Locale = " 
                	+ locale + "\n");
            }
        } catch(Exception e) {
            return Status.failed(apiTested + "Got Exception : " + e + "\n");
        }
    }
}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergingSearchEngine(view).createQuery() --> MergingSearchEngine(view).createQuery()
 *
 * testCase2 ... MergingSearchEngine(engine).createQuery() --> MergingSearchEngine(engine).createQuery()
 */

package javasoft.sqe.tests.api.javax.help.search.MergingSearchEngine;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;

import javax.help.HelpSet;
import javax.help.NavigatorView;

import javax.help.search.SearchQuery;
import javax.help.search.SearchEngine;
import javax.help.search.MergingSearchEngine;

import com.sun.java.help.search.DefaultSearchEngine;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.MergingSearchEngine ... createQuery()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class CreateQueryTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public CreateQueryTest() {
    }

    public static void main(String argv[]) {
        CreateQueryTest test = new CreateQueryTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>javax.help.search.SearchQuery createQuery()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "javax.help.search.SearchQuery createQuery(): "
            + "TestCase: '(new MergingSearchEngine(view)).createQuery()' "
            + "ExpectedResult: 'new SearchQuery object' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end

            Object query = engine.createQuery();


            if((query instanceof SearchQuery) && ((SearchEngine)engine).equals(((SearchQuery)query).getSearchEngine()) ) {
                return Status.passed(apiTested + "Got 'new SearchQuery object'");
            } else {
                return Status.failed(apiTested + "Did not get 'new SearchQuery object'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>javax.help.search.SearchQuery createQuery()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "javax.help.search.SearchQuery createQuery(): "
            + "TestCase: '(new MergingSearchEngine(engine)).createQuery()' "
            + "ExpectedResult: 'new SearchQuery object' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            SearchEngine searchengine = new DefaultSearchEngine(new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"), hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(searchengine);
            //create a MergingSearchEngine object ... end

            Object query = engine.createQuery();


            if((query instanceof SearchQuery) && ((SearchEngine)engine).equals(((SearchQuery)query).getSearchEngine()) ) {
                return Status.passed(apiTested + "Got 'new SearchQuery object'");
            } else {
                return Status.failed(apiTested + "Did not get 'new SearchQuery object'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

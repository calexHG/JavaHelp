/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergingSearchEngine(view) --> MergingSearchEngine(invalid)
 * testCase2 ... MergingSearchEngine(view) --> MergingSearchEngine(view)
 * testCase3 ... MergingSearchEngine(view) --> MergingSearchEngine(null)
 *
 * testCase4 ... MergingSearchEngine(engine) --> MergingSearchEngine(engine)
 * testCase5 ... MergingSearchEngine(engine) --> MergingSearchEngine(null)
 */

package javasoft.sqe.tests.api.javax.help.search.MergingSearchEngine;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;
import java.util.Enumeration;

import javax.help.HelpSet;
import javax.help.NavigatorView;

import javax.help.search.SearchEngine;
import javax.help.search.MergingSearchEngine;

import com.sun.java.help.search.DefaultSearchEngine;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.MergingSearchEngine ... MergingSearchEngine(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class MergingSearchEngineTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public MergingSearchEngineTest() {
    }

    public static void main(String argv[]) {
        MergingSearchEngineTest test = new MergingSearchEngineTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>MergingSearchEngineTest(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> invalid value
     */
    public Status testCase1() {
        String apiTested = "MergingSearchEngineTest(javax.help.NavigatorView view): "
            + "TestCase: Construct with: 'view == invalid' "
            + "ExpectedResult: MergingSearchEngine object with given value "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("mydata", "myview");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            Object engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end


            if (engine instanceof MergingSearchEngine) { //is instance of MergingSearchEngine class
                Enumeration enum = ((MergingSearchEngine)engine).getEngines();
                SearchEngine element = (SearchEngine)enum.nextElement();
                if (element == null) { //element with given parametters is null
                    return Status.passed(apiTested + "OK");
                } else { //element with given parametters is not null
                    return Status.failed(apiTested + "Did not add correct SearchEngine object to MergingSearchEngine object");
                }
            } else { //is not instance of MergingSearchEngine class
                return Status.failed(apiTested + "Did not construct MergingSearchEngine object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>MergingSearchEngineTest(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> valid value
     */
    public Status testCase2() {
        String apiTested = "MergingSearchEngineTest(javax.help.NavigatorView view): "
            + "TestCase: Construct with: 'view == valid' "
            + "ExpectedResult: MergingSearchEngine object with given value "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            Object engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end


            if (engine instanceof MergingSearchEngine) { //is instance of MergingSearchEngine class
                Enumeration enum = ((MergingSearchEngine)engine).getEngines();
                SearchEngine element = (SearchEngine)enum.nextElement();
                if (element != null && element instanceof com.sun.java.help.search.DefaultSearchEngine) { //element with given parametters is not null
                    return Status.passed(apiTested + "OK");
                } else { //element with given parametters is null
                    return Status.failed(apiTested + "Did not add correct SearchEngine object to MergingSearchEngine object");
                }
            } else { //is not instance of MergingSearchEngine class
                return Status.failed(apiTested + "Did not construct MergingSearchEngine object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>MergingSearchEngineTest(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "MergingSearchEngineTest(javax.help.NavigatorView view): "
            + "TestCase: Construct with: 'view == null' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            NavigatorView view = null;
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            Object engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch(IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>MergingSearchEngineTest(javax.help.search.SearchEngine engine)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>engine</code> valid value
     */
    public Status testCase4() {
        String apiTested = "MergingSearchEngineTest(javax.help.search.SearchEngine engine): "
            + "TestCase: Construct with: 'engine == valid' "
            + "ExpectedResult: MergingSearchEngine object with given value "
            + "ObtainedResult: ";

        try {
            //create a SearchEngine object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            SearchEngine engine = new DefaultSearchEngine(new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"), hashtable);
            //create a SearchEngine object ... end

            //create a MergingSearchEngine object ... start
            Object object = new MergingSearchEngine(engine);
            //create a MergingSearchEngine object ... end


            if (object instanceof MergingSearchEngine) { //is instance of MergingSearchEngine class
                Enumeration enum = ((MergingSearchEngine)object).getEngines();
                SearchEngine element = (SearchEngine)enum.nextElement();
                if (element != null && element instanceof com.sun.java.help.search.DefaultSearchEngine && element.equals(engine) ) { //element with given parametters is not null
                    return Status.passed(apiTested + "OK");
                } else { //element with given parametters is null
                    return Status.failed(apiTested + "Did not add correct SearchEngine object to MergingSearchEngine object");
                }
            } else { //is not instance of MergingSearchEngine class
                return Status.failed(apiTested + "Did not construct MergingSearchEngine object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>MergingSearchEngineTest(javax.help.search.SearchEngine engine)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>engine</code> <code>null</code> value
     */
    public Status testCase5() {
        String apiTested = "MergingSearchEngineTest(javax.help.search.SearchEngine engine): "
            + "TestCase: Construct with: 'engine == null' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a SearchEngine object ... start
            SearchEngine engine = null;
            //create a SearchEngine object ... end

            //create a MergingSearchEngine object ... start
            Object object = new MergingSearchEngine(engine);
            //create a MergingSearchEngine object ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch(IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

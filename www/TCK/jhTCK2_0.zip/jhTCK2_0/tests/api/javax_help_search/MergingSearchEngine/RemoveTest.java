/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... MergingSearchEngine(view).remove(view) --> MergingSearchEngine(view).remove(view)
 * testCase2 ... MergingSearchEngine(view).remove(view) --> MergingSearchEngine(view).remove(invalid)
 * testCase3 ... MergingSearchEngine(view).remove(view) --> MergingSearchEngine(view).remove(null)
 *
 * testCase4 ... MergingSearchEngine(engine).remove(view) --> MergingSearchEngine(engine).remove(view)
 * testCase5 ... MergingSearchEngine(engine).remove(view) --> MergingSearchEngine(engine).remove(invalid)
 * testCase6 ... MergingSearchEngine(engine).remove(view) --> MergingSearchEngine(engine).remove(null)
 */

package javasoft.sqe.tests.api.javax.help.search.MergingSearchEngine;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Hashtable;
import java.util.Enumeration;

import javax.help.HelpSet;
import javax.help.NavigatorView;

import javax.help.search.SearchEngine;
import javax.help.search.MergingSearchEngine;

import com.sun.java.help.search.DefaultSearchEngine;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.MergingSearchEngine ... remove(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class RemoveTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public RemoveTest() {
    }

    public static void main(String argv[]) {
        RemoveTest test = new RemoveTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> valid value
     */
    public Status testCase1() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(view)).remove(view)' "
            + "ExpectedResult: Remove 'view' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView mergeview = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //merge new view ... start
            engine.merge(mergeview);
            //merge new view ... end

            //remove the mergeview ... start
            engine.remove(mergeview);
            //remove the mergeview ... end


            //create an Enumeration of the engines ... start
            Enumeration enum = engine.getEngines();
            //create an Enumeration of the engines ... end

            if ((enum.nextElement() instanceof com.sun.java.help.search.DefaultSearchEngine) && !enum.hasMoreElements() ) {
                return Status.passed(apiTested + "Removed 'view'");
            } else {
                return Status.failed(apiTested + "Did not remove 'view'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> invalid value
     */
    public Status testCase2() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(view)).remove(invalid)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            hashtable = new Hashtable();
            hashtable.put("mydata", "myview");
            NavigatorView removeview = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //remove the removeview ... start
            engine.remove(removeview);
            //remove the removeview ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> <code>null</code> value
     */
    public Status testCase3() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(view)).remove(null)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView view = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC", "Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(view);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            NavigatorView removeview = null;
            //create a NavigatorView object ... end

            //remove the removeview ... start
            engine.remove(removeview);
            //remove the removeview ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> valid value
     */
    public Status testCase4() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(engine)).remove(view)' "
            + "ExpectedResult: Remove 'view' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            SearchEngine searchengine = new DefaultSearchEngine(new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"), hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(searchengine);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            NavigatorView mergeview = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //merge new view ... start
            engine.merge(mergeview);
            //merge new view ... end

            //remove the mergeview ... start
            engine.remove(mergeview);
            //remove the mergeview ... end


            //create an Enumeration of the engines ... start
            Enumeration enum = engine.getEngines();
            //create an Enumeration of the engines ... end

            if ((enum.nextElement() instanceof com.sun.java.help.search.DefaultSearchEngine) && !enum.hasMoreElements() ) {
                return Status.passed(apiTested + "Removed 'view'");
            } else {
                return Status.failed(apiTested + "Did not remove 'view'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> invalid value
     */
    public Status testCase5() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(engine)).remove(invalid)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            SearchEngine searchengine = new DefaultSearchEngine(new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"), hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(searchengine);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            hashtable = new Hashtable();
            hashtable.put("mydata", "myview");
            NavigatorView removeview = NavigatorView.create(new HelpSet(this.getClass().getClassLoader(), new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs")), "TOC2", "Jewish Holidays", Locale.getDefault(), "javax.help.TOCView", hashtable);
            //create a NavigatorView object ... end

            //remove the removeview ... start
            engine.remove(removeview);
            //remove the removeview ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>void remove(javax.help.NavigatorView view)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>view</code> <code>null</code> value
     */
    public Status testCase6() {
        String apiTested = "void remove(javax.help.NavigatorView view): "
            + "TestCase: '(new MergingSearchEngine(engine)).remove(null)' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //create a NavigatorView object ... start
            Hashtable hashtable = new Hashtable();
            hashtable.put("data", "JavaHelpSearch");
            SearchEngine searchengine = new DefaultSearchEngine(new URL("file", null, HSLOC + "/holidays/HolidayHistory.hs"), hashtable);
            //create a NavigatorView object ... end

            //create a MergingSearchEngine object ... start
            MergingSearchEngine engine = new MergingSearchEngine(searchengine);
            //create a MergingSearchEngine object ... end

            //create a NavigatorView object ... start
            NavigatorView removeview = null;
            //create a NavigatorView object ... end

            //remove the removeview ... start
            engine.remove(removeview);
            //remove the removeview ... end


            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

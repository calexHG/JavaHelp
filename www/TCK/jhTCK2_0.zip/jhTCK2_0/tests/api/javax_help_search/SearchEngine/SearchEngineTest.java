
/*
* 
* 
* @(#)SearchEngineTest.java	1.2 01/08/07 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.search.SearchEngine;

import javax.help.search.SearchEngine;
import javax.help.search.SearchQuery;
import javax.help.HelpSet;
import javax.help.Map;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchEngine;
 
 * @author ChellaKumaran
 */

class MySearchEngine extends SearchEngine {
    
    public MySearchEngine() {
        super();
    }
    
    public MySearchEngine(java.net.URL base1, java.util.Hashtable params1) {
        super(base1, params1);
    }
    
    public javax.help.search.SearchQuery createQuery() 
    throws IllegalStateException {
        return null;
    }
}

public class SearchEngineTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SearchEngineTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        SearchEngineTest test = new SearchEngineTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" SearchEngine()  \" ";
        try {
            MySearchEngine searchEngine = new MySearchEngine();
            if(searchEngine instanceof MySearchEngine) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" SearchEngine(java.net.URL base,"
                           + " java.util.Hashtable params)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            MySearchEngine searchEngine = new MySearchEngine(url, htab);
            if(searchEngine instanceof MySearchEngine) {
                return Status.passed(apiTested + "Okay for valid parameters");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for valid parameters" + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \" SearchEngine(java.net.URL base, "
                           + " java.util.Hashtable params)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            MySearchEngine searchEngine = new MySearchEngine(null, htab);
            if(searchEngine instanceof MySearchEngine) {
                return Status.passed(apiTested + "Okay for null url parameter");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested 
            + "Exception raised for null URL parameter" + ee);
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method \" SearchEngine(java.net.URL base, "
                           + " java.util.Hashtable params)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Hashtable htab = new Hashtable();
            htab.put("data", "HolidayTOC.xml");
            MySearchEngine searchEngine = new MySearchEngine(url, null);
            if(searchEngine instanceof MySearchEngine) {
                return Status.passed(apiTested 
                + "Okay for null HashTable parameter");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid object for null HashTable");
            }
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested 
            + "Exception raised for null HashTable parameter" + ee);
        }
    }
}

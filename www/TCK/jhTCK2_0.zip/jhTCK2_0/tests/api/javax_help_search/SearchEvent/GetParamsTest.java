/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SearchEvent(source, params, searching).getParams() --> SearchEvent(source, params, true).getParams()
 *
 * testCase2 ... SearchEvent(source, params, searching, items).getParams() --> SearchEvent(source, params, true, items).getParams()
 */

package javasoft.sqe.tests.api.javax.help.search.SearchEvent;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Vector;

import javax.help.search.SearchItem;
import javax.help.search.SearchEvent;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchEvent ... getParams()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetParamsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetParamsTest() {
    }

    public static void main(String argv[]) {
        GetParamsTest test = new GetParamsTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.lang.String getParams()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.lang.String getParams(): "
            + "TestCase: '(new SearchEvent(source, params, false)).getParams()' "
            + "ExpectedResult: 'params' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if (params.equals(searchEvent.getParams()) ) {
                return Status.passed(apiTested + "Got 'params'");
            } else {
                return Status.failed(apiTested + "Did not get 'params':" + searchEvent.getParams() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.lang.String getParams()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "java.lang.String getParams(): "
            + "TestCase: '(new SearchEvent(source, params, true, items)).getParams()' "
            + "ExpectedResult: 'params' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            if (params.equals(searchEvent.getParams()) ) {
                return Status.passed(apiTested + "Got 'params'");
            } else {
                return Status.failed(apiTested + "Did not get 'params': " + searchEvent.getParams() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


}

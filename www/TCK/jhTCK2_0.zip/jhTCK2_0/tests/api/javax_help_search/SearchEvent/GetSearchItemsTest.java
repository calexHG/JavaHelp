/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SearchEvent(source, params, searching).getSearchItems() --> SearchEvent(source, params, true).getSearchItems()
 *
 * testCase2 ... SearchEvent(source, params, searching, items).getSearchItems() --> SearchEvent(source, params, false, items).getSearchItems()
 */

package javasoft.sqe.tests.api.javax.help.search.SearchEvent;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Vector;
import java.util.Enumeration;

import javax.help.search.SearchItem;
import javax.help.search.SearchEvent;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchEvent ... getSearchItems()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class GetSearchItemsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public GetSearchItemsTest() {
    }

    public static void main(String argv[]) {
        GetSearchItemsTest test = new GetSearchItemsTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>java.util.Enumeration getSearchItems()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "java.util.Enumeration getSearchItems(): "
            + "TestCase: '(new SearchEvent(source, params, true)).getSearchItems()' "
            + "ExpectedResult: 'null' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if (searchEvent.getSearchItems() == null) {
                return Status.passed(apiTested + "Got 'null'");
            } else {
                return Status.failed(apiTested + "Did not get 'null' " + searchEvent.getSearchItems() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>java.util.Enumeration getSearchItems()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "java.util.Enumeration getSearchItems(): "
            + "TestCase: '(new SearchEvent(source, params, false, items)).getSearchItems()' "
            + "ExpectedResult: 'items' enumeration "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            //check the returned Enumeration ... end
            boolean check = true;
            Enumeration enum = searchEvent.getSearchItems();
            int vectorsize = items.size();
            for (int i = 0 ; (i < items.size()) && enum.hasMoreElements() && check ; i++, vectorsize--) {
                SearchItem item = (SearchItem)enum.nextElement();
                if (!item.equals((SearchItem)items.elementAt(i)) ) {
                    check = false;
                }
            }
            if (check && (vectorsize != 0 || enum.hasMoreElements()) ) {
                check = false;
            }
            //check the returned Enumeration ... end

            if (check) {
                return Status.passed(apiTested + "Got 'items' enumeration");
            } else {
                return Status.failed(apiTested + "Did not get 'items' enumeration");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SearchEvent(source, params, searching).isSearchCompleted() --> SearchEvent(source, params, false).isSearchCompleted()
 * testCase2 ... SearchEvent(source, params, searching).isSearchCompleted() --> SearchEvent(source, params, true).isSearchCompleted()
 *
 * testCase3 ... SearchEvent(source, params, searching, items).isSearchCompleted() --> SearchEvent(source, params, true, items).isSearchCompleted()
 * testCase4 ... SearchEvent(source, params, searching, items).isSearchCompleted() --> SearchEvent(source, params, false, items).isSearchCompleted()
 */

package javasoft.sqe.tests.api.javax.help.search.SearchEvent;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Vector;

import javax.help.search.SearchItem;
import javax.help.search.SearchEvent;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchEvent ... isSearchCompleted()
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class IsSearchCompletedTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public IsSearchCompletedTest() {
    }

    public static void main(String argv[]) {
        IsSearchCompletedTest test = new IsSearchCompletedTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Method test: <code>boolean isSearchCompleted()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase1() {
        String apiTested = "boolean isSearchCompleted(): "
            + "TestCase: '(new SearchEvent(source, params, false)).isSearchCompleted()' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if (searchEvent.isSearchCompleted() ) {
                return Status.failed(apiTested + "Did not get 'false':" + searchEvent.isSearchCompleted() );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean isSearchCompleted()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase2() {
        String apiTested = "boolean isSearchCompleted(): "
            + "TestCase: '(new SearchEvent(source, params, true)).isSearchCompleted()' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if (searchEvent.isSearchCompleted() ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + searchEvent.isSearchCompleted() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean isSearchCompleted()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase3() {
        String apiTested = "boolean isSearchCompleted(): "
            + "TestCase: '(new SearchEvent(source, params, true, items)).isSearchCompleted()' "
            + "ExpectedResult: 'true' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            if (searchEvent.isSearchCompleted() ) {
                return Status.passed(apiTested + "Got 'true'");
            } else {
                return Status.failed(apiTested + "Did not get 'true': " + searchEvent.isSearchCompleted() );
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Method test: <code>boolean isSearchCompleted()</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     */
    public Status testCase4() {
        String apiTested = "boolean isSearchCompleted(): "
            + "TestCase: '(new SearchEvent(source, params, false, items)).getParams()' "
            + "ExpectedResult: 'false' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            if (searchEvent.isSearchCompleted() ) {
                return Status.failed(apiTested + "Did not get 'false': " + searchEvent.isSearchCompleted() );
            } else {
                return Status.passed(apiTested + "Got 'false'");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

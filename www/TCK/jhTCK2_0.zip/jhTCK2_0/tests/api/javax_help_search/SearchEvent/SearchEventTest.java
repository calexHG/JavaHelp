/*
 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * CopyrightVersion 1.0
 */

/*
 * TestCases summary:
 * testCase1 ... SearchEvent(source, params, searching) --> SearchEvent(source, params, true)
 * testCase2 ... SearchEvent(source, params, searching) --> SearchEvent(source, params, false)
 * testCase3 ... SearchEvent(source, params, searching) --> SearchEvent(source, null, true)
 * testCase4 ... SearchEvent(source, params, searching) --> SearchEvent(null, params, true)
 *
 * testCase5 ... SearchEvent(source, params, searching, items) --> SearchEvent(source, params, true, items)
 * testCase6 ... SearchEvent(source, params, searching, items) --> SearchEvent(source, params, false, items)
 * testCase7 ... SearchEvent(source, params, searching, items) --> SearchEvent(source, params, true, null)
 * testCase8 ... SearchEvent(source, params, searching, items) --> SearchEvent(source, null, true, items)
 * testCase9 ... SearchEvent(source, params, searching, items) --> SearchEvent(null, params, true, items)
 */

package javasoft.sqe.tests.api.javax.help.search.SearchEvent;

import java.io.PrintWriter;

import java.net.URL;

import java.util.Locale;
import java.util.Vector;
import java.util.Enumeration;

import javax.help.search.SearchItem;
import javax.help.search.SearchEvent;

import com.sun.javatest.Status;
import com.sun.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchEvent ... SearchEvent(...)
 *
 * @author Patrik Knakal
 *
 * @since JH2.0
 */
public class SearchEventTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");

    public SearchEventTest() {
    }

    public static void main(String argv[]) {
        SearchEventTest test = new SearchEventTest();
        Status s = test.run(argv, new PrintWriter(System.out), new PrintWriter(System.err));
        s.exit();
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>true</code>
     */
    public Status testCase1() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching): "
            + "TestCase: Construct with: 'source == valid; params == valid; searching == true' "
            + "ExpectedResult: SearchEvent object with given values "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if(searchEvent instanceof SearchEvent) { //is instance of SearchEvent class
                if (source.equals(searchEvent.getSource()) ) { //source object is correct
                    if (params.equals(searchEvent.getParams()) ) { //params object is correct
                        if (searchEvent.isSearchCompleted() ) { //searching value is correct
                            return Status.passed(apiTested + "OK");
                        } else { //searching value is not correct
                            return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'searching' object: original: " + searching + " obtained: " + searchEvent.isSearchCompleted() );
                        }
                    } else { //params object is not correct
                        return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'params' object: original: " + params + " obtained: " + searchEvent.getParams() );
                    }
                } else { //source object is not correct
                    return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'source' object: original: " + source + " obtained: " + searchEvent.getSource() );
                }
            } else { //is not instance of SearchEvent class
                return Status.failed(apiTested + "Did not construct SearchEvent object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>false</code>
     */
    public Status testCase2() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching): "
            + "TestCase: Construct with: 'source == valid; params == valid; searching == false' "
            + "ExpectedResult: SearchEvent object with given values "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            if(searchEvent instanceof SearchEvent) { //is instance of SearchEvent class
                if (source.equals(searchEvent.getSource()) ) { //source object is correct
                    if (params.equals(searchEvent.getParams()) ) { //params object is correct
                        if ( !searchEvent.isSearchCompleted() ) { //searching value is correct
                            return Status.passed(apiTested + "OK");
                        } else { //searching value is not correct
                            return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'searching' object: original: " + searching + " obtained: " + searchEvent.isSearchCompleted() );
                        }
                    } else { //params object is not correct
                        return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'params' object: original: " + params + " obtained: " + searchEvent.getParams() );
                    }
                } else { //source object is not correct
                    return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'source' object: original: " + source + " obtained: " + searchEvent.getSource() );
                }
            } else { //is not instance of SearchEvent class
                return Status.failed(apiTested + "Did not construct SearchEvent object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    <code>null</code> value
     * @param <code>searching</code> <code>true</code>
     */
    public Status testCase3() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching): "
            + "TestCase: Construct with: 'source == valid; params == null; searching == true' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = null;
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    <code>null</code> value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>true</code>
     */
    public Status testCase4() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching): "
            + "TestCase: Construct with: 'source == null; params == valid; searching == true' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = null;
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching);
            //creating SearchEvent object form given parameters ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>true</code>
     * @param <code>items</code>     valid value
     */
    public Status testCase5() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items): "
            + "TestCase: Construct with: 'source == valid; params == valid; searching == true; items == valid' "
            + "ExpectedResult: SearchEvent object with given values "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            if(searchEvent instanceof SearchEvent) { //is instance of SearchEvent class
                if (source.equals(searchEvent.getSource()) ) { //source object is correct
                    if (params.equals(searchEvent.getParams()) ) { //params object is correct
                        if (searchEvent.isSearchCompleted() ) { //searching value is correct
                            //check the returned Enumeration ... end
                            boolean check = true;
                            Enumeration enum = searchEvent.getSearchItems();
                            int vectorsize = items.size();
                            for (int i = 0 ; (i < items.size()) && enum.hasMoreElements() && check ; i++, vectorsize--) {
                                SearchItem item = (SearchItem)enum.nextElement();
                                if (!item.equals((SearchItem)items.elementAt(i)) ) {
                                    check = false;
                                }
                            }
                            if (check && (vectorsize != 0 || enum.hasMoreElements()) ) {
                                check = false;
                            }
                            //check the returned Enumeration ... end
                            if (check) { //items object is correct
                                return Status.passed(apiTested + "OK");
                            } else { //items object is not correct
                                return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'items' object");
                            }
                        } else { //searching value is not correct
                            return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'searching' object: original: " + searching + " obtained: " + searchEvent.isSearchCompleted() );
                        }
                    } else { //params object is not correct
                        return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'params' object: original: " + params + " obtained: " + searchEvent.getParams() );
                    }
                } else { //source object is not correct
                    return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'source' object: original: " + source + " obtained: " + searchEvent.getSource() );
                }
            } else { //is not instance of SearchEvent class
                return Status.failed(apiTested + "Did not construct SearchEvent object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>false</code>
     * @param <code>items</code>     valid value
     */
    public Status testCase6() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items): "
            + "TestCase: Construct with: 'source == valid; params == valid; searching == false; items == valid' "
            + "ExpectedResult: SearchEvent object with given values "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = false;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            if(searchEvent instanceof SearchEvent) { //is instance of SearchEvent class
                if (source.equals(searchEvent.getSource()) ) { //source object is correct
                    if (params.equals(searchEvent.getParams()) ) { //params object is correct
                        if ( !searchEvent.isSearchCompleted() ) { //searching value is correct
                            //check the returned Enumeration ... end
                            boolean check = true;
                            Enumeration enum = searchEvent.getSearchItems();
                            int vectorsize = items.size();
                            for (int i = 0 ; (i < items.size()) && enum.hasMoreElements() && check ; i++, vectorsize--) {
                                SearchItem item = (SearchItem)enum.nextElement();
                                if (!item.equals((SearchItem)items.elementAt(i)) ) {
                                    check = false;
                                }
                            }
                            if (check && (vectorsize != 0 || enum.hasMoreElements()) ) {
                                check = false;
                            }
                            //check the returned Enumeration ... end
                            if (check) { //items object is correct
                                return Status.passed(apiTested + "OK");
                            } else { //items object is not correct
                                return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'items' object");
                            }
                        } else { //searching value is not correct
                            return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'searching' object: original: " + searching + " obtained: " + searchEvent.isSearchCompleted() );
                        }
                    } else { //params object is not correct
                        return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'params' object: original: " + params + " obtained: " + searchEvent.getParams() );
                    }
                } else { //source object is not correct
                    return Status.failed(apiTested + "Did not construct SearchEvent object with correct 'source' object: original: " + source + " obtained: " + searchEvent.getSource() );
                }
            } else { //is not instance of SearchEvent class
                return Status.failed(apiTested + "Did not construct SearchEvent object");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>true</code>
     * @param <code>items</code>     <code>null</code> value
     */
    public Status testCase7() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items): "
            + "TestCase: Construct with: 'source == valid; params == valid; searching == true; items == null' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating items Vector instance ... start
            Vector items = null;
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    valid value
     * @param <code>params</code>    <code>null</code> value
     * @param <code>searching</code> <code>true</code>
     * @param <code>items</code>     valid value
     */
    public Status testCase8() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items): "
            + "TestCase: Construct with: 'source == valid; params == null; searching == true; items == valid' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = new Object();
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = null;
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }


    /**
     * Constructor test: <code>SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items)</code>
     *
     * @author Patrik Knakal
     *
     * @since JH2.0
     *
     * @param <code>source</code>    <code>null</code> value
     * @param <code>params</code>    valid value
     * @param <code>searching</code> <code>true</code>
     * @param <code>items</code>     valid value
     */
    public Status testCase9() {
        String apiTested = "SearchEvent(java.lang.Object source, java.lang.String params, boolean searching, java.util.Vector items): "
            + "TestCase: Construct with: 'source == null; params == valid; searching == true; items == valid' "
            + "ExpectedResult: 'java.lang.IllegalArgumentException' "
            + "ObtainedResult: ";

        try {
            //creating source Object instance ... start
            Object source = null;
            //creating source Object instance ... end

            //creating params String instance ... start
            String params = "params";
            //creating params String instance ... end

            //setting searching value ... start
            boolean searching = true;
            //setting searching value ... end

            //creating SearchItem object ... start
            //copy from the SearchItemTest class
            Vector concepts = new Vector();
            concepts.addElement(new String("One") );
            concepts.addElement(new String("Two") );
            SearchItem searchItem = new SearchItem(new URL("file", null, HSLOC + "/holidays/hol/hol.html"), new String("TITLE"), Locale.getDefault().toString(), new String("hol.html"), 3, 1, 10, concepts);
            //creating SearchItem object ... end

            //creating items Vector instance ... start
            Vector items = new Vector();
            items.addElement(searchItem);
            //creating items Vector instance ... end

            //creating SearchEvent object form given parameters ... start
            SearchEvent searchEvent = new SearchEvent(source, params, searching, items);
            //creating SearchEvent object form given parameters ... end

            return Status.failed(apiTested + "Did not get 'java.lang.IllegalArgumentException'");
        } catch (IllegalArgumentException exc) {
            return Status.passed(apiTested + "Got 'java.lang.IllegalArgumentException'");
        } catch (Exception exc) {
            exc.printStackTrace();
            return Status.failed(apiTested + "Got Exception: " + exc);
        }
    }

}

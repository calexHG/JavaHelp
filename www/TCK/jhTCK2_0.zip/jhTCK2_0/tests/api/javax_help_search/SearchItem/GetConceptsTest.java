
/*
* 
* 
* @(#)GetConceptsTest.java	1.1 99/03/02 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.search.SearchItem;

import javax.help.search.SearchItem;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchItem;
 
 * @author Ben John.
 */

public class GetConceptsTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public GetConceptsTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        GetConceptsTest test = new GetConceptsTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" getConcepts() \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
			String ss[]={"One","Two"};
            myv.addElement(ss[0]);
            myv.addElement(ss[1]);
            SearchItem si = new SearchItem(url, "TITLE", 
                    Locale.getDefault().toString(), "hol.html", 3, 1, 10, myv);
			int i=0;
			boolean check=false;
			for(java.util.Enumeration ee = si.getConcepts();
					ee.hasMoreElements();) {
			   if(ee.nextElement().equals(ss[i])) {
                    check = true;
                }
                else {
                    check = false;
                    break;
                }
				i++;
            }
	        if((si instanceof SearchItem) 
            && (si.getConcepts() instanceof java.util.Enumeration) &&
				(check)) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}

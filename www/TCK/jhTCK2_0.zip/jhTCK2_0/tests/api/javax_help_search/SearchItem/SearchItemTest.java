
/*
* 
* 
* @(#)SearchItemTest.java	1.1 99/03/02 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.search.SearchItem;

import javax.help.search.SearchItem;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;

/**
 * Tests for javax.help.search.SearchItem;
 
 * @author Ben John.
 */

public class SearchItemTest extends MultiTest {
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public SearchItemTest() { //constructor
        
    }
    
    public static void main(String argv[]) {
        SearchItemTest test = new SearchItemTest();
        Status s = test.run(argv, new PrintWriter(System.out), 
                   new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + " java.lang.String title, java.lang.String lang, "
                           + " java.lang.String filename, double confidence, "
                           + " int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            String ss[]={"One","Two"};
			myv.addElement(ss[0]);
            myv.addElement(ss[1]);
            SearchItem si = new SearchItem(url, "TITLE", 
                     Locale.getDefault().toString(), "hol.html", 3, 1, 10, myv);
			int i=0;
			boolean check=false;
			for(java.util.Enumeration ee = si.getConcepts();
					ee.hasMoreElements();) {
		   if(ee.nextElement().equals(ss[i])) {
                   check = true;
               }
           else {
              check = false;
               break;
             }
				i++;
           }
		   double dd= 3;
            if((si instanceof SearchItem) && (si.getBase() == url) &&
			     (si.getTitle()=="TITLE") && (si.getFilename()=="hol.html")
				 && (si.getConfidence()==dd ) && (si.getBegin()==1) &&
				  (si.getEnd()==10) && (check)) {
                return Status.passed(apiTested + "Okay");
            } else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + " java.lang.String title, java.lang.String lang, "
                           + " java.lang.String filename, double confidence, "
                           + " int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            SearchItem si = new SearchItem(null, "TITLE", 
                       Locale.getDefault().toString(), "hol.html", 3, 0, 0, myv);
            return Status.failed(apiTested
                + "Did not Exception throws");
          }
		catch(NullPointerException ne){
			return Status.passed(apiTested 
		            + "Exception raised for null URL " + ne);
		}
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for null URL " + ee);
        }
    }
    
    public Status testCase3() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + " java.lang.String title, java.lang.String lang,"
                           + "  java.lang.String filename, double confidence, "
                           + "int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            SearchItem si = new SearchItem(url, null, 
                      Locale.getDefault().toString(), "hol.html", 3, 0, 0, myv);
			return Status.failed(apiTested
			                + "Did not Exception throws");
        }
		catch(NullPointerException ne){
			return Status.passed(apiTested 
				+ "Exception raised for null Title " + ne);		
		}
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for null Title " + ee);
        }
    }
    
    public Status testCase4() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + "java.lang.String title, java.lang.String lang,"
                           + " java.lang.String filename, double confidence,"
                           + " int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            SearchItem si = new SearchItem(url, "TITLE", null, "hol.html", 
                            3, 0, 0, myv);
            if((si instanceof SearchItem) && (si.getLang() == null)) {
                return Status.passed(apiTested + "Okay for null Lang");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid object for null Lang");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for null Lang: " + ee);
        }
    }
    
    public Status testCase5() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + "java.lang.String title, java.lang.String lang, "
                           + "java.lang.String filename, double confidence, "
                           + "int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            SearchItem si = new SearchItem(url, "TITLE", 
                            Locale.getDefault().toString(), null, 3, 0, 0, myv);
            return Status.failed(apiTested
                + "Did not Exception throws");
        }
		catch(NullPointerException ne){
			return Status.passed(apiTested 
			+ "Exception raised for null FileName: " + ne);				
		}
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for null FileName: " + ee);
        }
    }
    
    public Status testCase6() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + "java.lang.String title, java.lang.String lang,"
                           + " java.lang.String filename, double confidence,"
                           + " int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            SearchItem si = new SearchItem(url, "TITLE", 
                     Locale.getDefault().toString(), "hol.html", 3, 0, 0, null);
            return Status.failed(apiTested
                + "Did not Exception throws");        
			}
			catch(NullPointerException ne){
				return Status.passed(apiTested 
				+ "Exception raised for null concepts " + ne);
			}
	        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for null concepts " + ee);
        }
    }
    
    public Status testCase7() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + "java.lang.String title, java.lang.String lang, "
                           + "java.lang.String filename, double confidence, "
                           + "int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            int a = Integer.MAX_VALUE;
            int b = Integer.MIN_VALUE;
            SearchItem si = new SearchItem(url, "TITLE", 
                      Locale.getDefault().toString(), "hol.html", 3, a, b, myv);
            if((si instanceof SearchItem) && (si.getBase() == url)) {
                return Status.passed(apiTested 
                + "Okay for Max and Min int parameters");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid object with maximum and minimum "
                + " Integer parameters");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for max. and min. Integer parameters. " + ee);
        }
    }
    
    public Status testCase8() {
        String apiTested = "Method \" SearchItem(java.net.URL base, "
                           + "java.lang.String title, java.lang.String lang, "
                           + "java.lang.String filename, double confidence, "
                           + "int begin, int end, java.util.Vector concepts)  \" ";
        try {
            URL url = new URL("file", null, HSLOC + "/holidays/hol/hol.html");
            Vector myv = new Vector();
            myv.addElement("One");
            myv.addElement("Two");
            double dd = Double.MAX_VALUE;
            SearchItem si = new SearchItem(url, "TITLE", 
                     Locale.getDefault().toString(), "hol.html", dd, 0, 0, myv);
            if((si instanceof SearchItem) && (si.getBase() == url)) {
                return Status.passed(apiTested 
                 + "Okay with max. double type parameter");
            }
            else {
                return Status.failed(apiTested 
                + "Did not Construct valid object with double type parameter");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested 
            + "Exception raised for double type parameter. " + ee);
        }
    }
}

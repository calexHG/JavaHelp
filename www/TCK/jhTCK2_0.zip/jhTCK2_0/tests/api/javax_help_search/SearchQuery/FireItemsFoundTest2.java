
/*
* 
* 
* @(#)FireItemsFoundTest2.java	1.1 99/03/15 Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
* 
* This software is the confidential and proprietary information of Sun
* Microsystems, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Sun.
* 
* SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
* SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
* THIS SOFTWARE OR ITS DERIVATIVES.
* 
* CopyrightVersion 1.0
*/
package javasoft.sqe.tests.api.javax.help.search.SearchQuery;
import javax.help.search.SearchEngine;
import javax.help.search.SearchEvent;
import javax.help.search.SearchQuery;
import javax.help.HelpSet;
import javax.help.Map;
import com.sun.help.jck.harness.MySearchListener;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import java.net.URL;
import java.io.PrintWriter;
import javasoft.sqe.javatest.Status;
import javasoft.sqe.javatest.lib.MultiTest;
import java.util.Hashtable;

/**
 * Tests for javax.help.search.SearchQuery;
 
 * @author ChellaKumaran
 */

class MySearchEngine extends SearchEngine {
    
    public MySearchEngine() {
        super();
    }
    
    public MySearchEngine(java.net.URL base1, java.util.Hashtable params1) {
        super(base1, params1);
    }
    
    public javax.help.search.SearchQuery createQuery() throws IllegalStateException {
        return null;
    }
}

class MySearchQuery extends SearchQuery {
    
    public MySearchQuery(SearchEngine ss) {
        super(ss);
    }
    
    public boolean isActive() {
        return false;
    }
    
    public void myFireItemsFound(boolean search, Vector v) {
        fireItemsFound(search, v);
    }
    
    public void myFireItemsFound(SearchEvent e) {
        fireSearchStarted();
        fireSearchFinished();
    }
}

public class FireItemsFoundTest2 extends MultiTest {
    
    public static String HSLOC = System.getProperty("HS_LOC");
    
    public FireItemsFoundTest2() { //constructor
        
    }
    
    public static void main(String argv[]) {
        FireItemsFoundTest2 test = new FireItemsFoundTest2();
        Status s = test.run(argv, new PrintWriter(System.out), 
        new PrintWriter(System.err));
        s.exit();
    }
    
    public Status testCase1() {
        String apiTested = "Method \" fireItemsFound(SearchEvent e) \" ";
        try {
            
            MySearchListener searchListen = new MySearchListener();
            Vector myVector = new Vector();
            myVector.addElement("Guru");
            myVector.addElement("Sishyan");
            SearchEvent sevent = new SearchEvent(searchListen, "myJavaHelp", 
                                 true, myVector);
            MySearchEngine searchEngine = new MySearchEngine();
            MySearchQuery searchQuery = new MySearchQuery(searchEngine);
            searchQuery.addSearchListener(searchListen); 
            searchQuery.start("myJavaHelp", Locale.getDefault()); 
            searchQuery.myFireItemsFound(sevent);
            
            if(MySearchListener.boolValue == false) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            ee.printStackTrace();
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
    
    public Status testCase2() {
        String apiTested = "Method \" fireItemsFound(SearchEvent e) \" ";
        try {
            MySearchEngine searchEngine = new MySearchEngine();
            MySearchQuery searchQuery = new MySearchQuery(searchEngine);
            MySearchListener searchListen = new MySearchListener();
            searchQuery.addSearchListener(searchListen); 
            searchQuery.start("myJavaHelp", Locale.getDefault()); 
            Vector myVector = new Vector();
            myVector.addElement("Guru");
            myVector.addElement("Sishyan");
            searchQuery.myFireItemsFound();
            if(MySearchListener.findValue == true) {
                return Status.passed(apiTested + "Okay");
            }
            else {
                return Status.failed(apiTested + "Did not Construct valid object");
            }
        }
        catch(Exception ee) {
            return Status.failed(apiTested + "Exception raised: " + ee);
        }
    }
}
